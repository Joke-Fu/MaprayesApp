import { i as useSettings, t as cn } from "./room-BKUs9KcL.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as playSound } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { t as useHasMounted } from "./use-has-mounted-6Fm7Kyxs.mjs";
import { t as Switch } from "./switch-D6lyiARv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ajustes-D_1Iki_s.js
var import_jsx_runtime = require_jsx_runtime();
function Ajustes() {
	const mounted = useHasMounted();
	const theme = useSettings((s) => s.theme);
	const setTheme = useSettings((s) => s.setTheme);
	const textSize = useSettings((s) => s.textSize);
	const setTextSize = useSettings((s) => s.setTextSize);
	const font = useSettings((s) => s.font);
	const setFont = useSettings((s) => s.setFont);
	const showCounters = useSettings((s) => s.showCounters);
	const setShowCounters = useSettings((s) => s.setShowCounters);
	const soundEnabled = useSettings((s) => s.soundEnabled);
	const setSoundEnabled = useSettings((s) => s.setSoundEnabled);
	const primordialUnlocked = useSettings((s) => s.primordialUnlocked);
	const chaosFontUnlocked = useSettings((s) => s.chaosFontUnlocked);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Ajustes",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceGroup, {
					label: "Tema",
					options: [
						{
							id: "light",
							label: "Claro"
						},
						{
							id: "dark",
							label: "Oscuro"
						},
						{
							id: "night",
							label: "Noche de Guardianes"
						}
					],
					value: theme,
					onChange: (v) => setTheme(v)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceGroup, {
					label: "Tamaño de texto",
					options: [
						{
							id: "small",
							label: "Pequeño"
						},
						{
							id: "normal",
							label: "Normal"
						},
						{
							id: "large",
							label: "Grande"
						}
					],
					value: textSize,
					onChange: (v) => setTextSize(v)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Fuente"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceChip, {
									active: font === "normal",
									onClick: () => setFont("normal"),
									children: "Estándar"
								}),
								mounted && primordialUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceChip, {
									active: font === "maprayes",
									onClick: () => setFont("maprayes"),
									children: "Maprayés"
								}) : null,
								mounted && chaosFontUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceChip, {
									active: font === "caos",
									onClick: () => setFont("caos"),
									children: "Caos"
								}) : null
							]
						}),
						mounted && !primordialUnlocked && !chaosFontUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted italic",
							children: "Hay fuentes que se revelan cuando el lenguaje lo permite."
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-4 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "counters",
						className: "text-sm font-medium",
						children: "Mostrar contadores de caracteres"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: "counters",
						checked: showCounters,
						onCheckedChange: setShowCounters
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-4 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "sounds",
						className: "text-sm font-medium",
						children: "Sonidos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Traducir, guardianes, cámara y códigos."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: "sounds",
						checked: soundEnabled,
						onCheckedChange: (v) => {
							setSoundEnabled(v);
							if (v) playSound("toggle");
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianThemeToggle, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-6 text-center text-xs text-muted italic",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Maprayés © Joke-Fu 2026" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://github.com/Joke-Fu/maprayes",
							target: "_blank",
							rel: "noreferrer",
							className: "underline decoration-border underline-offset-4 hover:text-olive",
							children: "Ver en GitHub"
						})
					})]
				})
			]
		})
	});
}
function GuardianThemeToggle() {
	const guardianTheme = useSettings((s) => s.guardianTheme);
	const setGuardianTheme = useSettings((s) => s.setGuardianTheme);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: "guardian-theme",
			className: "text-sm font-medium",
			children: "Colores de guardianes"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: "El acento de la interfaz sigue al último guardián de la secuencia."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			id: "guardian-theme",
			checked: guardianTheme,
			onCheckedChange: (v) => {
				setGuardianTheme(v);
				playSound("toggle");
			}
		})]
	});
}
function ChoiceGroup({ label, options, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceChip, {
				active: value === opt.id,
				onClick: () => onChange(opt.id),
				children: opt.label
			}, opt.id))
		})]
	});
}
function ChoiceChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-11 rounded-md px-4 text-sm font-medium transition-colors duration-150", active ? "bg-olive text-olive-fg" : "bg-surface text-fg shadow-[var(--shadow-border)]"),
		children
	});
}
//#endregion
export { Ajustes as component };
