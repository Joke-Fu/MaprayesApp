import { a as PRIMORDIAL_LORE, i as GUARDIAN_IDS, r as GUARDIANS } from "./guardians-DdPXp9oS.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as GuardianSigil } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guardianes-CuIUeQj9.js
var import_jsx_runtime = require_jsx_runtime();
function Guardianes() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Guardianes",
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-6 text-sm text-muted",
			children: "Ocho voluntades custodian el lenguaje. Cada una desplaza el alfabeto a su manera."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
			children: [GUARDIAN_IDS.map((id) => {
				const g = GUARDIANS[id];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					style: { borderTop: `3px solid ${g.accent}` },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center gap-3 text-olive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
								id,
								className: "size-7"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-medium text-fg",
								children: g.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-sm italic text-muted",
							children: g.epithet
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed",
							children: g.lore
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-xs font-medium tracking-wide text-muted uppercase",
							children: ["Desplazamiento · ", g.displacement]
						})
					]
				}, id);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Maprayés Primordial"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-sm italic text-muted",
						children: "El lenguaje en su forma más antigua y pura."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed",
						children: PRIMORDIAL_LORE
					})
				]
			})]
		})]
	});
}
//#endregion
export { Guardianes as component };
