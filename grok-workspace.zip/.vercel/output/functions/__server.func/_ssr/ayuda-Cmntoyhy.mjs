import { i as GUARDIAN_IDS, r as GUARDIANS } from "./guardians-DdPXp9oS.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as GuardianSigil } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ayuda-Cmntoyhy.js
var import_jsx_runtime = require_jsx_runtime();
function Ayuda() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Ayuda y lore",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-8 text-sm leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Qué es Maprayés"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Maprayés nació como un lenguaje secreto: un código que une lo cotidiano con lo mítico. Cada glifo ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: "(X)Y"
						}),
						" ",
						"es una puerta pequeña hacia un universo donde gatos, portales y caos conviven."
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: "Cómo traducir"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Escribe en el traductor y el texto se convierte en códigos. Los espacios separan palabras con ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono",
								children: "||"
							}),
							". Para volver atrás, pega el código — si el mensaje lleva prefijo",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono",
								children: "[MYTHIC:…]"
							}),
							", los guardianes se restauran solos."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El código visual (imagen) incluye a los guardianes activos. Compártelo para que la otra persona reciba no solo las letras, sino también quién las custodia." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Cámara"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Desde el menú o el traductor puedes abrir la cámara y apuntar a un código. Si el entorno no deja usar la cámara en vivo, elige una foto: el mensaje se pega en Maprayés a texto, con sus guardianes si el código lleva prefijo MYTHIC." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Sala"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Crea un umbral y comparte el código ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: "MAP-····"
						}),
						". Quien lo escriba ve los mismos guardianes y, en el traductor, el texto que escribes — en claro o cifrado, según elija. La conexión es directa entre dispositivos."
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Afinidad"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El mapa recuerda qué guardianes viajan juntos cuando un mensaje se cifra de verdad — no basta con invocarlos. Cada secuencia de dos o más que toque al menos una letra, número o símbolo teje un hilo." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: "Iniciación"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cinco caminos para probar el lenguaje. Fácil, Medio, Difícil y Libre usan el alfabeto base: se muestra un cifrado y escribes la lectura. Puedes revelar si el velo no cede. Extremo es otro rito: la frase está clara, el cifrado ya tiene cortejo, y tú convocas guardianes hasta que las dos escrituras coincidan." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Los aciertos despiertan Reliquias — sellos y sigilos que permanecen." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Compartir"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El botón Compartir abre la hoja del sistema: WhatsApp, Messenger, Bluetooth u otras apps del teléfono. Si el navegador no la ofrece, copia el mensaje o envíalo por WhatsApp web." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Los ocho"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: GUARDIAN_IDS.map((id) => {
							const g = GUARDIANS[id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
									id,
									className: "mt-0.5 size-5 text-olive"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "font-medium",
										children: [g.name, "."]
									}),
									" ",
									g.help
								] })]
							}, id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Lo que no se dice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Seis es el límite. Ocho es la excepción. Tres voluntades juntas —la travesura, el humor picante y la llama— pueden desordenar el velo, y el velo se rompe más rápido de lo que parece. Hay fuentes que no aparecen en Ajustes hasta que el lenguaje las recuerda. En Ajustes también puedes dejar que el color de la interfaz siga al último guardián, o devolverle el oliva." })]
				})
			]
		})
	});
}
//#endregion
export { Ayuda as component };
