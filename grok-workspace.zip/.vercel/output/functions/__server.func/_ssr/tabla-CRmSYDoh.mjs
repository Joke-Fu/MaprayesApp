import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as useSettings, t as cn } from "./room-BKUs9KcL.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Star } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { l as entriesForCategory } from "./alphabet-DP9zcs2T.mjs";
import { t as Input } from "./input-BtFy7h-C.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tabla-CRmSYDoh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "letras",
		label: "Letras"
	},
	{
		id: "numeros",
		label: "Números"
	},
	{
		id: "simbolos",
		label: "Símbolos"
	},
	{
		id: "favoritos",
		label: "Favoritos"
	}
];
function Tabla() {
	const [category, setCategory] = (0, import_react.useState)("letras");
	const [query, setQuery] = (0, import_react.useState)("");
	const favorites = useSettings((s) => s.favorites);
	const toggleFavorite = useSettings((s) => s.toggleFavorite);
	const rows = (0, import_react.useMemo)(() => {
		const items = entriesForCategory(category, favorites);
		const q = query.trim().toLowerCase();
		if (!q) return items;
		return items.filter(([code, char]) => char.toLowerCase().includes(q) || code.toLowerCase().includes(q));
	}, [
		category,
		favorites,
		query
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Tabla de códigos",
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: TABS.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCategory(tab.id),
						className: cn("h-11 rounded-md px-4 text-sm font-medium transition-colors duration-150", category === tab.id ? "bg-olive text-olive-fg" : "bg-surface text-fg shadow-[var(--shadow-border)]"),
						children: tab.label
					}, tab.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Buscar carácter o código…",
					"aria-label": "Filtrar tabla"
				}),
				rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted",
					children: category === "favoritos" ? "Aún no has marcado ningún código. Toca la estrella en la tabla." : "Nada coincide con esa búsqueda."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "bg-olive text-olive-fg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-display font-medium",
									children: "Carácter"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-display font-medium",
									children: "Código"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-display font-medium",
									children: "Favorito"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map(([code, char], i) => {
							const fav = favorites.includes(code);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: i % 2 === 1 ? "bg-surface-2/50" : void 0,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-3 text-lg",
										children: char
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-3 font-mono text-sm",
										children: code
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "inline-flex size-11 items-center justify-center rounded-md",
											"aria-label": fav ? "Quitar de favoritos" : "Añadir a favoritos",
											"aria-pressed": fav,
											onClick: () => toggleFavorite(code),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-5", fav ? "fill-olive text-olive" : "text-muted") })
										})
									})
								]
							}, code);
						}) })]
					})
				})
			]
		})
	});
}
//#endregion
export { Tabla as component };
