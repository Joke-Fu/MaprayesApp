import { o as __toESM } from "../_runtime.mjs";
import { c as canAddGuardian, i as GUARDIAN_IDS, r as GUARDIANS, u as isDualMode } from "./guardians-DdPXp9oS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as cn } from "./room-BKUs9KcL.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as ArrowRight, g as Eye, h as Gem, t as X } from "../_libs/lucide-react.mjs";
import { i as Button, n as notify, o as playSound, r as GuardianSigil } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { i as encodeWithGuardians } from "./cipher-C9E6kqVb.mjs";
import { t as useHasMounted } from "./use-has-mounted-6Fm7Kyxs.mjs";
import { t as Switch } from "./switch-D6lyiARv.mjs";
import { t as Input } from "./input-BtFy7h-C.mjs";
import { a as RELICS, c as makeExtremoChallenge, d as useIniciacion, i as LEVEL_LABEL, l as relicUnlocked, n as KIND_LABEL, o as answersMatch, r as LEVEL_HINT$1, s as makeDrillPrompt, t as DRILL_KINDS, u as unlockedCount } from "./iniciacion-nmFQ5Xo3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/iniciacion.index-DBvc0DcF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Iniciacion() {
	const [view, setView] = (0, import_react.useState)("hub");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: view === "hub" ? "Iniciación" : LEVEL_LABEL[view],
		children: view === "hub" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, { onOpen: setView }) : view === "extremo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtremoBoard, { onBack: () => setView("hub") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrillBoard, {
			level: view,
			onBack: () => setView("hub")
		})
	});
}
function Hub({ onOpen }) {
	const mounted = useHasMounted();
	const hits = useIniciacion((s) => s.hits);
	const guardianHits = useIniciacion((s) => s.guardianHits);
	const relics = mounted ? unlockedCount({
		hits,
		guardianHits
	}) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Aquí el lenguaje se prueba en voz baja. Descifrado primero; en Extremo, los guardianes son la respuesta."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/iniciacion/reliquias",
				className: "flex min-h-14 items-center justify-between rounded-xl bg-surface px-5 py-3.5 shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.98]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "size-5 text-olive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium",
						children: "Reliquias"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: mounted ? `${relics} de ${RELICS.length} despiertas` : "Vitrina de logros"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted" })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex flex-col gap-2",
			"aria-label": "Niveles",
			children: [
				"facil",
				"medio",
				"dificil",
				"extremo",
				"libre"
			].map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					playSound("toggle");
					onOpen(level);
				},
				className: "flex min-h-14 items-center justify-between rounded-xl bg-surface px-5 py-3.5 text-left shadow-[var(--shadow-border)] transition-transform duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--fg)_16%,transparent)] active:scale-[0.98]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: LEVEL_LABEL[level]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: LEVEL_HINT$1[level]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums text-olive",
					children: mounted ? `${hits[level]} aciertos` : ""
				})]
			}, level))
		})]
	});
}
function announceRelics(beforeIds) {
	const stats = useIniciacion.getState();
	const fresh = RELICS.filter((r) => relicUnlocked(r, stats) && !beforeIds.has(r.id));
	if (fresh[0]) {
		playSound("primordial");
		notify(`Reliquia: ${fresh[0].title}`, "full", 3600);
	}
}
function snapshotRelics() {
	const stats = useIniciacion.getState();
	return new Set(RELICS.filter((r) => relicUnlocked(r, stats)).map((r) => r.id));
}
function DrillBoard({ level, onBack }) {
	const hits = useIniciacion((s) => s.hits);
	const registerHit = useIniciacion((s) => s.registerHit);
	const [kind, setKind] = (0, import_react.useState)(level === "libre" ? "palabras" : "letras");
	const used = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const [prompt, setPrompt] = (0, import_react.useState)(() => makeDrillPrompt(level, level === "libre" ? "palabras" : "letras", used.current));
	const [answer, setAnswer] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("idle");
	function nextPrompt(nextKind = kind) {
		setPrompt(makeDrillPrompt(level, nextKind, used.current));
		setAnswer("");
		setStatus("idle");
		playSound("translate");
	}
	function check() {
		if (!answer.trim()) {
			playSound("error");
			notify("Escribe tu lectura.", "escrimedes");
			return;
		}
		if (answersMatch(prompt.plaintext, answer)) {
			setStatus("ok");
			playSound("decode");
			const before = snapshotRelics();
			registerHit(level);
			announceRelics(before);
			notify("El velo se abre.", "yudmiry");
		} else {
			setStatus("bad");
			playSound("error");
			notify("Aún no. Mira otra vez el signo.", "escrimedes");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "text-sm text-muted hover:text-fg",
					children: "Niveles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tabular-nums text-muted",
					children: [hits[level], " aciertos"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: DRILL_KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setKind(item);
						nextPrompt(item);
					},
					className: cn("h-11 rounded-md px-3 text-sm font-medium", kind === item ? "bg-olive text-olive-fg" : "bg-surface text-fg shadow-[var(--shadow-border)]"),
					children: KIND_LABEL[item]
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-xl bg-surface px-4 py-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-muted uppercase",
					children: "Lee esto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-sm leading-relaxed break-all text-olive",
					children: prompt.cipher
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: answer,
				onChange: (e) => {
					setAnswer(e.target.value);
					if (status === "bad") setStatus("idle");
				},
				placeholder: "Tu lectura…",
				"aria-label": "Respuesta",
				onKeyDown: (e) => {
					if (e.key === "Enter" && status !== "ok" && status !== "revealed") check();
				},
				disabled: status === "ok" || status === "revealed"
			}),
			status === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-center text-sm italic text-olive",
				children: "Correcto."
			}) : null,
			status === "bad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-[color:var(--danger)]",
				children: "Aún no coincide."
			}) : null,
			status === "revealed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center font-medium",
				children: prompt.plaintext
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [status === "ok" || status === "revealed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => nextPrompt(),
					children: "Siguiente"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: check,
					children: "Comprobar"
				}), status !== "ok" && status !== "revealed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => {
						setStatus("revealed");
						setAnswer(prompt.plaintext);
						playSound("toggle");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}), "Revelar"]
				}) : null]
			})
		]
	});
}
function ExtremoBoard({ onBack }) {
	const hits = useIniciacion((s) => s.hits);
	const registerExtremo = useIniciacion((s) => s.registerExtremo);
	const used = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const [challenge, setChallenge] = (0, import_react.useState)(() => makeExtremoChallenge(used.current));
	const [sequence, setSequence] = (0, import_react.useState)([]);
	const [modes, setModes] = (0, import_react.useState)({});
	const [resolved, setResolved] = (0, import_react.useState)("idle");
	const counted = (0, import_react.useRef)(false);
	const current = (0, import_react.useMemo)(() => encodeWithGuardians(challenge.plaintext, sequence, modes).code, [
		challenge.plaintext,
		sequence,
		modes
	]);
	const matches = current === challenge.target && sequence.length > 0;
	(0, import_react.useEffect)(() => {
		if (resolved !== "idle") return;
		if (!matches) return;
		setResolved("ok");
		if (counted.current) return;
		counted.current = true;
		playSound("decode");
		const before = snapshotRelics();
		registerExtremo(sequence);
		announceRelics(before);
		notify("La combinación es la correcta.", "full", 3200);
	}, [
		matches,
		resolved,
		registerExtremo,
		sequence
	]);
	function next() {
		counted.current = false;
		setChallenge(makeExtremoChallenge(used.current));
		setSequence([]);
		setModes({});
		setResolved("idle");
		playSound("translate");
	}
	function add(id) {
		const check = canAddGuardian(sequence, modes, id);
		if (!check.ok) {
			playSound("error");
			notify(check.reason === "already" ? "Ese guardián ya está en el cortejo." : "El equilibrio se rompe. No más de seis.", id);
			return;
		}
		setSequence((s) => [...s, id]);
		setModes((m) => ({
			...m,
			[id]: true
		}));
		playSound("guardian-add", { guardian: id });
	}
	function remove(index) {
		const id = sequence[index];
		if (!id) return;
		setSequence((s) => s.filter((_, i) => i !== index));
		setModes((m) => {
			const nextModes = { ...m };
			delete nextModes[id];
			return nextModes;
		});
		playSound("guardian-remove", { guardian: id });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "text-sm text-muted hover:text-fg",
					children: "Niveles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tabular-nums text-muted",
					children: [hits.extremo, " aciertos"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "La frase es clara. El cifrado ya tiene cortejo. Invoca y retira guardianes hasta que tu versión coincida."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-xl bg-surface px-4 py-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-muted uppercase",
					children: "Frase"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-medium italic",
					children: challenge.plaintext
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CipherCompare, {
				target: challenge.target,
				current,
				match: matches
			}),
			resolved === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-center text-sm italic text-olive",
				children: "El cortejo es el justo."
			}) : null,
			resolved === "revealed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted",
				children: challenge.sequence.map((id) => {
					const g = GUARDIANS[id];
					const plus = challenge.modes[id] !== false;
					if (isDualMode(id)) return `${g.name} (${plus ? g.plusLabel : g.minusLabel})`;
					return g.name;
				}).join(" · ")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [sequence.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: sequence.map((id, i) => {
						const g = GUARDIANS[id];
						const plus = modes[id] !== false;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-h-12 items-center gap-3 rounded-lg bg-surface px-3 py-2 shadow-[var(--shadow-border)]",
							style: { borderLeft: `3px solid ${g.accent}` },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
									id,
									className: "size-5 text-olive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 font-medium",
									children: g.name
								}),
								isDualMode(id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-xs text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: plus,
										onCheckedChange: (v) => setModes((m) => ({
											...m,
											[id]: v
										})),
										"aria-label": g.name
									}), plus ? g.plusLabel : g.minusLabel]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs tabular-nums text-muted",
									children: g.displacement
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex size-10 items-center justify-center rounded-md text-muted hover:text-fg",
									"aria-label": `Quitar ${g.name}`,
									onClick: () => remove(i),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
								})
							]
						}, `${id}-${i}`);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted italic",
					children: "Ningún guardián convocado."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: GUARDIAN_IDS.map((id) => {
						const g = GUARDIANS[id];
						const taken = sequence.includes(id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: taken,
							onClick: () => add(id),
							className: "flex min-h-14 flex-col items-start gap-1 rounded-lg bg-surface px-3 py-2.5 text-left shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.98] disabled:opacity-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2 text-olive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
									id,
									className: "size-4"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-fg",
									children: g.name
								})]
							})
						}, id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: resolved !== "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: next,
					children: "Siguiente"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => {
						setResolved("revealed");
						setSequence(challenge.sequence);
						setModes(challenge.modes);
						playSound("toggle");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}), "Revelar"]
				})
			})
		]
	});
}
function CipherCompare({ target, current, match }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-muted uppercase",
				children: "Cifrado buscado"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs leading-relaxed break-all",
				children: target
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("space-y-2 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]", match && "ring-2 ring-olive/45"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-muted uppercase",
				children: "Tu cifrado"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs leading-relaxed break-all text-olive",
				children: current || "—"
			})]
		})]
	});
}
//#endregion
export { Iniciacion as component };
