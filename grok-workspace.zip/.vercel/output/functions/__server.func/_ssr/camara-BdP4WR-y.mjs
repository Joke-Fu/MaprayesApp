import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as notify, o as playSound, s as useSession } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { n as looksLikeMaprayes, t as QrScanner } from "./qr-scanner-DrWT5lhR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/camara-BdP4WR-y.js
var import_jsx_runtime = require_jsx_runtime();
function Camara() {
	const navigate = useNavigate();
	const setPendingCipher = useSession((s) => s.setPendingCipher);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Cámara",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Apunta al código para traducirlo. El mensaje —y los guardianes, si van en el prefijo— se abrirán en el traductor."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrScanner, {
				variant: "page",
				onScan: (text) => {
					playSound("scan");
					notify(looksLikeMaprayes(text) ? "Código Maprayés leído." : "Código leído.", "yudmiry");
					setPendingCipher(text);
					navigate({ to: "/traductor" });
				}
			})]
		})
	});
}
//#endregion
export { Camara as component };
