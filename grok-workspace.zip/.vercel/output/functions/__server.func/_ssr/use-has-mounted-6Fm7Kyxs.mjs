import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-has-mounted-6Fm7Kyxs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useHasMounted() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	return mounted;
}
//#endregion
export { useHasMounted as t };
