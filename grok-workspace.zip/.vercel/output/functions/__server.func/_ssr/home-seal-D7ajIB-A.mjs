import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-seal-D7ajIB-A.js
var import_jsx_runtime = require_jsx_runtime();
function HomeSeal({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 120",
		className,
		"aria-hidden": "true",
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "46",
				stroke: "currentColor",
				strokeWidth: "1.2",
				opacity: "0.7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "32",
				stroke: "currentColor",
				strokeWidth: "0.8",
				opacity: "0.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "6",
				fill: "currentColor",
				opacity: "0.85"
			}),
			Array.from({ length: 8 }).map((_, i) => {
				const a = i * Math.PI / 4 - Math.PI / 2;
				const x1 = 60 + Math.cos(a) * 14;
				const y1 = 60 + Math.sin(a) * 14;
				const x2 = 60 + Math.cos(a) * 44;
				const y2 = 60 + Math.sin(a) * 44;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1,
					y1,
					x2,
					y2,
					stroke: "currentColor",
					strokeWidth: "1.1",
					opacity: "0.65"
				}, i);
			})
		]
	});
}
//#endregion
export { HomeSeal as t };
