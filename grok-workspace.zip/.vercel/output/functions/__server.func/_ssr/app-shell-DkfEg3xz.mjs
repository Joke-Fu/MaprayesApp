import { r as useRoom, t as cn } from "./room-BKUs9KcL.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { w as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-DkfEg3xz.js
var import_jsx_runtime = require_jsx_runtime();
function AppShell({ title, wide, backTo = "/", children }) {
	const roomCode = useRoom((s) => s.code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-30 border-b border-border/70 bg-bg/85 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mx-auto flex h-14 items-center gap-3 px-4", wide ? "max-w-3xl" : "max-w-lg"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: backTo,
						className: "inline-flex h-11 items-center gap-1.5 rounded-md px-2 text-fg transition-colors duration-150 hover:bg-surface",
						"aria-label": "Regresar",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							children: "Atrás"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate font-display text-lg font-medium tracking-tight",
						children: title
					}),
					roomCode && title !== "Sala" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sala",
						className: "ml-auto truncate font-mono text-xs tracking-wide text-olive",
						children: roomCode
					}) : null
				]
			})
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: cn("mx-auto w-full flex-1 px-5 py-6", wide ? "max-w-3xl" : "max-w-lg"),
			children
		})]
	});
}
//#endregion
export { AppShell as t };
