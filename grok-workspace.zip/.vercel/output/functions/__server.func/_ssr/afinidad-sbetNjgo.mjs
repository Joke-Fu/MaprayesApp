import { o as __toESM } from "../_runtime.mjs";
import { i as GUARDIAN_IDS, r as GUARDIANS } from "./guardians-DdPXp9oS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Button, o as playSound, r as GuardianSigil } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { i as useAffinity, n as parsePairKey, t as maxValue } from "./affinity-BV43GLWo.mjs";
import { t as useHasMounted } from "./use-has-mounted-6Fm7Kyxs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/afinidad-sbetNjgo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SIZE = 320;
var CX = 160;
var CY = 156;
var RING = 112;
function nodes() {
	return GUARDIAN_IDS.map((id, i) => {
		const a = i / GUARDIAN_IDS.length * Math.PI * 2 - Math.PI / 2;
		return {
			id,
			x: CX + Math.cos(a) * RING,
			y: CY + Math.sin(a) * RING,
			lx: CX + Math.cos(a) * 140,
			ly: CY + Math.sin(a) * 140
		};
	});
}
function Afinidad() {
	const mounted = useHasMounted();
	const counts = useAffinity((s) => s.counts);
	const pairs = useAffinity((s) => s.pairs);
	const forget = useAffinity((s) => s.forget);
	const [armed, setArmed] = (0, import_react.useState)(false);
	const sky = (0, import_react.useMemo)(() => nodes(), []);
	const pairEntries = (0, import_react.useMemo)(() => {
		return Object.entries(pairs).map(([key, n]) => {
			const parsed = parsePairKey(key);
			if (!parsed || n <= 0) return null;
			return {
				key,
				a: parsed[0],
				b: parsed[1],
				n
			};
		}).filter((v) => v != null).sort((x, y) => y.n - x.n);
	}, [pairs]);
	const maxPair = maxValue(pairEntries.map((p) => p.n));
	const maxCount = maxValue(GUARDIAN_IDS.map((id) => counts[id] ?? 0));
	const hasLazos = mounted && pairEntries.length > 0;
	const byId = Object.fromEntries(sky.map((n) => [n.id, n]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Mapa de afinidad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Cada vez que dos o más guardianes custodian un mismo mensaje, se teje un hilo. El cielo recuerda quiénes viajan juntos."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: `0 0 ${SIZE} 344`,
						role: "img",
						"aria-label": "Constelación de guardianes",
						className: "mx-auto block w-full max-w-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: "Constelación de afinidad" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: CX,
								cy: CY,
								r: RING,
								fill: "none",
								stroke: "currentColor",
								strokeOpacity: "0.08"
							}),
							hasLazos ? pairEntries.map((edge) => {
								const na = byId[edge.a];
								const nb = byId[edge.b];
								if (!na || !nb) return null;
								const t = edge.n / maxPair;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: na.x,
									y1: na.y,
									x2: nb.x,
									y2: nb.y,
									stroke: "var(--khaki)",
									strokeWidth: 1 + t * 4,
									strokeOpacity: .22 + t * .62,
									strokeLinecap: "round"
								}, edge.key);
							}) : null,
							sky.map((node) => {
								const n = mounted ? counts[node.id] ?? 0 : 0;
								const t = maxCount > 0 ? n / maxCount : 0;
								const r = 11 + t * 9;
								const accent = GUARDIANS[node.id].accent;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
										cx: node.x,
										cy: node.y,
										r: r + 4,
										fill: accent,
										fillOpacity: .12 + t * .18
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
										cx: node.x,
										cy: node.y,
										r,
										fill: "var(--surface)",
										stroke: accent,
										strokeWidth: 1.5
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("foreignObject", {
										x: node.x - 8,
										y: node.y - 8,
										width: 16,
										height: 16,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex size-4 items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
												id: node.id,
												className: "size-4 text-olive"
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: node.lx,
										y: node.ly,
										textAnchor: "middle",
										dominantBaseline: "middle",
										fill: "var(--muted)",
										fontSize: "9",
										fontFamily: "var(--font-sans)",
										children: GUARDIANS[node.id].initials
									})
								] }, node.id);
							})
						]
					})
				}),
				hasLazos ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-medium",
						children: "Lazos más densos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: pairEntries.slice(0, 6).map((edge) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 rounded-lg bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
										id: edge.a,
										className: "size-4 text-olive"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: GUARDIANS[edge.a].name }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
										id: edge.b,
										className: "size-4 text-olive"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: GUARDIANS[edge.b].name })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-xs text-muted",
								children: edge.n
							})]
						}, edge.key))
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center font-display text-sm italic text-muted",
					children: "Los guardianes aún no han tejido lazos. Elige dos o más en el traductor."
				}),
				hasLazos ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pt-2 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: () => {
							if (!armed) {
								setArmed(true);
								return;
							}
							forget();
							setArmed(false);
							playSound("clear");
						},
						children: armed ? "Confirmar olvido" : "Olvidar lazos"
					})
				}) : null
			]
		})
	});
}
//#endregion
export { Afinidad as component };
