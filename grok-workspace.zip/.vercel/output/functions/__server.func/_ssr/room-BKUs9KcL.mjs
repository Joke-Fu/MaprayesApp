import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DBMGGiUk.js
var useSettings = create()(persist((set, get) => ({
	theme: "light",
	textSize: "normal",
	font: "normal",
	showCounters: false,
	soundEnabled: true,
	guardianTheme: true,
	favorites: [],
	primordialUnlocked: false,
	chaosFontUnlocked: false,
	setTheme: (theme) => set({ theme }),
	setTextSize: (textSize) => set({ textSize }),
	setFont: (font) => set({ font }),
	setShowCounters: (showCounters) => set({ showCounters }),
	setSoundEnabled: (soundEnabled) => set({ soundEnabled }),
	setGuardianTheme: (guardianTheme) => set({ guardianTheme }),
	toggleFavorite: (code) => {
		const current = get().favorites;
		set({ favorites: current.includes(code) ? current.filter((c) => c !== code) : [...current, code] });
	},
	unlockPrimordial: () => set({ primordialUnlocked: true }),
	unlockChaosFont: () => set({ chaosFontUnlocked: true })
}), {
	name: "maprayes-settings",
	partialize: (s) => ({
		theme: s.theme,
		textSize: s.textSize,
		font: s.font,
		showCounters: s.showCounters,
		soundEnabled: s.soundEnabled,
		guardianTheme: s.guardianTheme,
		favorites: s.favorites,
		primordialUnlocked: s.primordialUnlocked,
		chaosFontUnlocked: s.chaosFontUnlocked
	})
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/room-BKUs9KcL.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function generateRoomCode() {
	let body = "";
	for (let i = 0; i < 4; i += 1) body += ALPHABET[Math.floor(Math.random() * 32)];
	return `MAP-${body}`;
}
/** Accepts `MAP-7X3K`, `map 7x3k`, or just `7X3K`. */
function parseRoomCode(raw) {
	const s = raw.trim().toUpperCase().replace(/[\s_]+/g, "");
	const withPrefix = s.startsWith("MAP-") || s.startsWith("MAP") ? s.replace(/^MAP-?/, "MAP-") : `MAP-${s}`;
	if (/^MAP-[A-Z0-9]{4}$/.test(withPrefix)) return withPrefix;
	return null;
}
function inviteText(code) {
	return `Entra a mi sala Maprayés: ${code}`;
}
function cleanName(name) {
	return name.trim().slice(0, 24) || "Viajero";
}
var useRoom = create()(persist((set, get) => ({
	name: "Viajero",
	view: "plain",
	code: null,
	isHost: false,
	selfId: null,
	joined: false,
	peers: [],
	plain: "",
	origin: "local",
	setName: (name) => set({ name: cleanName(name) }),
	setView: (view) => set({ view }),
	createRoom: () => {
		const code = generateRoomCode();
		set({
			code,
			isHost: true,
			joined: false,
			peers: [],
			selfId: null,
			plain: get().plain,
			origin: "local"
		});
		return code;
	},
	joinRoom: (raw) => {
		const code = parseRoomCode(raw);
		if (!code) return null;
		set({
			code,
			isHost: false,
			joined: false,
			peers: [],
			selfId: null,
			plain: "",
			origin: "local"
		});
		return code;
	},
	leaveRoom: () => set({
		code: null,
		isHost: false,
		joined: false,
		peers: [],
		selfId: null
	}),
	setMesh: (patch) => set(patch),
	setLocalPlain: (plain) => {
		const cur = get();
		if (cur.plain === plain && cur.origin === "local") return;
		set({
			plain,
			origin: "local"
		});
	},
	setRemotePlain: (plain) => set({
		plain,
		origin: "remote"
	})
}), {
	name: "maprayes-room",
	partialize: (s) => ({
		name: s.name,
		view: s.view
	})
}));
//#endregion
export { useSettings as i, inviteText as n, useRoom as r, cn as t };
