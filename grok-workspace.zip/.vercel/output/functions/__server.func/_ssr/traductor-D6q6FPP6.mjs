import { o as __toESM } from "../_runtime.mjs";
import { d as isFullAlignment, i as GUARDIAN_IDS, p as mythicPower, r as GUARDIANS, u as isDualMode } from "./guardians-DdPXp9oS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as useSettings, r as useRoom, t as cn } from "./room-BKUs9KcL.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as Eraser, s as Share2, t as X, u as QrCode, v as Download, x as Camera } from "../_libs/lucide-react.mjs";
import { i as Button, n as notify, o as playSound, r as GuardianSigil, s as useSession } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { i as encodeWithGuardians, n as decodeWithGuardians, o as parseMythicPrefix, t as buildQrPayload } from "./cipher-C9E6kqVb.mjs";
import { i as useAffinity, r as shouldRecordAffinity } from "./affinity-BV43GLWo.mjs";
import { t as Switch } from "./switch-D6lyiARv.mjs";
import { n as looksLikeMaprayes, t as QrScanner } from "./qr-scanner-DrWT5lhR.mjs";
import { i as shareText, n as ShareButton, r as shareFiles, t as CopyButton } from "./share-button-RZBJH7Si.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/traductor-D6q6FPP6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QrPanel({ cleanCode }) {
	const sequence = useSession((s) => s.sequence);
	const modes = useSession((s) => s.modes);
	const farewellText = useSession((s) => s.farewellText);
	const setFarewell = useSession((s) => s.setFarewell);
	const [dataUrl, setDataUrl] = (0, import_react.useState)(null);
	const [payload, setPayload] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!farewellText) return;
		render(farewellText);
	}, [farewellText]);
	async function render(text) {
		try {
			const url = await (await import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default.toDataURL(text, {
				width: 280,
				margin: 2,
				color: {
					dark: "#2A261F",
					light: "#F6EEE2"
				},
				errorCorrectionLevel: "M"
			});
			setDataUrl(url);
			setPayload(text);
		} catch {
			playSound("error");
			notify("No se pudo generar el código.", "triczy");
		}
	}
	async function generate() {
		if (!cleanCode) {
			playSound("error");
			notify("Escribe un texto primero.");
			return;
		}
		setFarewell(null);
		await render(buildQrPayload(cleanCode, sequence, modes));
		playSound("qr");
		notify("Código listo para compartir.", "lino");
	}
	function clear() {
		setDataUrl(null);
		setPayload("");
		setFarewell(null);
	}
	async function shareQr() {
		if (!payload) {
			playSound("error");
			notify("Genera un código primero.");
			return;
		}
		let result = "fail";
		if (dataUrl) try {
			const blob = await (await fetch(dataUrl)).blob();
			const file = new File([blob], "maprayes.png", { type: "image/png" });
			result = await shareFiles([file], payload);
		} catch {
			result = await shareText(payload);
		}
		else result = await shareText(payload);
		if (result === "cancel") return;
		if (result === "fail") {
			playSound("error");
			notify("No se pudo compartir.", "triczy");
			return;
		}
		playSound("share");
		notify(result === "shared" ? "Elige WhatsApp, Messenger o Bluetooth en la hoja del sistema." : "Payload copiado.", "lino");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					onClick: () => void generate(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {}), "Generar código"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: clear,
					children: "Limpiar"
				}),
				payload ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
					value: payload,
					label: "Copiar payload"
				}) : null,
				payload ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					onClick: () => void shareQr(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), "Compartir"]
				}) : null,
				dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: dataUrl,
						download: "maprayes.png",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Descargar"]
					})
				}) : null
			]
		}), dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				sequence.length > 0 && !farewellText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center justify-center gap-2 text-olive",
					children: sequence.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
							id,
							className: "size-4"
						}), GUARDIANS[id].initials]
					}, id))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: dataUrl,
					alt: "Código Maprayés",
					width: 220,
					height: 220,
					className: "rounded-md outline outline-1 -outline-offset-1 outline-black/10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-center font-mono text-xs break-all text-muted",
					children: payload
				})
			]
		}) : null]
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("w-full min-h-32 resize-y rounded-md bg-surface px-3 py-3 text-fg shadow-[var(--shadow-border)] placeholder:text-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-olive/40", className),
		...props
	});
}
function Traductor() {
	const [plain, setPlain] = (0, import_react.useState)("");
	const [cipherIn, setCipherIn] = (0, import_react.useState)("");
	const [scannerOpen, setScannerOpen] = (0, import_react.useState)(false);
	const sequence = useSession((s) => s.sequence);
	const modes = useSession((s) => s.modes);
	const pendingCipher = useSession((s) => s.pendingCipher);
	const setPendingCipher = useSession((s) => s.setPendingCipher);
	const roomCode = useRoom((s) => s.code);
	const roomPlain = useRoom((s) => s.plain);
	const roomOrigin = useRoom((s) => s.origin);
	const setLocalPlain = useRoom((s) => s.setLocalPlain);
	const roomView = useRoom((s) => s.view);
	const setRoomView = useRoom((s) => s.setView);
	const roomPeers = useRoom((s) => s.peers);
	const showCounters = useSettings((s) => s.showCounters);
	const invalidOnce = (0, import_react.useRef)(false);
	const skipDecodeSound = (0, import_react.useRef)(false);
	const firstEncode = (0, import_react.useRef)(true);
	const firstDecode = (0, import_react.useRef)(true);
	const lastAffinityKey = (0, import_react.useRef)("");
	const encoded = (0, import_react.useMemo)(() => {
		if (!plain.trim()) return {
			code: "",
			invalid: false
		};
		return encodeWithGuardians(plain, sequence, modes);
	}, [
		plain,
		sequence,
		modes
	]);
	const decoded = (0, import_react.useMemo)(() => {
		if (!cipherIn.trim()) return {
			text: "",
			parsed: null
		};
		return decodeWithGuardians(cipherIn, sequence, modes);
	}, [
		cipherIn,
		sequence,
		modes
	]);
	(0, import_react.useEffect)(() => {
		if (!pendingCipher) return;
		skipDecodeSound.current = true;
		setCipherIn(pendingCipher);
		setPendingCipher(null);
	}, [pendingCipher, setPendingCipher]);
	const skipRoomEcho = (0, import_react.useRef)(false);
	const roomSeeded = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!roomCode) {
			roomSeeded.current = false;
			return;
		}
		if (roomSeeded.current) return;
		roomSeeded.current = true;
		if (roomPlain && !plain) {
			skipRoomEcho.current = true;
			firstEncode.current = true;
			setPlain(roomPlain);
		}
	}, [
		roomCode,
		roomPlain,
		plain
	]);
	(0, import_react.useEffect)(() => {
		if (!roomCode) return;
		if (roomOrigin !== "remote") return;
		if (roomPlain === plain) return;
		skipRoomEcho.current = true;
		firstEncode.current = true;
		setPlain(roomPlain);
	}, [
		roomCode,
		roomOrigin,
		roomPlain,
		plain
	]);
	(0, import_react.useEffect)(() => {
		if (!roomCode) return;
		if (skipRoomEcho.current) {
			skipRoomEcho.current = false;
			return;
		}
		const id = window.setTimeout(() => setLocalPlain(plain), 180);
		return () => window.clearTimeout(id);
	}, [
		plain,
		roomCode,
		setLocalPlain
	]);
	(0, import_react.useEffect)(() => {
		const parsed = parseMythicPrefix(cipherIn);
		if (parsed.sequence.length === 0) return;
		const current = useSession.getState();
		if (current.sequence.join() === parsed.sequence.join() && JSON.stringify(current.modes) === JSON.stringify(parsed.modes)) return;
		current.adoptSequence(parsed.sequence, parsed.modes);
	}, [cipherIn]);
	(0, import_react.useEffect)(() => {
		if (encoded.invalid && !invalidOnce.current) {
			invalidOnce.current = true;
			notify("Algunos caracteres no tienen código.", "escrimedes");
		}
		if (!encoded.invalid) invalidOnce.current = false;
	}, [encoded.invalid]);
	(0, import_react.useEffect)(() => {
		if (firstEncode.current) {
			firstEncode.current = false;
			return;
		}
		if (!encoded.code) return;
		const id = window.setTimeout(() => playSound("translate"), 420);
		return () => window.clearTimeout(id);
	}, [encoded.code]);
	(0, import_react.useEffect)(() => {
		if (firstDecode.current) {
			firstDecode.current = false;
			return;
		}
		if (!decoded.text) return;
		if (skipDecodeSound.current) {
			skipDecodeSound.current = false;
			return;
		}
		const id = window.setTimeout(() => playSound("decode"), 420);
		return () => window.clearTimeout(id);
	}, [decoded.text]);
	(0, import_react.useEffect)(() => {
		if (!shouldRecordAffinity(sequence, plain)) return;
		if (!encoded.code) return;
		const key = sequence.join(",");
		if (key === lastAffinityKey.current) return;
		lastAffinityKey.current = key;
		useAffinity.getState().record(sequence);
	}, [
		plain,
		sequence,
		encoded.code
	]);
	const aligned = isFullAlignment(sequence, modes);
	const power = mythicPower(sequence, modes);
	function applyScan(text) {
		skipDecodeSound.current = true;
		setCipherIn(text);
		setScannerOpen(false);
		playSound("scan");
		notify(looksLikeMaprayes(text) ? "Código Maprayés leído." : "Código leído.", "yudmiry");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Traductor",
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-10",
			children: [
				roomCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomStrip, {
					code: roomCode,
					peers: roomPeers.filter((p) => p.connectionState === "connected").length,
					view: roomView,
					onView: setRoomView
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: "Texto a Maprayés"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "inputText",
							value: plain,
							onChange: setPlain,
							placeholder: "Escribe tu texto aquí…",
							showCount: showCounters,
							emphasize: !!roomCode && roomView === "plain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "maprayesOutput",
							value: encoded.code,
							readOnly: true,
							placeholder: "Resultado en Maprayés…",
							showCount: showCounters,
							emphasize: !!roomCode && roomView === "cipher"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									value: encoded.code,
									label: "Copiar código"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareButton, {
									value: encoded.code,
									label: "Compartir"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "sm",
									onClick: () => setPlain("Hola, guardianes."),
									children: "Probar un saludo"
								})
							]
						}),
						aligned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-center text-sm italic text-olive",
							children: "Mensaje en Maprayés Primordial"
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianRack, {}),
				sequence.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Poder mítico" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [power, "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("h-full rounded-full bg-olive transition-[width] duration-500", sequence.includes("triczy") && "bg-[color:var(--g-triczy)]"),
							style: { width: `${power}%` }
						})
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrPanel, { cleanCode: encoded.code }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-medium",
								children: "Maprayés a texto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: () => setScannerOpen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), "Leer código"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "inputMaprayes",
							value: cipherIn,
							onChange: setCipherIn,
							placeholder: "Pega un código Maprayés — con o sin prefijo MYTHIC…",
							showCount: showCounters
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "textoOutput",
							value: decoded.text,
							readOnly: true,
							placeholder: "Texto traducido…",
							showCount: showCounters
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								value: decoded.text,
								label: "Copiar texto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareButton, {
								value: decoded.text,
								label: "Compartir"
							})]
						})
					]
				})
			]
		}), scannerOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrScanner, {
			onScan: applyScan,
			onClose: () => setScannerOpen(false)
		}) : null]
	});
}
function RoomStrip({ code, peers, view, onView }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-2 rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/sala",
				className: "font-mono text-sm tracking-wide text-olive",
				children: code
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: peers === 0 ? "Esperando…" : `${peers + 1} en la sala`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onView("plain"),
					className: cn("h-8 rounded-md px-2.5 text-xs font-medium", view === "plain" ? "bg-olive text-olive-fg" : "bg-surface-2 text-fg"),
					children: "Texto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onView("cipher"),
					className: cn("h-8 rounded-md px-2.5 text-xs font-medium", view === "cipher" ? "bg-olive text-olive-fg" : "bg-surface-2 text-fg"),
					children: "Cifrado"
				})]
			})
		]
	});
}
function Field({ id, value, onChange, placeholder, readOnly, showCount, emphasize }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				id,
				value,
				readOnly,
				placeholder,
				onChange: (e) => onChange?.(e.target.value),
				className: cn("pr-10", readOnly && "opacity-90", emphasize && "ring-2 ring-olive/45")
			}),
			value && onChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute top-2 right-2 inline-flex size-9 items-center justify-center rounded-md text-muted hover:text-fg",
				"aria-label": "Limpiar",
				onClick: () => onChange(""),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			}) : null,
			showCount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-right text-xs tabular-nums text-muted",
				children: [value.length, " caracteres"]
			}) : null
		]
	});
}
function GuardianRack() {
	const sequence = useSession((s) => s.sequence);
	const modes = useSession((s) => s.modes);
	const addGuardian = useSession((s) => s.addGuardian);
	const removeGuardian = useSession((s) => s.removeGuardian);
	const clearGuardians = useSession((s) => s.clearGuardians);
	const setMode = useSession((s) => s.setMode);
	function handleAdd(id) {
		const result = addGuardian(id);
		if (result === "already") {
			playSound("error");
			notify("Ese guardián ya custodia este mensaje.", id);
			return;
		}
		if (result === "limit") {
			playSound("error");
			notify("El equilibrio se rompe. Maprayés rechaza más de seis… a menos que conozcas el orden antiguo.", "escrimedes", 3600);
			return;
		}
		if (result === "chaos") {
			playSound("chaos");
			notify("Triczy ha tomado el control. Los otros huyen aterrorizados.", "chaos", 4200);
			return;
		}
		if (result === "primordial") {
			playSound("primordial");
			notify("Los ocho se han alineado. El velo se adelgaza… Maprayés recuerda su origen.", "full", 7e3);
			return;
		}
		playSound("guardian-add", { guardian: id });
		notify(GUARDIANS[id].addPhrase, id);
	}
	function handleRemove(index) {
		const id = removeGuardian(index);
		if (id) {
			playSound("guardian-remove", { guardian: id });
			notify(GUARDIANS[id].removePhrase, id);
		}
	}
	function handleMode(id, plus) {
		const result = setMode(id, plus);
		playSound(result === "primordial" ? "primordial" : "guardian-mode", { guardian: id });
		if (result === "primordial") notify("Los ocho se han alineado. El velo se adelgaza… Maprayés recuerda su origen.", "full", 7e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Guardianes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Cada uno desplaza el alfabeto. Máximo seis, salvo el rito antiguo."
				})] }), sequence.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: () => {
						clearGuardians();
						playSound("clear");
						notify("Guardianes liberados. Sin rastros.", "escrimedes");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}), "Limpiar"]
				}) : null]
			}),
			sequence.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: sequence.map((id, i) => {
					const g = GUARDIANS[id];
					const plus = modes[id] !== false;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex min-h-12 items-center gap-3 rounded-lg bg-surface px-3 py-2 shadow-[var(--shadow-border)]",
						style: { borderLeft: `3px solid ${g.accent}` },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
								id,
								className: "size-5 text-olive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 font-medium",
								children: g.name
							}),
							isDualMode(id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: plus,
									onCheckedChange: (v) => handleMode(id, v),
									"aria-label": g.name
								}), plus ? g.plusLabel : g.minusLabel]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tabular-nums text-muted",
								children: g.displacement
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-10 items-center justify-center rounded-md text-muted hover:text-fg",
								"aria-label": `Quitar ${g.name}`,
								onClick: () => handleRemove(i),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					}, `${id}-${i}`);
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: GUARDIAN_IDS.map((id) => {
					const g = GUARDIANS[id];
					const taken = sequence.includes(id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: taken,
						onClick: () => handleAdd(id),
						className: "flex min-h-14 flex-col items-start gap-1 rounded-lg bg-surface px-3 py-2.5 text-left shadow-[var(--shadow-border)] transition-transform duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--fg)_16%,transparent)] active:scale-[0.98] disabled:opacity-40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 text-olive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
								id,
								className: "size-4"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-fg",
								children: g.name
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.7rem] text-muted",
							children: g.displacement
						})]
					}, id);
				})
			})
		]
	});
}
//#endregion
export { Traductor as component };
