import { i as GUARDIAN_IDS, l as isChaosCombo, r as GUARDIANS, u as isDualMode } from "./guardians-DdPXp9oS.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { r as ALFABETO, s as LETTERS } from "./alphabet-DP9zcs2T.mjs";
import { i as encodeWithGuardians, r as encodeToMaprayes } from "./cipher-C9E6kqVb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/iniciacion-nmFQ5Xo3.js
/** Practice corpus for Iniciación. Only characters that exist in the codebook. */
var WORDS = {
	facil: [
		"sol",
		"gato",
		"luna",
		"casa",
		"mar",
		"pan",
		"luz",
		"flor",
		"río",
		"nido",
		"oro",
		"miel",
		"paz",
		"fuego",
		"vino"
	],
	medio: [
		"umbral",
		"velo",
		"sigilo",
		"portal",
		"linterna",
		"sendero",
		"eclipse",
		"susurro",
		"brújula",
		"fogata",
		"custodio",
		"cifrado",
		"espejo",
		"jaguar",
		"reliquia"
	],
	dificil: [
		"maprayés",
		"primordial",
		"alineación",
		"constelación",
		"transfigurar",
		"oráculo",
		"manuscrito",
		"crepúsculo",
		"laberinto",
		"desplazamiento",
		"efervescencia",
		"arquitectura",
		"guardián",
		"volcán",
		"transmutar"
	]
};
var PHRASES = {
	facil: [
		"hola mundo",
		"el gato duerme",
		"luz de luna",
		"pan y miel",
		"mar en calma",
		"nido de oro",
		"fuego lento",
		"casa de sol"
	],
	medio: [
		"el velo se abre",
		"bajo la linterna",
		"un portal oculto",
		"susurro del umbral",
		"brújula de arena",
		"el espejo miente",
		"fogata en el sendero",
		"custodio del cifrado"
	],
	dificil: [
		"el maprayés recuerda",
		"la alineación se cumple",
		"constelación de voluntades",
		"el oráculo no calla",
		"transfigurar el velo",
		"manuscrito primordial",
		"el crepúsculo guarda signos",
		"laberinto de reliquias"
	]
};
var DRILL_KINDS = [
	"letras",
	"numeros",
	"simbolos",
	"palabras",
	"frases"
];
var LEVEL_LABEL = {
	facil: "Fácil",
	medio: "Medio",
	dificil: "Difícil",
	extremo: "Extremo",
	libre: "Modo Libre"
};
var KIND_LABEL = {
	letras: "Letras",
	numeros: "Números",
	simbolos: "Símbolos",
	palabras: "Palabras",
	frases: "Frases"
};
var LEVEL_HINT$1 = {
	facil: "El primer aliento del código.",
	medio: "El velo ya pide atención.",
	dificil: "Frases y signos que no perdonan.",
	extremo: "No se escribe: se convoca.",
	libre: "Elige el material. El ritmo es tuyo."
};
var DIGITS = "0123456789";
var SYMBOLS = Object.values(ALFABETO).filter((ch) => !/^[A-ZÁÉÍÓÚÑ0-9]$/.test(ch) && ch !== " " && ch !== "...").join("");
var LENGTHS = {
	facil: {
		letras: 1,
		numeros: 1,
		simbolos: 1,
		palabras: 1,
		frases: 1
	},
	medio: {
		letras: 3,
		numeros: 2,
		simbolos: 2,
		palabras: 1,
		frases: 1
	},
	dificil: {
		letras: 5,
		numeros: 4,
		simbolos: 3,
		palabras: 1,
		frases: 1
	},
	libre: {
		letras: 4,
		numeros: 3,
		simbolos: 2,
		palabras: 1,
		frases: 1
	}
};
function normalizePractice(value) {
	return value.trim().replace(/\s+/g, " ").toLocaleUpperCase("es-MX");
}
function answersMatch(expected, given) {
	return normalizePractice(expected) === normalizePractice(given);
}
function corpusLevel(level) {
	if (level === "dificil") return "dificil";
	if (level === "medio") return "medio";
	return "facil";
}
function pickFrom(items, used, key) {
	const unused = items.filter((item) => !used.has(key(item)));
	const pool = unused.length > 0 ? unused : [...items];
	const item = pool[Math.floor(Math.random() * pool.length)];
	if (item === void 0) throw new Error("empty pool");
	used.add(key(item));
	return item;
}
function randomGlyphs(alphabet, count) {
	let out = "";
	for (let i = 0; i < count; i += 1) {
		const ch = alphabet[Math.floor(Math.random() * alphabet.length)];
		if (ch) out += ch;
	}
	return out;
}
function wordPool(level) {
	if (level === "libre") return [
		...WORDS.facil,
		...WORDS.medio,
		...WORDS.dificil
	];
	return WORDS[corpusLevel(level)];
}
function phrasePool(level) {
	if (level === "libre") return [
		...PHRASES.facil,
		...PHRASES.medio,
		...PHRASES.dificil
	];
	return PHRASES[corpusLevel(level)];
}
function makeDrillPrompt(level, kind, used) {
	const n = LENGTHS[level][kind];
	let plaintext = "";
	if (kind === "letras") plaintext = randomGlyphs(LETTERS, n);
	else if (kind === "numeros") plaintext = randomGlyphs(DIGITS, n);
	else if (kind === "simbolos") plaintext = randomGlyphs(SYMBOLS, n);
	else if (kind === "palabras") plaintext = pickFrom(wordPool(level), used, (w) => `w:${w}`);
	else plaintext = pickFrom(phrasePool(level), used, (p) => `p:${p}`);
	const { code } = encodeToMaprayes(plaintext);
	return {
		kind,
		plaintext,
		cipher: code
	};
}
function randomModes(id) {
	if (!isDualMode(id)) return true;
	return Math.random() < .5;
}
function randomSequence(size) {
	const sequence = [...GUARDIAN_IDS].sort(() => Math.random() - .5).slice(0, size);
	const modes = {};
	for (const id of sequence) modes[id] = randomModes(id);
	return {
		sequence,
		modes
	};
}
function makeExtremoChallenge(used) {
	const plaintext = pickFrom([
		...PHRASES.medio,
		...PHRASES.dificil,
		...WORDS.dificil
	], used, (p) => `x:${p}`);
	const base = encodeToMaprayes(plaintext).code;
	for (let attempt = 0; attempt < 24; attempt += 1) {
		const roll = Math.random();
		const { sequence, modes } = randomSequence(roll < .4 ? 1 : roll < .8 ? 2 : 3);
		if (isChaosCombo(sequence, modes)) continue;
		const { code } = encodeWithGuardians(plaintext, sequence, modes);
		if (!code || code === base) continue;
		return {
			plaintext,
			target: code,
			sequence,
			modes
		};
	}
	const sequence = ["lino"];
	const modes = { lino: true };
	const { code } = encodeWithGuardians(plaintext, sequence, modes);
	return {
		plaintext,
		target: code || base,
		sequence,
		modes
	};
}
var LEVEL_TITLES = {
	facil: {
		10: "Primer aliento",
		25: "Aprendiz del velo",
		50: "Lectura clara",
		75: "Ojo despierto",
		100: "Escriba novicio"
	},
	medio: {
		10: "Paso del umbral",
		25: "Eco doble",
		50: "Manuscrito vivo",
		75: "Traductor errante",
		100: "Custodio menor"
	},
	dificil: {
		10: "Lengua antigua",
		25: "Cifrado profundo",
		50: "Velo rasgado",
		75: "Arquitecto del signo",
		100: "Oráculo del código"
	},
	extremo: {
		10: "Primer pacto",
		25: "Concilio breve",
		50: "Alquimia de voluntades",
		75: "Consejo velado",
		100: "Alineación vivida"
	}
};
var LEVEL_HINT = {
	facil: "Aciertos en Fácil",
	medio: "Aciertos en Medio",
	dificil: "Aciertos en Difícil",
	extremo: "Aciertos en Extremo"
};
var GUARDIAN_RELIC = {
	lino: "Llama fiel",
	garbanza: "Moño de contradicción",
	yudmiry: "Espejo abierto",
	escrimedes: "Tinta eterna",
	oithar: "Vértigo lúcido",
	epheron: "Vela última",
	willy: "Pacto sereno",
	triczy: "Travesura contenida"
};
var THRESHOLDS = [
	10,
	25,
	50,
	75,
	100
];
var GUARDIAN_THRESHOLD = 10;
var RELICS = [...[
	"facil",
	"medio",
	"dificil",
	"extremo"
].flatMap((level) => THRESHOLDS.map((threshold) => ({
	id: `${level}-${threshold}`,
	title: LEVEL_TITLES[level][threshold] ?? `${threshold}`,
	hint: `${LEVEL_HINT[level]}: ${threshold}`,
	kind: "level",
	level,
	threshold
}))), ...GUARDIAN_IDS.map((guardian) => ({
	id: `guardian-${guardian}`,
	title: GUARDIAN_RELIC[guardian],
	hint: `${GUARDIAN_THRESHOLD} aciertos en Extremo con ${GUARDIANS[guardian].name}`,
	kind: "guardian",
	guardian,
	threshold: GUARDIAN_THRESHOLD
}))];
function relicUnlocked(relic, stats) {
	if (relic.kind === "guardian" && relic.guardian) return (stats.guardianHits[relic.guardian] ?? 0) >= relic.threshold;
	if (relic.level) return (stats.hits[relic.level] ?? 0) >= relic.threshold;
	return false;
}
function unlockedCount(stats) {
	return RELICS.filter((relic) => relicUnlocked(relic, stats)).length;
}
var EMPTY_HITS = {
	facil: 0,
	medio: 0,
	dificil: 0,
	extremo: 0,
	libre: 0
};
var useIniciacion = create()(persist((set, get) => ({
	hits: { ...EMPTY_HITS },
	guardianHits: {},
	registerHit: (level) => {
		set({ hits: {
			...get().hits,
			[level]: (get().hits[level] ?? 0) + 1
		} });
	},
	registerExtremo: (sequence) => {
		const hits = {
			...get().hits,
			extremo: (get().hits.extremo ?? 0) + 1
		};
		const guardianHits = { ...get().guardianHits };
		for (const id of new Set(sequence)) guardianHits[id] = (guardianHits[id] ?? 0) + 1;
		set({
			hits,
			guardianHits
		});
	}
}), { name: "maprayes-iniciacion" }));
//#endregion
export { RELICS as a, makeExtremoChallenge as c, useIniciacion as d, LEVEL_LABEL as i, relicUnlocked as l, KIND_LABEL as n, answersMatch as o, LEVEL_HINT$1 as r, makeDrillPrompt as s, DRILL_KINDS as t, unlockedCount as u };
