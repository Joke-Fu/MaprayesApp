import { o as __toESM } from "../_runtime.mjs";
import { r as GUARDIANS } from "./guardians-DdPXp9oS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as inviteText, r as useRoom, t as cn } from "./room-BKUs9KcL.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as ArrowRight, f as LogOut, l as Radio } from "../_libs/lucide-react.mjs";
import { i as Button, n as notify, o as playSound, r as GuardianSigil, s as useSession } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { i as encodeWithGuardians } from "./cipher-C9E6kqVb.mjs";
import { t as Input } from "./input-BtFy7h-C.mjs";
import { n as ShareButton, t as CopyButton } from "./share-button-RZBJH7Si.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sala-BMoteMIA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Sala() {
	const code = useRoom((s) => s.code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Sala",
		children: code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InRoom, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lobby, {})
	});
}
function Lobby() {
	const name = useRoom((s) => s.name);
	const setName = useRoom((s) => s.setName);
	const createRoom = useRoom((s) => s.createRoom);
	const joinRoom = useRoom((s) => s.joinRoom);
	const [joinValue, setJoinValue] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-olive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium text-fg",
						children: "Umbral"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Abre una sala y comparte el código. Los guardianes y el texto del traductor viajan al instante entre quienes cruzan."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: "Tu nombre en la sala"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					maxLength: 24,
					onChange: (e) => setName(e.target.value),
					placeholder: "Viajero"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				className: "w-full",
				onClick: () => {
					const next = createRoom();
					playSound("join");
					notify(`Sala ${next} abierta.`, "yudmiry");
				},
				children: "Crear sala"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Unirse con un código"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: joinValue,
						onChange: (e) => setJoinValue(e.target.value.toUpperCase()),
						placeholder: "MAP-7X3K",
						"aria-label": "Código de sala",
						className: "font-mono tracking-widest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => {
							const joined = joinRoom(joinValue);
							if (!joined) {
								playSound("error");
								notify("Ese código no abre ninguna puerta.", "escrimedes");
								return;
							}
							playSound("join");
							notify(`Cruzando a ${joined}…`, "yudmiry");
						},
						children: "Entrar"
					})]
				})]
			})
		]
	});
}
function InRoom() {
	const code = useRoom((s) => s.code);
	const name = useRoom((s) => s.name);
	const joined = useRoom((s) => s.joined);
	const peers = useRoom((s) => s.peers);
	const view = useRoom((s) => s.view);
	const setView = useRoom((s) => s.setView);
	const plain = useRoom((s) => s.plain);
	const leaveRoom = useRoom((s) => s.leaveRoom);
	const sequence = useSession((s) => s.sequence);
	const modes = useSession((s) => s.modes);
	const encoded = (0, import_react.useMemo)(() => encodeWithGuardians(plain, sequence, modes).code, [
		plain,
		sequence,
		modes
	]);
	const live = view === "cipher" ? encoded : plain;
	const connected = peers.filter((p) => p.connectionState === "connected");
	const failed = peers.filter((p) => p.connectionState === "failed");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface px-5 py-6 text-center shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.28em] text-muted uppercase",
						children: "Código"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-medium tracking-[0.18em]",
						children: code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: joined ? connected.length === 0 ? "Esperando a que alguien cruce…" : `${connected.length + 1} viajeros en el umbral` : "Abriendo el umbral…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
							value: code,
							label: "Copiar código"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareButton, {
							value: inviteText(code),
							label: "Invitar"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: "Eco en vivo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewChip, {
								active: view === "plain",
								onClick: () => setView("plain"),
								children: "Texto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewChip, {
								active: view === "cipher",
								onClick: () => setView("cipher"),
								children: "Cifrado"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("min-h-24 rounded-xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)]", view === "cipher" && "font-mono text-xs break-all"),
						children: live.trim() ? live : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted italic",
							children: "Aún no hay palabras en esta sala. Escríbelas en el traductor."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/traductor",
							children: ["Ir al traductor", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				]
			}),
			sequence.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium",
					children: "Guardianes en curso"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-wrap gap-2",
					children: sequence.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5 rounded-md bg-surface px-2.5 py-1.5 text-xs shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
							id,
							className: "size-3.5 text-olive"
						}), GUARDIANS[id].name]
					}, id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium",
					children: "Presentes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-lg bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]",
							children: [
								name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: "(tú)"
								})
							]
						}),
						connected.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-lg bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]",
							children: [p.name || "Viajero", p.rttMs != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 text-xs text-muted",
								children: [p.rttMs, " ms"]
							}) : null]
						}, p.id)),
						failed.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-lg bg-surface px-3 py-2 text-sm text-muted",
							children: [p.name || "Viajero", " · no se pudo conectar"]
						}, p.id))
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				className: "w-full",
				onClick: () => {
					leaveRoom();
					playSound("clear");
					notify("Has dejado la sala.", "epheron");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {}), "Salir de la sala"]
			})
		]
	});
}
function ViewChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 rounded-md px-3 text-xs font-medium transition-colors duration-150", active ? "bg-olive text-olive-fg" : "bg-surface text-fg shadow-[var(--shadow-border)]"),
		children
	});
}
//#endregion
export { Sala as component };
