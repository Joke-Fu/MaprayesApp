import { o as __toESM } from "../_runtime.mjs";
import { s as WHISPERS } from "./guardians-DdPXp9oS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as ArrowRight, S as BookOpen, T as ArrowLeftRight, a as Sparkles, c as Settings2, d as Orbit, l as Radio, o as Shield, r as Table2, x as Camera } from "../_libs/lucide-react.mjs";
import { t as HomeSeal } from "./home-seal-D7ajIB-A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CI67jVbh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NAV = [
	{
		to: "/traductor",
		label: "Traductor",
		hint: "Texto ↔ código",
		icon: ArrowLeftRight
	},
	{
		to: "/iniciacion",
		label: "Iniciación",
		hint: "Práctica y reliquias",
		icon: Sparkles
	},
	{
		to: "/camara",
		label: "Cámara",
		hint: "Leer un código",
		icon: Camera
	},
	{
		to: "/sala",
		label: "Sala",
		hint: "Conectar viajeros",
		icon: Radio
	},
	{
		to: "/tabla",
		label: "Tabla de códigos",
		hint: "Alfabeto y favoritos",
		icon: Table2
	},
	{
		to: "/guardianes",
		label: "Guardianes",
		hint: "Ocho voluntades",
		icon: Shield
	},
	{
		to: "/afinidad",
		label: "Afinidad",
		hint: "Quiénes viajan juntos",
		icon: Orbit
	},
	{
		to: "/ayuda",
		label: "Ayuda",
		hint: "Uso y lore",
		icon: BookOpen
	},
	{
		to: "/ajustes",
		label: "Ajustes",
		hint: "Tema, tipo, sonido",
		icon: Settings2
	}
];
function Home() {
	const [whisper, setWhisper] = (0, import_react.useState)(WHISPERS[0] ?? "");
	(0, import_react.useEffect)(() => {
		setWhisper(WHISPERS[Math.floor(Math.random() * WHISPERS.length)] ?? "");
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex w-full max-w-lg flex-1 flex-col items-center justify-center px-5 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeSeal, { className: "mb-6 size-24 text-olive" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-[0.7rem] tracking-[0.38em] text-muted uppercase",
					children: "Joke-Fu · 2026"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-5xl font-medium tracking-tight italic",
					children: "Maprayés"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 min-h-6 text-center text-sm text-muted italic",
					children: whisper
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-10 flex w-full flex-col gap-2",
					"aria-label": "Secciones",
					children: NAV.map((item, i) => {
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: "group flex min-h-14 items-center justify-between rounded-xl bg-surface px-5 py-3.5 shadow-[var(--shadow-border)] transition-[transform,box-shadow] duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--fg)_16%,transparent)] active:scale-[0.98]",
							style: { animationDelay: `${i * 40}ms` },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-olive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: item.hint
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted transition-transform duration-150 group-hover:translate-x-0.5" })]
						}, item.to);
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "px-5 pb-8 text-center text-xs text-muted italic",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Maprayés © Joke-Fu 2026" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://github.com/Joke-Fu/maprayes",
					target: "_blank",
					rel: "noreferrer",
					className: "underline decoration-border underline-offset-4 hover:text-olive",
					children: "Ver en GitHub"
				})
			})]
		})]
	});
}
//#endregion
export { Home as component };
