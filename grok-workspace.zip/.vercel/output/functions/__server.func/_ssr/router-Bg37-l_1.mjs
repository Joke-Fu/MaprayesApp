import { o as __toESM } from "../_runtime.mjs";
import { c as canAddGuardian, d as isFullAlignment, l as isChaosCombo, n as EXIT_MESSAGES, t as CHAOS_MESSAGES } from "./guardians-DdPXp9oS.mjs";
import { n as create } from "../_libs/zustand.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as useSettings, r as useRoom, t as cn } from "./room-BKUs9KcL.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as number, c as union, i as literal, l as unknown, n as _enum, o as object, r as discriminatedUnion, s as string, t as number$1 } from "../_libs/zod.mjs";
import { r as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Bg37-l_1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var useSession = create((set, get) => ({
	sequence: [],
	modes: {},
	chaos: "off",
	stability: 100,
	preTheme: "light",
	farewellText: null,
	pendingCipher: null,
	primordialSeen: false,
	addGuardian: (id) => {
		const { sequence, modes, chaos } = get();
		const check = canAddGuardian(sequence, modes, id);
		if (!check.ok) return check.reason;
		const nextSeq = [...sequence, id];
		const nextModes = {
			...modes,
			[id]: true
		};
		set({
			sequence: nextSeq,
			modes: nextModes
		});
		if (isChaosCombo(nextSeq, nextModes) && chaos === "off") {
			get().enterChaos();
			return "chaos";
		}
		if (isFullAlignment(nextSeq, nextModes) && !get().primordialSeen) {
			set({ primordialSeen: true });
			useSettings.getState().unlockPrimordial();
			return "primordial";
		}
		return "ok";
	},
	removeGuardian: (index) => {
		const { sequence, modes } = get();
		const id = sequence[index];
		if (!id) return null;
		const nextSeq = sequence.filter((_, i) => i !== index);
		const nextModes = { ...modes };
		delete nextModes[id];
		set({
			sequence: nextSeq,
			modes: nextModes
		});
		return id;
	},
	clearGuardians: () => set({
		sequence: [],
		modes: {},
		primordialSeen: false
	}),
	setMode: (id, plus) => {
		const nextModes = {
			...get().modes,
			[id]: plus
		};
		set({ modes: nextModes });
		if (isFullAlignment(get().sequence, nextModes) && !get().primordialSeen) {
			set({ primordialSeen: true });
			useSettings.getState().unlockPrimordial();
			return "primordial";
		}
		return "ok";
	},
	adoptSequence: (sequence, modes) => {
		set({
			sequence,
			modes
		});
		if (isChaosCombo(sequence, modes) && get().chaos === "off") get().enterChaos();
		if (isFullAlignment(sequence, modes) && !get().primordialSeen) {
			set({ primordialSeen: true });
			useSettings.getState().unlockPrimordial();
		}
	},
	enterChaos: () => {
		const theme = useSettings.getState().theme;
		set({
			chaos: "active",
			stability: 100,
			preTheme: theme,
			sequence: [
				"triczy",
				"garbanza",
				"lino"
			],
			modes: {
				triczy: true,
				garbanza: true,
				lino: true
			}
		});
	},
	calmChaos: () => {
		const pre = get().preTheme;
		useSettings.getState().setTheme(pre);
		set({ chaos: "residual" });
	},
	releaseChaos: () => {
		const msg = EXIT_MESSAGES[Math.floor(Math.random() * EXIT_MESSAGES.length)] ?? "Triczy se retira… por ahora.";
		set({
			chaos: "off",
			sequence: [],
			modes: {},
			stability: 100,
			farewellText: msg
		});
		return msg;
	},
	tickStability: () => {
		const { chaos, stability } = get();
		if (chaos !== "active") return;
		const next = Math.max(0, stability - 1);
		set({ stability: next });
		if (next === 0) useSettings.getState().unlockChaosFont();
	},
	setFarewell: (farewellText) => set({ farewellText }),
	setPendingCipher: (pendingCipher) => set({ pendingCipher })
}));
function ThemeSync() {
	const theme = useSettings((s) => s.theme);
	const textSize = useSettings((s) => s.textSize);
	const font = useSettings((s) => s.font);
	const primordialUnlocked = useSettings((s) => s.primordialUnlocked);
	const chaosFontUnlocked = useSettings((s) => s.chaosFontUnlocked);
	const guardianTheme = useSettings((s) => s.guardianTheme);
	const chaos = useSession((s) => s.chaos);
	const sequence = useSession((s) => s.sequence);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		root.dataset.theme = theme;
		root.dataset.size = textSize;
		const allowedFont = font === "maprayes" && !primordialUnlocked ? "normal" : font === "caos" && !chaosFontUnlocked ? "normal" : font;
		root.dataset.font = allowedFont;
		if (chaos === "off") delete root.dataset.chaos;
		else root.dataset.chaos = chaos;
		const last = sequence[sequence.length - 1];
		if (guardianTheme && chaos === "off" && last) {
			root.style.setProperty("--olive", `var(--g-${last})`);
			root.dataset.guardian = last;
		} else {
			root.style.removeProperty("--olive");
			delete root.dataset.guardian;
		}
	}, [
		theme,
		textSize,
		font,
		primordialUnlocked,
		chaosFontUnlocked,
		chaos,
		guardianTheme,
		sequence
	]);
	return null;
}
var GUARDIAN_HZ = {
	lino: 196,
	garbanza: 233,
	yudmiry: 261,
	escrimedes: 174,
	oithar: 311,
	epheron: 146,
	willy: 220,
	triczy: 185
};
var ctx = null;
function Ctor() {
	if (typeof window === "undefined") return null;
	return window.AudioContext || window.webkitAudioContext || null;
}
function getCtx() {
	const Audio = Ctor();
	if (!Audio) return null;
	if (!ctx) ctx = new Audio();
	return ctx;
}
function unlockSound() {
	const c = getCtx();
	if (c && c.state === "suspended") c.resume();
}
function tone(c, freq, start, dur, type, gain, slideTo) {
	const osc = c.createOscillator();
	const g = c.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, start);
	if (slideTo !== void 0) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), start + dur);
	g.gain.setValueAtTime(1e-4, start);
	g.gain.exponentialRampToValueAtTime(gain, start + .014);
	g.gain.exponentialRampToValueAtTime(1e-4, start + dur);
	osc.connect(g);
	g.connect(c.destination);
	osc.start(start);
	osc.stop(start + dur + .03);
}
function playSound(kind, extra) {
	if (!useSettings.getState().soundEnabled) return;
	const c = getCtx();
	if (!c) return;
	if (c.state === "suspended") c.resume();
	const t = c.currentTime;
	try {
		switch (kind) {
			case "translate":
				tone(c, 523, t, .09, "triangle", .07);
				tone(c, 659, t + .08, .12, "triangle", .08);
				break;
			case "decode":
				tone(c, 659, t, .09, "triangle", .07);
				tone(c, 494, t + .08, .14, "sine", .08);
				break;
			case "copy":
				tone(c, 880, t, .05, "sine", .05);
				break;
			case "qr":
				tone(c, 196, t, .05, "square", .04);
				tone(c, 784, t + .05, .1, "triangle", .07);
				break;
			case "scan":
				tone(c, 784, t, .08, "sine", .08);
				tone(c, 1046, t + .07, .16, "triangle", .09);
				break;
			case "error":
				tone(c, 110, t, .18, "square", .05);
				break;
			case "guardian-add": {
				const f = GUARDIAN_HZ[extra?.guardian ?? "lino"];
				tone(c, f, t, .14, "triangle", .08);
				tone(c, f * 2, t + .06, .18, "sine", .05);
				break;
			}
			case "guardian-remove": {
				const f = GUARDIAN_HZ[extra?.guardian ?? "lino"];
				tone(c, f, t, .16, "sine", .06, f * .6);
				break;
			}
			case "guardian-mode":
				tone(c, 440, t, .04, "triangle", .05);
				break;
			case "clear":
				tone(c, 330, t, .08, "sine", .05);
				tone(c, 196, t + .09, .14, "sine", .05);
				break;
			case "chaos":
				tone(c, 73, t, .32, "square", .05);
				tone(c, 110, t + .04, .22, "sawtooth", .035);
				tone(c, 311, t + .18, .12, "square", .04);
				break;
			case "primordial":
				tone(c, 261, t, .16, "sine", .07);
				tone(c, 329, t + .12, .16, "sine", .07);
				tone(c, 392, t + .24, .18, "sine", .07);
				tone(c, 523, t + .38, .28, "triangle", .08);
				break;
			case "toggle":
				tone(c, 523, t, .07, "sine", .06);
				tone(c, 784, t + .07, .12, "triangle", .07);
				break;
			case "share":
				tone(c, 392, t, .07, "triangle", .06);
				tone(c, 523, t + .08, .12, "sine", .07);
				break;
			case "join":
				tone(c, 330, t, .1, "sine", .07);
				tone(c, 494, t + .1, .16, "triangle", .08);
		}
	} catch {}
}
function SoundGate() {
	(0, import_react.useEffect)(() => {
		const unlock = () => unlockSound();
		window.addEventListener("pointerdown", unlock, { once: true });
		window.addEventListener("keydown", unlock, { once: true });
		return () => {
			window.removeEventListener("pointerdown", unlock);
			window.removeEventListener("keydown", unlock);
		};
	}, []);
	return null;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-olive/50 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-olive text-olive-fg shadow-sm hover:opacity-90",
			outline: "bg-surface text-fg shadow-[var(--shadow-border)] hover:bg-surface-2",
			ghost: "bg-transparent text-fg hover:bg-surface",
			danger: "bg-transparent text-[color:var(--danger)] hover:bg-surface"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Svg({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-6 shrink-0", className),
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.6",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children
	});
}
function GuardianSigil({ id, className }) {
	switch (id) {
		case "lino": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 26c5 0 8-4 8-9 0-6-5-10-8-13-3 3-8 7-8 13 0 5 3 9 8 9z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 18c0-3 2-5 2-8" })]
		});
		case "garbanza": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "16",
					cy: "18",
					r: "7"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 12c0-4 8-4 8 0" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 5v4" })
			]
		});
		case "yudmiry": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "5"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 16c4-7 20-7 24 0M4 16c4 7 20 7 24 0" })]
		});
		case "escrimedes": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 5h12v22H9z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 10h6M12 15h6M12 20h4" })]
		});
		case "oithar": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 16c2-8 14-8 16 0-2 8-14 8-16 0z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 16c1.5-5 10.5-5 12 0" })]
		});
		case "epheron": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 4c4 6 4 10 0 14-4-4-4-8 0-14z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 26h12c-1-4-4-6-6-6s-5 2-6 6z" })]
		});
		case "willy": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Svg, {
			className,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 26c-6-4-8-10-6-16 3 2 5 2 6 0 1 2 3 2 6 0 2 6 0 12-6 16z" })
		});
		case "triczy": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Svg, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 12c0-4 3-7 8-7s8 3 8 7c0 8-8 15-8 15S8 20 8 12z" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "13",
					cy: "13",
					r: "1.2",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "19",
					cy: "13",
					r: "1.2",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M13 18c2 2 4 2 6 0" })
			]
		});
	}
}
function notify(message, kind = "default", duration = 2400) {
	toast(message, {
		duration,
		className: `map-toast map-toast-${kind}`
	});
}
function ChaosLayer() {
	const chaos = useSession((s) => s.chaos);
	const stability = useSession((s) => s.stability);
	const tickStability = useSession((s) => s.tickStability);
	const calmChaos = useSession((s) => s.calmChaos);
	const releaseChaos = useSession((s) => s.releaseChaos);
	const chaosFontUnlocked = useSettings((s) => s.chaosFontUnlocked);
	const [msg, setMsg] = (0, import_react.useState)("");
	const unlockedToast = (0, import_react.useRef)(false);
	const [pos, setPos] = (0, import_react.useState)({
		x: 72,
		y: 120
	});
	(0, import_react.useEffect)(() => {
		if (chaos === "active" && !msg) setMsg(CHAOS_MESSAGES[Math.floor(Math.random() * CHAOS_MESSAGES.length)] ?? "");
	}, [chaos, msg]);
	(0, import_react.useEffect)(() => {
		if (chaos !== "active") return;
		const id = window.setInterval(tickStability, 300);
		return () => window.clearInterval(id);
	}, [chaos, tickStability]);
	(0, import_react.useEffect)(() => {
		if (chaos === "off") return;
		const ms = chaos === "active" ? 9e3 : 14e3;
		const id = window.setInterval(() => {
			setPos({
				x: 24 + Math.random() * Math.max(40, window.innerWidth - 80),
				y: 80 + Math.random() * Math.max(40, window.innerHeight - 160)
			});
		}, ms);
		return () => window.clearInterval(id);
	}, [chaos]);
	(0, import_react.useEffect)(() => {
		if (stability === 0 && chaos === "active" && chaosFontUnlocked && !unlockedToast.current) {
			unlockedToast.current = true;
			notify("La estabilidad se ha roto. La fuente del caos ahora es tuya.", "chaos", 5e3);
		}
	}, [
		stability,
		chaos,
		chaosFontUnlocked
	]);
	if (chaos === "off") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "chaos-scan" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "chaos-drift text-olive",
			style: {
				left: pos.x,
				top: pos.y
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
				id: "triczy",
				className: "size-8"
			})
		}),
		chaos === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none fixed top-0 right-0 left-0 z-50 px-4 pt-[max(10px,env(safe-area-inset-top))]",
			"aria-label": "Estabilidad",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ml-auto h-1.5 w-28 overflow-hidden rounded-full bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full bg-olive transition-[width] duration-500",
					style: { width: `${stability}%` }
				})
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed right-4 bottom-[max(1.25rem,env(safe-area-inset-bottom))] z-50 flex flex-col items-end gap-2",
			children: [chaos === "active" && msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-[14rem] text-right font-display text-xs italic text-muted",
				children: msg
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-[14rem] text-right font-display text-xs italic text-muted",
				children: "Triczy se esconde… pero aún observa."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				size: "sm",
				onClick: () => {
					if (chaos === "active") {
						calmChaos();
						playSound("clear");
						notify("La calma es solo aparente…", "triczy", 3200);
					} else {
						const farewell = releaseChaos();
						playSound("guardian-remove", { guardian: "triczy" });
						notify(farewell, "triczy", 4e3);
					}
				},
				children: chaos === "active" ? "Calmar a Triczy" : "Liberar por completo"
			})]
		})
	] });
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	constructor(opts) {
		this.opts = opts;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(`/api/rtc?${params}`);
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		if (initiator) {
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch("/api/rtc", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
/**
* React binding for P2PRoom. Identity and room id are captured once on mount
* (useState initializers) so re-renders never tear down the mesh: the P2PRoom
* instance lives exactly as long as the component that mounted it, and
* changing `room`/`name` requires a remount (key the component on them).
*/
function defaultRoom() {
	if (typeof window === "undefined") return "room-ssr";
	return `room-${window.location.hostname.split(".")[0]}`.slice(0, 64);
}
function useP2PRoom(options = {}) {
	const [selfId] = (0, import_react.useState)(() => `p-${Math.random().toString(36).slice(2, 10)}`);
	const [room] = (0, import_react.useState)(() => options.room ?? defaultRoom());
	const [name] = (0, import_react.useState)(() => options.name ?? selfId);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const listeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		const p2p = new P2PRoom({
			room,
			selfId,
			name,
			onPeersChanged: setPeers,
			onMessage: (from, data, channel) => {
				for (const fn of listeners.current) fn(from, data, channel);
			},
			onConnected: () => setJoined(true)
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		room,
		selfId,
		name
	]);
	return {
		selfId,
		room,
		peers,
		joined,
		broadcast: (0, import_react.useCallback)((data) => roomRef.current?.broadcast(data), []),
		send: (0, import_react.useCallback)((data, peerId) => roomRef.current?.send(data, peerId), []),
		onMessage: (0, import_react.useCallback)((fn) => {
			listeners.current.add(fn);
			return () => {
				listeners.current.delete(fn);
			};
		}, [])
	};
}
function isRoomMsg(data) {
	if (!data || typeof data !== "object") return false;
	const t = data.t;
	return t === "snapshot" || t === "text" || t === "guardians";
}
function RoomMesh() {
	const code = useRoom((s) => s.code);
	const name = useRoom((s) => s.name);
	if (!code) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomMeshInner, {
		code,
		name
	}, code);
}
function RoomMeshInner({ code, name }) {
	const isHost = useRoom((s) => s.isHost);
	const p2p = useP2PRoom({
		room: code,
		name
	});
	const sendArmed = (0, import_react.useRef)(isHost);
	const skipGuardians = (0, import_react.useRef)(false);
	const seenRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const lastPeerCount = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		useRoom.getState().setMesh({
			selfId: p2p.selfId,
			joined: p2p.joined,
			peers: p2p.peers
		});
	}, [
		p2p.selfId,
		p2p.joined,
		p2p.peers
	]);
	(0, import_react.useEffect)(() => {
		if (sendArmed.current) return;
		const id = window.setTimeout(() => {
			sendArmed.current = true;
		}, 1600);
		return () => window.clearTimeout(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const connected = p2p.peers.filter((p) => p.connectionState === "connected");
		const n = connected.length;
		if (n > lastPeerCount.current) {
			playSound("join");
			notify("Alguien cruzó el umbral.", "yudmiry");
		} else if (n < lastPeerCount.current && lastPeerCount.current > 0) notify("Un viajero se alejó.", "epheron");
		lastPeerCount.current = n;
		const newcomers = connected.filter((p) => !seenRef.current.has(p.id));
		if (newcomers.length > 0 && sendArmed.current) {
			if ([p2p.selfId, ...seenRef.current].sort()[0] === p2p.selfId) {
				const snap = currentSnapshot();
				for (const peer of newcomers) p2p.send(snap, peer.id);
			}
		}
		seenRef.current = new Set(connected.map((p) => p.id));
	}, [
		p2p.peers,
		p2p.selfId,
		p2p.send
	]);
	(0, import_react.useEffect)(() => p2p.onMessage((_from, data) => {
		if (!isRoomMsg(data)) return;
		applyRemote(data, () => {
			skipGuardians.current = true;
		});
		sendArmed.current = true;
	}), [p2p.onMessage]);
	const sequence = useSession((s) => s.sequence);
	const modes = useSession((s) => s.modes);
	const plain = useRoom((s) => s.plain);
	const origin = useRoom((s) => s.origin);
	(0, import_react.useEffect)(() => {
		if (!p2p.joined || !sendArmed.current) return;
		if (skipGuardians.current) {
			skipGuardians.current = false;
			return;
		}
		const msg = {
			t: "guardians",
			sequence,
			modes
		};
		p2p.send(msg);
	}, [
		sequence,
		modes,
		p2p.joined,
		p2p.send
	]);
	(0, import_react.useEffect)(() => {
		if (!p2p.joined || !sendArmed.current) return;
		if (origin !== "local") return;
		p2p.send({
			t: "text",
			plain
		});
	}, [
		plain,
		origin,
		p2p.joined,
		p2p.send
	]);
	return null;
}
function currentSnapshot() {
	const session = useSession.getState();
	return {
		t: "snapshot",
		plain: useRoom.getState().plain,
		sequence: session.sequence,
		modes: session.modes
	};
}
function applyRemote(msg, markGuardians) {
	if (msg.t === "text") {
		useRoom.getState().setRemotePlain(msg.plain);
		return;
	}
	if (msg.t === "guardians" || msg.t === "snapshot") {
		const current = useSession.getState();
		if (!(current.sequence.join() === msg.sequence.join() && JSON.stringify(current.modes) === JSON.stringify(msg.modes))) {
			markGuardians();
			current.adoptSequence(msg.sequence, msg.modes);
		}
	}
	if (msg.t === "snapshot") useRoom.getState().setRemotePlain(msg.plain);
}
var styles_default = "/assets/styles-M9FttRoF.css";
var APP_NAME = "Maprayés";
var themeBoot = `(function(){try{var r=localStorage.getItem("maprayes-settings");if(!r)return;var s=JSON.parse(r).state||{};var d=document.documentElement;if(s.theme)d.setAttribute("data-theme",s.theme);if(s.textSize)d.setAttribute("data-size",s.textSize);if(s.font)d.setAttribute("data-font",s.font);}catch(e){}})();`;
var Route$13 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Traductor del lenguaje secreto Maprayés. Guardianes, códigos y un poco de caos."
			},
			{
				name: "theme-color",
				content: "#5A614E"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;1,9..144,500&family=Source+Sans+3:ital,wght@0,400;0,500;0,600;1,400&family=VT323&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "es",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: themeBoot } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSync, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SoundGate, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomMesh, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChaosLayer, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
						position: "bottom-center",
						toastOptions: { className: "map-toast" },
						offset: 28
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$11 = () => import("./routes-CI67jVbh.mjs");
var Route$12 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./afinidad-sbetNjgo.mjs");
var Route$11 = createFileRoute("/afinidad")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./ajustes-D_1Iki_s.mjs");
var Route$10 = createFileRoute("/ajustes")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./ayuda-Cmntoyhy.mjs");
var Route$9 = createFileRoute("/ayuda")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./camara-BdP4WR-y.mjs");
var Route$8 = createFileRoute("/camara")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./guardianes-CuIUeQj9.mjs");
var Route$7 = createFileRoute("/guardianes")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./iniciacion-De0dxT0e.mjs");
var Route$6 = createFileRoute("/iniciacion")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./sala-BMoteMIA.mjs");
var Route$5 = createFileRoute("/sala")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./tabla-CRmSYDoh.mjs");
var Route$4 = createFileRoute("/tabla")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./traductor-D6q6FPP6.mjs");
var Route$3 = createFileRoute("/traductor")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef$1 = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef$1.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef$1.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef$1.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef$1.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef$1.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef$1.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({});
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef$1.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef$1.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
});
/**
* WebRTC signaling over the app database (Neon deployed, PGLite in preview).
* Only rendezvous traffic passes through here — roster + SDP/ICE relay while a
* mesh forms; game data then flows peer-to-peer. DB-backed so any serverless
* instance can serve any poll. Mount at /api/rtc (see the multiplayer-p2p
* skill); the client side lives in `@/lib/multiplayer`.
*
* The GET poll is the whole peer lifecycle: the first poll (since=0) IS the
* join — it registers the peer, returns the roster, and prunes stale rows.
* Peer ids are random per mount, so a fresh inbox never has old signals to
* skip and no join/cursor handshake is needed.
*/
var ID = string().regex(/^[a-zA-Z0-9_-]{1,64}$/);
var signalSchema = object({
	op: literal("signal"),
	room: ID,
	from: ID,
	to: ID,
	kind: _enum([
		"offer",
		"answer",
		"ice"
	]),
	payload: unknown().refine((v) => v !== void 0 && JSON.stringify(v).length <= 32768, { message: "payload too large" })
});
var leaveSchema = object({
	op: literal("leave"),
	room: ID,
	peer: ID
});
var postSchema = discriminatedUnion("op", [signalSchema, leaveSchema]);
var PEER_TTL_SECONDS = 30;
var SIGNAL_TTL_SECONDS = 60;
var globalRef = globalThis;
function ensureSchema(sql) {
	globalRef.__rtcSchemaPromise__ ??= (async () => {
		await sql.query(`CREATE TABLE IF NOT EXISTS webrtc_peers (
         room TEXT NOT NULL,
         peer_id TEXT NOT NULL,
         name TEXT NOT NULL DEFAULT '',
         last_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
         PRIMARY KEY (room, peer_id)
       )`);
		await sql.query(`CREATE TABLE IF NOT EXISTS webrtc_signals (
         id BIGSERIAL PRIMARY KEY,
         room TEXT NOT NULL,
         to_peer TEXT NOT NULL,
         from_peer TEXT NOT NULL,
         kind TEXT NOT NULL,
         payload JSONB NOT NULL,
         created_at TIMESTAMPTZ NOT NULL DEFAULT now()
       )`);
		await sql.query(`CREATE INDEX IF NOT EXISTS webrtc_signals_inbox
         ON webrtc_signals (room, to_peer, id)`);
	})().catch((err) => {
		globalRef.__rtcSchemaPromise__ = void 0;
		throw err;
	});
	return globalRef.__rtcSchemaPromise__;
}
async function roster(sql, room) {
	return (await sql.query(`SELECT peer_id, name FROM webrtc_peers
     WHERE room = $1 AND last_seen > now() - make_interval(secs => $2)
     ORDER BY peer_id LIMIT 32`, [room, PEER_TTL_SECONDS])).map((r) => ({
		id: r.peer_id,
		name: r.name
	}));
}
async function touchPeer(sql, room, peer, name) {
	await sql.query(`INSERT INTO webrtc_peers (room, peer_id, name, last_seen)
     VALUES ($1, $2, $3, now())
     ON CONFLICT (room, peer_id)
     DO UPDATE SET last_seen = now(), name = EXCLUDED.name`, [
		room,
		peer,
		name
	]);
}
async function prune(sql) {
	await Promise.all([sql.query(`DELETE FROM webrtc_signals WHERE created_at < now() - make_interval(secs => $1)`, [SIGNAL_TTL_SECONDS]), sql.query(`DELETE FROM webrtc_peers WHERE last_seen < now() - make_interval(secs => $1)`, [PEER_TTL_SECONDS])]);
}
function json(body, status = 200) {
	return new Response(JSON.stringify(body), {
		status,
		headers: {
			"content-type": "application/json",
			"cache-control": "no-store"
		}
	});
}
async function handleGet(url) {
	const parsed = object({
		room: ID,
		peer: ID,
		name: string().max(64).default(""),
		since: number$1().int().min(0).default(0)
	}).safeParse({
		room: url.searchParams.get("room"),
		peer: url.searchParams.get("peer"),
		name: url.searchParams.get("name") ?? "",
		since: url.searchParams.get("since") ?? 0
	});
	if (!parsed.success) return json({ error: "invalid query" }, 400);
	const { room, peer, name, since } = parsed.data;
	const sql = await getSql();
	await ensureSchema(sql);
	if (since === 0 || Math.random() < .02) await prune(sql);
	await touchPeer(sql, room, peer, name);
	const rows = await sql.query(`SELECT id, from_peer, kind, payload FROM webrtc_signals
     WHERE room = $1 AND to_peer = $2 AND id > $3
     ORDER BY id LIMIT 200`, [
		room,
		peer,
		since
	]);
	return json({
		peers: await roster(sql, room),
		signals: rows.map((r) => ({
			id: r.id,
			from: r.from_peer,
			kind: r.kind,
			payload: r.payload
		}))
	});
}
async function handlePost(request) {
	let body;
	try {
		body = await request.json();
	} catch {
		return json({ error: "invalid JSON" }, 400);
	}
	const parsed = postSchema.safeParse(body);
	if (!parsed.success) return json({ error: "invalid request" }, 400);
	const msg = parsed.data;
	const sql = await getSql();
	await ensureSchema(sql);
	if (msg.op === "signal") await sql.query(`INSERT INTO webrtc_signals (room, to_peer, from_peer, kind, payload)
       VALUES ($1, $2, $3, $4, $5)`, [
		msg.room,
		msg.to,
		msg.from,
		msg.kind,
		JSON.stringify(msg.payload)
	]);
	else await sql.query(`DELETE FROM webrtc_peers WHERE room = $1 AND peer_id = $2`, [msg.room, msg.peer]);
	return json({ ok: true });
}
async function handleSignaling(request) {
	try {
		if (request.method === "GET") return await handleGet(new URL(request.url));
		if (request.method === "POST") return await handlePost(request);
		return json({ error: "method not allowed" }, 405);
	} catch (error) {
		console.error("[rtc] signaling error:", error);
		return json({ error: "signaling failed" }, 500);
	}
}
var handle = ({ request }) => handleSignaling(request);
var Route$2 = createFileRoute("/api/rtc")({ server: { handlers: {
	GET: handle,
	POST: handle
} } });
var $$splitComponentImporter$1 = () => import("./iniciacion.index-DBvc0DcF.mjs");
var Route$1 = createFileRoute("/iniciacion/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./iniciacion.reliquias-eSkAvb0n.mjs");
var Route = createFileRoute("/iniciacion/reliquias")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$12.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$13
});
var AfinidadRoute = Route$11.update({
	id: "/afinidad",
	path: "/afinidad",
	getParentRoute: () => Route$13
});
var AjustesRoute = Route$10.update({
	id: "/ajustes",
	path: "/ajustes",
	getParentRoute: () => Route$13
});
var AyudaRoute = Route$9.update({
	id: "/ayuda",
	path: "/ayuda",
	getParentRoute: () => Route$13
});
var CamaraRoute = Route$8.update({
	id: "/camara",
	path: "/camara",
	getParentRoute: () => Route$13
});
var GuardianesRoute = Route$7.update({
	id: "/guardianes",
	path: "/guardianes",
	getParentRoute: () => Route$13
});
var IniciacionRoute = Route$6.update({
	id: "/iniciacion",
	path: "/iniciacion",
	getParentRoute: () => Route$13
});
var SalaRoute = Route$5.update({
	id: "/sala",
	path: "/sala",
	getParentRoute: () => Route$13
});
var TablaRoute = Route$4.update({
	id: "/tabla",
	path: "/tabla",
	getParentRoute: () => Route$13
});
var TraductorRoute = Route$3.update({
	id: "/traductor",
	path: "/traductor",
	getParentRoute: () => Route$13
});
var ApiRtcRoute = Route$2.update({
	id: "/api/rtc",
	path: "/api/rtc",
	getParentRoute: () => Route$13
});
var IniciacionIndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => IniciacionRoute
});
var IniciacionRouteChildren = {
	IniciacionReliquiasRoute: Route.update({
		id: "/reliquias",
		path: "/reliquias",
		getParentRoute: () => IniciacionRoute
	}),
	IniciacionIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AfinidadRoute,
	AjustesRoute,
	AyudaRoute,
	CamaraRoute,
	GuardianesRoute,
	IniciacionRoute: IniciacionRoute._addFileChildren(IniciacionRouteChildren),
	SalaRoute,
	TablaRoute,
	TraductorRoute,
	ApiRtcRoute
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { buttonVariants as a, Button as i, notify as n, playSound as o, GuardianSigil as r, useSession as s, router_exports as t };
