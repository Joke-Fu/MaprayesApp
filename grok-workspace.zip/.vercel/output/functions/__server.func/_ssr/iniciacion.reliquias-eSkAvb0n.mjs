import { t as cn } from "./room-BKUs9KcL.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { p as Lock } from "../_libs/lucide-react.mjs";
import { r as GuardianSigil } from "./router-Bg37-l_1.mjs";
import { t as AppShell } from "./app-shell-DkfEg3xz.mjs";
import { t as useHasMounted } from "./use-has-mounted-6Fm7Kyxs.mjs";
import { a as RELICS, d as useIniciacion, i as LEVEL_LABEL, l as relicUnlocked, u as unlockedCount } from "./iniciacion-nmFQ5Xo3.mjs";
import { t as HomeSeal } from "./home-seal-D7ajIB-A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/iniciacion.reliquias-eSkAvb0n.js
var import_jsx_runtime = require_jsx_runtime();
var LEVELS = [
	"facil",
	"medio",
	"dificil",
	"extremo"
];
function Reliquias() {
	const mounted = useHasMounted();
	const hits = useIniciacion((s) => s.hits);
	const guardianHits = useIniciacion((s) => s.guardianHits);
	const stats = {
		hits,
		guardianHits
	};
	const open = mounted ? unlockedCount(stats) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Reliquias",
		backTo: "/iniciacion",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: ["Cada acierto deja una marca. Lo que duerme aquí no se inventa: se recuerda. ", mounted ? `${open} de ${RELICS.length} despiertas.` : ""]
				}),
				LEVELS.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: LEVEL_LABEL[level]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tabular-nums text-muted",
							children: mounted ? `${hits[level]} aciertos` : ""
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
						children: RELICS.filter((r) => r.level === level).map((relic) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelicCard, {
							relic,
							unlocked: mounted && relicUnlocked(relic, stats),
							progress: hits[level] ?? 0
						}, relic.id))
					})]
				}, level)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: "Pactos de Extremo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Cada guardián recuerda las veces que su voluntad cerró el acierto."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
							children: RELICS.filter((r) => r.kind === "guardian").map((relic) => {
								const id = relic.guardian;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelicCard, {
									relic,
									unlocked: mounted && relicUnlocked(relic, stats),
									progress: guardianHits[id] ?? 0,
									guardian: id
								}, relic.id);
							})
						})
					]
				})
			]
		})
	});
}
function RelicCard({ relic, unlocked, progress, guardian }) {
	const ratio = Math.min(1, progress / relic.threshold);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: cn("flex items-center gap-3 rounded-xl bg-surface px-4 py-3.5 shadow-[var(--shadow-border)]", !unlocked && "opacity-70"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("flex size-12 shrink-0 items-center justify-center rounded-full", unlocked ? "text-olive" : "text-muted"),
			"aria-hidden": "true",
			children: guardian ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuardianSigil, {
				id: guardian,
				className: "size-7"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeSeal, { className: "size-10" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: relic.title
					}), unlocked ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 text-muted" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: relic.hint
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-2 block h-1 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block h-full rounded-full bg-olive transition-[width] duration-500",
						style: { width: `${ratio * 100}%` }
					})
				})
			]
		})]
	});
}
//#endregion
export { Reliquias as component };
