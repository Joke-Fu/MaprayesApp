import { f as isFullPrefix, o as TRICZY_SHIFTS, r as GUARDIANS, u as isDualMode } from "./guardians-DdPXp9oS.mjs";
import { a as CHAR_TO_CODE, c as MAX_CODE_LEN, i as BASE_CODES, n as ACCENTED_CODES, o as CODE_TO_CHAR, t as ACCENTED } from "./alphabet-DP9zcs2T.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cipher-C9E6kqVb.js
function hasEncodableGlyph(text) {
	let i = 0;
	while (i < text.length) {
		if (text.slice(i, i + 3) === "..." && CHAR_TO_CODE["..."]) return true;
		const ch = text[i] ?? "";
		const code = CHAR_TO_CODE[ch] ?? CHAR_TO_CODE[ch.toUpperCase()] ?? CHAR_TO_CODE[ch.toLowerCase()];
		if (code && code !== "||") return true;
		i += 1;
	}
	return false;
}
function encodeToMaprayes(text) {
	const words = text.split(/\s+/).filter((w) => w.length > 0);
	let invalid = false;
	return {
		code: words.map((word) => {
			let out = "";
			let i = 0;
			while (i < word.length) {
				if (word.slice(i, i + 3) === "..." && CHAR_TO_CODE["..."]) {
					out += CHAR_TO_CODE["..."];
					i += 3;
					continue;
				}
				const ch = word[i] ?? "";
				const code = CHAR_TO_CODE[ch] ?? CHAR_TO_CODE[ch.toUpperCase()] ?? CHAR_TO_CODE[ch.toLowerCase()];
				if (code && code !== "||") out += code;
				else if (ch) {
					out += "?";
					invalid = true;
				}
				i += 1;
			}
			return out;
		}).join("||"),
		invalid
	};
}
function decodeFromMaprayes(input) {
	const parts = input.split(/\|\|/);
	const words = [];
	for (const part of parts) {
		let word = "";
		let i = 0;
		while (i < part.length) {
			const match = longestMatch(part, i);
			if (match) {
				word += CODE_TO_CHAR[match] ?? "?";
				i += match.length;
			} else {
				word += "?";
				i += 1;
			}
		}
		words.push(word);
	}
	return words.join(" ").trim();
}
function longestMatch(part, i) {
	const max = Math.min(MAX_CODE_LEN, part.length - i);
	for (let len = max; len >= 1; len--) {
		const sub = part.slice(i, i + len);
		if (CODE_TO_CHAR[sub]) return sub;
	}
	return null;
}
function shiftAmount(id, isPlus, isReverse, letterIndex) {
	if (id === "triczy") {
		const arr = isReverse ? TRICZY_SHIFTS.map((n) => -n) : TRICZY_SHIFTS;
		return {
			shift: arr[letterIndex % arr.length] ?? 0,
			nextIndex: letterIndex + 1
		};
	}
	const g = GUARDIANS[id];
	let shift = 0;
	if (isDualMode(id)) shift = isPlus ? g.plus ?? 0 : g.minus ?? 0;
	else shift = g.shift ?? 0;
	if (isReverse) shift = -shift;
	return {
		shift,
		nextIndex: letterIndex
	};
}
function applyLetterShift(letter, shift, fallbackCode) {
	const upper = letter.toUpperCase();
	if (ACCENTED.includes(upper)) {
		const index = ACCENTED.indexOf(upper);
		const effective = (shift % 5 + 5) % 5;
		const next = ACCENTED[(index + effective) % 5];
		return ACCENTED_CODES[next ?? upper] ?? fallbackCode;
	}
	if ("ABCDEFGHIJKLMNÑOPQRSTUVWXYZ".includes(upper)) {
		const next = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"[("ABCDEFGHIJKLMNÑOPQRSTUVWXYZ".indexOf(upper) + shift + 2700) % 27] ?? upper;
		return BASE_CODES[next] ?? fallbackCode;
	}
	return fallbackCode;
}
function applyMythicShift(code, character, isPlus, isReverse) {
	return code.split(/\|\|/).map((part) => {
		let out = "";
		let letterIndex = 0;
		let i = 0;
		while (i < part.length) {
			const match = longestMatch(part, i);
			if (match) {
				const letter = (CODE_TO_CHAR[match] ?? "").toUpperCase();
				const { shift, nextIndex } = shiftAmount(character, isPlus, isReverse, letterIndex);
				letterIndex = nextIndex;
				out += applyLetterShift(letter, shift, match);
				i += match.length;
			} else {
				out += part[i] ?? "";
				i += 1;
			}
		}
		return out;
	}).join("||");
}
function applySequence(code, sequence, modes, reverse = false) {
	let current = code;
	const seq = reverse ? [...sequence].reverse() : sequence;
	for (const g of seq) {
		const isPlus = modes[g] !== false;
		current = applyMythicShift(current, g, isPlus, reverse);
	}
	return current;
}
var INITIALS = Object.fromEntries(Object.values(GUARDIANS).map((g) => [g.initials, g.id]));
function parseMythicPrefix(input) {
	const match = input.match(/\[MYTHIC:([^\]]+)\]\s*(.*)/s);
	if (!match) return {
		clean: input,
		sequence: [],
		modes: {},
		isFull: false
	};
	let prefix = match[1] ?? "";
	let isFull = false;
	if (prefix.startsWith("FULL,")) {
		isFull = true;
		prefix = prefix.slice(5);
	}
	const sequence = [];
	const modes = {};
	for (const raw of prefix.split(",")) {
		const p = raw.trim();
		if (!p) continue;
		const signed = p.match(/^([A-Z]{2})([+-]\d+)$/);
		if (signed) {
			const id = INITIALS[signed[1] ?? ""];
			if (id) {
				sequence.push(id);
				modes[id] = (signed[2] ?? "").startsWith("+");
			}
		} else {
			const id = INITIALS[p];
			if (id) {
				sequence.push(id);
				modes[id] = true;
			}
		}
	}
	return {
		clean: match[2] ?? "",
		sequence,
		modes,
		isFull
	};
}
function buildMythicPrefix(sequence, modes) {
	if (sequence.length === 0) return "";
	const body = sequence.map((g) => {
		const initial = GUARDIANS[g].initials;
		if (g === "garbanza") return `${initial}${modes[g] !== false ? "+5" : "-5"}`;
		if (g === "oithar") return `${initial}${modes[g] !== false ? "+8" : "-8"}`;
		if (g === "willy") return `${initial}${modes[g] !== false ? "+4" : "-2"}`;
		return initial;
	}).join(",");
	return `[MYTHIC:${isFullPrefix(sequence, modes) ? "FULL," : ""}${body}] `;
}
function buildQrPayload(cleanCode, sequence, modes) {
	return `${buildMythicPrefix(sequence, modes)}${cleanCode}`;
}
function encodeWithGuardians(text, sequence, modes) {
	const { code, invalid } = encodeToMaprayes(text);
	if (!code) return {
		code: "",
		invalid
	};
	if (sequence.length === 0) return {
		code,
		invalid
	};
	return {
		code: applySequence(code, sequence, modes, false),
		invalid
	};
}
function decodeWithGuardians(input, sequence, modes) {
	const parsed = parseMythicPrefix(input);
	const seq = parsed.sequence.length > 0 ? parsed.sequence : sequence;
	const md = parsed.sequence.length > 0 ? parsed.modes : modes;
	return {
		text: decodeFromMaprayes(applySequence(parsed.clean, seq, md, true)),
		parsed
	};
}
//#endregion
export { hasEncodableGlyph as a, encodeWithGuardians as i, decodeWithGuardians as n, parseMythicPrefix as o, encodeToMaprayes as r, buildQrPayload as t };
