import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as cn } from "./room-BKUs9KcL.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("h-11 w-full rounded-md bg-surface px-3 text-fg shadow-[var(--shadow-border)] placeholder:text-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-olive/40", className),
		...props
	});
}
//#endregion
export { Input as t };
