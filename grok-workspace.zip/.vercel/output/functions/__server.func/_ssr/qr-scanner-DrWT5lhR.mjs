import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as cn } from "./room-BKUs9KcL.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { m as Image$1, t as X, x as Camera } from "../_libs/lucide-react.mjs";
import { a as buttonVariants, i as Button, o as playSound } from "./router-Bg37-l_1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qr-scanner-DrWT5lhR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function looksLikeMaprayes(text) {
	return /\[MYTHIC:/i.test(text) || /\(\d\)\d/.test(text) || text.includes("||");
}
function getDetector() {
	if (typeof window === "undefined") return null;
	return window.BarcodeDetector ?? null;
}
async function decodeQrFromSource(source) {
	const Detector = getDetector();
	if (Detector) try {
		const value = (await new Detector({ formats: ["qr_code"] }).detect(source))[0]?.rawValue?.trim();
		if (value) return value;
	} catch {}
	return decodeWithJsQr(source);
}
function sourceToImageData(source) {
	const canvas = document.createElement("canvas");
	let width = 0;
	let height = 0;
	if (source instanceof HTMLVideoElement) {
		width = source.videoWidth;
		height = source.videoHeight;
	} else if (source instanceof HTMLImageElement) {
		width = source.naturalWidth || source.width;
		height = source.naturalHeight || source.height;
	} else if (source instanceof HTMLCanvasElement) {
		width = source.width;
		height = source.height;
	} else if (typeof ImageBitmap !== "undefined" && source instanceof ImageBitmap) {
		width = source.width;
		height = source.height;
	}
	if (width < 8 || height < 8) return null;
	const scale = Math.min(1, 1280 / Math.max(width, height));
	canvas.width = Math.max(1, Math.round(width * scale));
	canvas.height = Math.max(1, Math.round(height * scale));
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) return null;
	ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
	return ctx.getImageData(0, 0, canvas.width, canvas.height);
}
async function decodeWithJsQr(source) {
	const image = sourceToImageData(source);
	if (!image) return null;
	const { default: jsQR } = await import("../_libs/jsqr.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	return jsQR(image.data, image.width, image.height, { inversionAttempts: "attemptBoth" })?.data?.trim() || null;
}
async function decodeQrFromFile(file) {
	const url = URL.createObjectURL(file);
	try {
		return decodeQrFromSource(await loadImage(url));
	} finally {
		URL.revokeObjectURL(url);
	}
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("image"));
		img.src = src;
	});
}
function cameraErrorMessage(err) {
	const name = err && typeof err === "object" && "name" in err ? String(err.name) : "";
	if (name === "NotAllowedError") return "Sin permiso de cámara. Puedes usar una foto del código.";
	if (name === "NotFoundError") return "No hay cámara en este dispositivo. Usa una foto.";
	if (name === "SecurityError" || name === "NotSupportedError") return "Este entorno no permite la cámara en vivo. Usa una foto del código.";
	return "No se pudo abrir la cámara. Usa una foto del código.";
}
function QrScanner({ onScan, onClose, variant = "overlay" }) {
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const foundRef = (0, import_react.useRef)(false);
	const onScanRef = (0, import_react.useRef)(onScan);
	onScanRef.current = onScan;
	const [status, setStatus] = (0, import_react.useState)("Abriendo cámara…");
	const [live, setLive] = (0, import_react.useState)(false);
	const [cameraFailed, setCameraFailed] = (0, import_react.useState)(false);
	const [busyFile, setBusyFile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		foundRef.current = false;
		let cancelled = false;
		let raf = 0;
		let busy = false;
		let lastScan = 0;
		async function start() {
			if (!navigator.mediaDevices?.getUserMedia) {
				setCameraFailed(true);
				setStatus("Este entorno no permite la cámara en vivo. Usa una foto del código.");
				return;
			}
			try {
				let stream;
				try {
					stream = await navigator.mediaDevices.getUserMedia({
						audio: false,
						video: {
							facingMode: { ideal: "environment" },
							width: { ideal: 1280 },
							height: { ideal: 720 }
						}
					});
				} catch {
					stream = await navigator.mediaDevices.getUserMedia({
						audio: false,
						video: true
					});
				}
				if (cancelled) {
					stream.getTracks().forEach((t) => t.stop());
					return;
				}
				streamRef.current = stream;
				const video = videoRef.current;
				if (!video) return;
				video.srcObject = stream;
				await video.play();
				setLive(true);
				setStatus("Apunta al código Maprayés");
				const tick = () => {
					if (cancelled || foundRef.current) return;
					const now = performance.now();
					if (!busy && video.readyState >= 2 && now - lastScan > 140) {
						lastScan = now;
						busy = true;
						decodeQrFromSource(video).then((text) => {
							if (cancelled || foundRef.current || !text) return;
							foundRef.current = true;
							streamRef.current?.getTracks().forEach((t) => t.stop());
							onScanRef.current(text);
						}).finally(() => {
							busy = false;
						});
					}
					raf = window.requestAnimationFrame(tick);
				};
				raf = window.requestAnimationFrame(tick);
			} catch (err) {
				if (cancelled) return;
				setCameraFailed(true);
				setLive(false);
				setStatus(cameraErrorMessage(err));
			}
		}
		start();
		return () => {
			cancelled = true;
			window.cancelAnimationFrame(raf);
			streamRef.current?.getTracks().forEach((t) => t.stop());
			streamRef.current = null;
			const video = videoRef.current;
			if (video) video.srcObject = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (variant !== "overlay") return;
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		const onKey = (e) => {
			if (e.key === "Escape") onClose?.();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = prev;
			window.removeEventListener("keydown", onKey);
		};
	}, [variant, onClose]);
	async function onFile(file) {
		if (!file) return;
		setBusyFile(true);
		try {
			const text = await decodeQrFromFile(file);
			if (text) {
				foundRef.current = true;
				onScanRef.current(text);
			} else {
				playSound("error");
				setStatus("No se encontró un código en esa foto.");
			}
		} catch {
			playSound("error");
			setStatus("No se pudo leer esa imagen.");
		} finally {
			setBusyFile(false);
		}
	}
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("qr-stage relative w-full overflow-hidden rounded-xl bg-surface-2", live ? "aspect-[3/4] sm:aspect-video" : "min-h-56"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						className: cn("size-full object-cover", live ? "opacity-100" : "opacity-0"),
						autoPlay: true,
						muted: true,
						playsInline: true
					}),
					live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "qr-finder",
						"aria-hidden": true
					}) : null,
					!live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-8 text-olive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: status
						})]
					}) : null,
					live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute inset-x-3 bottom-3 rounded-md bg-bg/80 px-3 py-1.5 text-center text-xs text-fg",
						children: status
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: cn(buttonVariants({ variant: "outline" }), "cursor-pointer"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, {}),
						cameraFailed ? "Tomar o elegir foto" : "Usar foto",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							capture: cameraFailed ? "environment" : void 0,
							className: "sr-only",
							disabled: busyFile,
							onChange: (e) => {
								const file = e.target.files?.[0];
								e.target.value = "";
								onFile(file);
							}
						})
					]
				}), variant === "overlay" && onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: onClose,
					children: "Cerrar"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: "Si la cámara no está disponible, elige una foto del código. En el teléfono también puedes tomarla al momento."
			})
		]
	});
	if (variant === "page") return body;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[80] flex items-end justify-center bg-bg/92 p-4 backdrop-blur-sm sm:items-center",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Leer código",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[min(92dvh,44rem)] w-full max-w-lg overflow-y-auto rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium",
					children: "Leer código"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-md text-muted hover:text-fg",
					"aria-label": "Cerrar",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), body]
		})
	});
}
//#endregion
export { looksLikeMaprayes as n, QrScanner as t };
