import { i as GUARDIAN_IDS } from "./guardians-DdPXp9oS.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as hasEncodableGlyph } from "./cipher-C9E6kqVb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/affinity-BV43GLWo.js
function pairKey(a, b) {
	return a < b ? `${a}|${b}` : `${b}|${a}`;
}
function parsePairKey(key) {
	const [a, b] = key.split("|");
	if (!a || !b) return null;
	if (!GUARDIAN_IDS.includes(a)) return null;
	if (!GUARDIAN_IDS.includes(b)) return null;
	return [a, b];
}
function recordAffinity(counts, pairs, sequence) {
	const unique = [...new Set(sequence)];
	if (unique.length < 2) return {
		counts,
		pairs
	};
	const nextCounts = { ...counts };
	const nextPairs = { ...pairs };
	for (const id of unique) nextCounts[id] = (nextCounts[id] ?? 0) + 1;
	for (let i = 0; i < unique.length; i += 1) for (let j = i + 1; j < unique.length; j += 1) {
		const left = unique[i];
		const right = unique[j];
		if (!left || !right) continue;
		const key = pairKey(left, right);
		nextPairs[key] = (nextPairs[key] ?? 0) + 1;
	}
	return {
		counts: nextCounts,
		pairs: nextPairs
	};
}
function maxValue(values) {
	let max = 0;
	for (const n of values) if (n > max) max = n;
	return max;
}
/** Affinity is only recorded when a real message is encoded with 2+ guardians. */
function shouldRecordAffinity(sequence, text) {
	if (sequence.length < 2) return false;
	if (!text.trim()) return false;
	return hasEncodableGlyph(text);
}
var useAffinity = create()(persist((set, get) => ({
	counts: {},
	pairs: {},
	record: (sequence) => {
		set(recordAffinity(get().counts, get().pairs, sequence));
	},
	forget: () => set({
		counts: {},
		pairs: {}
	})
}), { name: "maprayes-affinity" }));
//#endregion
export { useAffinity as i, parsePairKey as n, shouldRecordAffinity as r, maxValue as t };
