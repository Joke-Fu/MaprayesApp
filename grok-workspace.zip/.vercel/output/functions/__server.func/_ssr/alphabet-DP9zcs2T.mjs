//#region node_modules/.nitro/vite/services/ssr/assets/alphabet-DP9zcs2T.js
/** Canonical Maprayés codebook — character ←→ glyph. */
var ALFABETO = {
	"(1)1": "A",
	"(1)01": "Á",
	"(1)2": "B",
	"(1)3": "C",
	"(1)4": "D",
	"(1)5": "E",
	"(1)05": "É",
	"(1)6": "F",
	"(1)7": "G",
	"(1)8": "H",
	"(1)9": "I",
	"(1)09": "Í",
	"(2)1": "J",
	"(2)2": "K",
	"(2)3": "L",
	"(2)4": "M",
	"(2)5": "N",
	"(2)6": "Ñ",
	"(2)7": "O",
	"(2)07": "Ó",
	"(2)8": "P",
	"(2)9": "Q",
	"(3)1": "R",
	"(3)2": "S",
	"(3)3": "T",
	"(3)4": "U",
	"(3)04": "Ú",
	"(3)5": "V",
	"(3)6": "W",
	"(3)7": "X",
	"(3)8": "Y",
	"(3)9": "Z",
	"(4)1": "?",
	"(4)01": "¿",
	"(4)2": "!",
	"(4)02": "¡",
	"(4)3": "=",
	"(4)4": ",",
	"(4)5": ";",
	"(4)6": "\"",
	"(4)7": ")",
	"(4)07": "(",
	"(4)8": "...",
	"(4)9": "*",
	"(5)1": "+",
	"(5)2": "-",
	"(5)3": "÷",
	"(5)4": "×",
	"(5)5": "√",
	"(5)6": "_",
	"(5)7": "@",
	"(5)8": "π",
	"(5)9": "$",
	"(6)1": "#",
	"(6)2": "'",
	"(6)3": "%",
	"(6)4": "^",
	"(6)5": "°",
	"(6)6": "/",
	"(6)06": "\\",
	"(6)7": ">",
	"(6)07": "<",
	"(6)8": "¢",
	"(6)9": "€",
	"(1)3(1)5#": "0",
	"(3)4(2)5#": "1",
	"(1)4(2)7#": "2",
	"(3)3(3)1#": "3",
	"(1)3(3)4#": "4",
	"(1)3(1)9#": "5",
	"(3)2(1)5#": "6",
	"(3)2(1)9#": "7",
	"(2)7(1)3#": "8",
	"(2)5(3)4#": "9",
	"(0)0": ".",
	"||": " "
};
var LETTERS = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
var ACCENTED = [
	"Á",
	"É",
	"Í",
	"Ó",
	"Ú"
];
var ACCENTED_CODES = {
	Á: "(1)01",
	É: "(1)05",
	Í: "(1)09",
	Ó: "(2)07",
	Ú: "(3)04"
};
var BASE_CODES = {
	A: "(1)1",
	B: "(1)2",
	C: "(1)3",
	D: "(1)4",
	E: "(1)5",
	F: "(1)6",
	G: "(1)7",
	H: "(1)8",
	I: "(1)9",
	J: "(2)1",
	K: "(2)2",
	L: "(2)3",
	M: "(2)4",
	N: "(2)5",
	Ñ: "(2)6",
	O: "(2)7",
	P: "(2)8",
	Q: "(2)9",
	R: "(3)1",
	S: "(3)2",
	T: "(3)3",
	U: "(3)4",
	V: "(3)5",
	W: "(3)6",
	X: "(3)7",
	Y: "(3)8",
	Z: "(3)9"
};
var CODE_TO_CHAR = { ...ALFABETO };
var CHAR_TO_CODE = {};
for (const [code, char] of Object.entries(ALFABETO)) {
	CHAR_TO_CODE[char] = code;
	CHAR_TO_CODE[char.toLowerCase()] = code;
	CHAR_TO_CODE[char.toUpperCase()] = code;
}
CHAR_TO_CODE["…"] = "(4)8";
var MAX_CODE_LEN = Object.keys(ALFABETO).reduce((m, k) => Math.max(m, k.length), 1);
function entriesForCategory(category, favorites) {
	let items = Object.entries(ALFABETO);
	if (category === "letras") {
		const order = "AÁBCDEÉFGHIÍJKLMNÑOÓPQRSTUÚVWXYZ";
		items = items.filter(([, char]) => /^[A-ZÁÉÍÓÚÑ]$/.test(char));
		items.sort((a, b) => order.indexOf(a[1]) - order.indexOf(b[1]));
	} else if (category === "numeros") {
		const order = "0123456789";
		items = items.filter(([, char]) => /^[0-9]$/.test(char));
		items.sort((a, b) => order.indexOf(a[1]) - order.indexOf(b[1]));
	} else if (category === "simbolos") items = items.filter(([, char]) => !/^[A-ZÁÉÍÓÚÑ0-9]$/.test(char));
	else items = items.filter(([code]) => favorites.includes(code)).reverse();
	return items;
}
//#endregion
export { CHAR_TO_CODE as a, MAX_CODE_LEN as c, BASE_CODES as i, entriesForCategory as l, ACCENTED_CODES as n, CODE_TO_CHAR as o, ALFABETO as r, LETTERS as s, ACCENTED as t };
