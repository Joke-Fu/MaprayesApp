import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { b as Check, s as Share2, y as Copy } from "../_libs/lucide-react.mjs";
import { i as Button, n as notify, o as playSound } from "./router-Bg37-l_1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/share-button-RZBJH7Si.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CopyButton({ value, label = "Copiar" }) {
	const [done, setDone] = (0, import_react.useState)(false);
	async function copy() {
		if (!value) {
			playSound("error");
			notify("No hay nada que copiar.");
			return;
		}
		try {
			await navigator.clipboard.writeText(value);
			setDone(true);
			playSound("copy");
			notify("Copiado al portapapeles.", "yudmiry");
			window.setTimeout(() => setDone(false), 1600);
		} catch {
			playSound("error");
			notify("No se pudo copiar. Selecciona el texto a mano.", "triczy");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		variant: "outline",
		size: "sm",
		onClick: copy,
		children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), label]
	});
}
function canNativeShare(text, files) {
	if (typeof navigator === "undefined" || typeof navigator.share !== "function") return false;
	try {
		if (typeof navigator.canShare === "function") return navigator.canShare(files?.length ? {
			text,
			files
		} : { text });
	} catch {
		return false;
	}
	return true;
}
async function shareText(text, title = "Maprayés") {
	if (!text) return "fail";
	if (canNativeShare(text)) try {
		await navigator.share({
			title,
			text
		});
		return "shared";
	} catch (err) {
		if (err instanceof DOMException && err.name === "AbortError") return "cancel";
	}
	try {
		await navigator.clipboard.writeText(text);
		return "copied";
	} catch {
		return "fail";
	}
}
async function shareFiles(files, text, title = "Maprayés") {
	if (canNativeShare(text, files)) try {
		await navigator.share({
			title,
			text,
			files
		});
		return "shared";
	} catch (err) {
		if (err instanceof DOMException && err.name === "AbortError") return "cancel";
	}
	return shareText(text, title);
}
function whatsappHref(text) {
	return `https://wa.me/?text=${encodeURIComponent(text)}`;
}
function telegramHref(text) {
	return `https://t.me/share/url?url=${encodeURIComponent(text)}`;
}
function ShareButton({ value, label = "Compartir" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	const native = typeof navigator !== "undefined" && canNativeShare(value || ".");
	const rootRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onDoc(e) {
			if (!rootRef.current?.contains(e.target)) setOpen(false);
		}
		document.addEventListener("mousedown", onDoc);
		return () => document.removeEventListener("mousedown", onDoc);
	}, [open]);
	async function nativeShare() {
		if (!value) {
			playSound("error");
			notify("No hay nada que compartir.");
			return;
		}
		const result = await shareText(value);
		if (result === "cancel") return;
		if (result === "fail") {
			playSound("error");
			notify("No se pudo compartir.", "triczy");
			return;
		}
		playSound("share");
		setDone(true);
		notify(result === "shared" ? "Elige WhatsApp, Messenger o Bluetooth en la hoja del sistema." : "Copiado. Pégalo en WhatsApp, Messenger o donde quieras.", "lino");
		window.setTimeout(() => setDone(false), 1600);
	}
	if (native) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		variant: "outline",
		size: "sm",
		onClick: () => void nativeShare(),
		children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), label]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: rootRef,
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			onClick: () => {
				if (!value) {
					playSound("error");
					notify("No hay nada que compartir.");
					return;
				}
				setOpen((v) => !v);
			},
			children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), label]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute top-full left-0 z-40 mt-1 min-w-44 overflow-hidden rounded-lg bg-surface py-1 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "block w-full px-3 py-2.5 text-left text-sm hover:bg-surface-2",
					onClick: () => {
						nativeShare();
						setOpen(false);
					},
					children: "Copiar mensaje"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "block px-3 py-2.5 text-sm hover:bg-surface-2",
					href: whatsappHref(value),
					target: "_blank",
					rel: "noreferrer",
					onClick: () => {
						playSound("share");
						setOpen(false);
					},
					children: "WhatsApp"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "block px-3 py-2.5 text-sm hover:bg-surface-2",
					href: telegramHref(value),
					target: "_blank",
					rel: "noreferrer",
					onClick: () => {
						playSound("share");
						setOpen(false);
					},
					children: "Telegram"
				})
			]
		}) : null]
	});
}
//#endregion
export { shareText as i, ShareButton as n, shareFiles as r, CopyButton as t };
