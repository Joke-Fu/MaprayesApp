//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CYLRhVhS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/afinidad",
			"/ajustes",
			"/ayuda",
			"/camara",
			"/guardianes",
			"/iniciacion",
			"/sala",
			"/tabla",
			"/traductor",
			"/api/rtc"
		],
		preloads: [
			"/assets/index-DSIhydMU.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/useStore-CxBsohbJ.js",
			"/assets/room-CUXSwZW5.js",
			"/assets/settings-BYVJAKK5.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DSIhydMU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-EIWJcqU0.js",
			"/assets/arrow-right-BwP2OflT.js",
			"/assets/camera-J-3Sahb9.js",
			"/assets/radio-5e1ldofd.js",
			"/assets/home-seal-o9MAx4mY.js"
		]
	},
	"/afinidad": {
		filePath: "/workspace/src/routes/afinidad.tsx",
		children: void 0,
		preloads: [
			"/assets/afinidad-bSU1Aoo4.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/affinity-CQmvJ8Zk.js",
			"/assets/use-has-mounted-ChPFa2f8.js"
		]
	},
	"/ajustes": {
		filePath: "/workspace/src/routes/ajustes.tsx",
		children: void 0,
		preloads: [
			"/assets/ajustes-D8fvgHJ4.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/use-has-mounted-ChPFa2f8.js",
			"/assets/switch-D7ZPA3pL.js"
		]
	},
	"/ayuda": {
		filePath: "/workspace/src/routes/ayuda.tsx",
		children: void 0,
		preloads: ["/assets/ayuda-CDuCme1B.js", "/assets/app-shell-BuQxPGbV.js"]
	},
	"/camara": {
		filePath: "/workspace/src/routes/camara.tsx",
		children: void 0,
		preloads: [
			"/assets/camara-ByW0tTok.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/qr-scanner-BmsQdclJ.js"
		]
	},
	"/guardianes": {
		filePath: "/workspace/src/routes/guardianes.tsx",
		children: void 0,
		preloads: ["/assets/guardianes-C0cPRB7k.js", "/assets/app-shell-BuQxPGbV.js"]
	},
	"/iniciacion": {
		filePath: "/workspace/src/routes/iniciacion.tsx",
		children: ["/iniciacion/reliquias", "/iniciacion/"],
		preloads: ["/assets/iniciacion-Q3Wb1qC7.js"]
	},
	"/sala": {
		filePath: "/workspace/src/routes/sala.tsx",
		children: void 0,
		preloads: [
			"/assets/sala-DQVxx5xD.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/arrow-right-BwP2OflT.js",
			"/assets/share-button-kWnJpRJM.js",
			"/assets/radio-5e1ldofd.js",
			"/assets/cipher-Dj_aJFXv.js",
			"/assets/input-6XGLOL91.js"
		]
	},
	"/tabla": {
		filePath: "/workspace/src/routes/tabla.tsx",
		children: void 0,
		preloads: [
			"/assets/tabla-P23Qw2_e.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/alphabet-NPB4A-9T.js",
			"/assets/input-6XGLOL91.js"
		]
	},
	"/traductor": {
		filePath: "/workspace/src/routes/traductor.tsx",
		children: void 0,
		preloads: [
			"/assets/traductor-C9m1dqlG.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/camera-J-3Sahb9.js",
			"/assets/share-button-kWnJpRJM.js",
			"/assets/qr-scanner-BmsQdclJ.js",
			"/assets/x-DieiHTRi.js",
			"/assets/cipher-Dj_aJFXv.js",
			"/assets/affinity-CQmvJ8Zk.js",
			"/assets/switch-D7ZPA3pL.js"
		]
	},
	"/iniciacion/reliquias": {
		filePath: "/workspace/src/routes/iniciacion.reliquias.tsx",
		children: void 0,
		preloads: [
			"/assets/iniciacion.reliquias-CVHqe-Nh.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/use-has-mounted-ChPFa2f8.js",
			"/assets/home-seal-o9MAx4mY.js",
			"/assets/iniciacion-BHrnujeb.js"
		]
	},
	"/iniciacion/": {
		filePath: "/workspace/src/routes/iniciacion.index.tsx",
		children: void 0,
		preloads: [
			"/assets/iniciacion.index-BLpaqNEc.js",
			"/assets/app-shell-BuQxPGbV.js",
			"/assets/arrow-right-BwP2OflT.js",
			"/assets/x-DieiHTRi.js",
			"/assets/cipher-Dj_aJFXv.js",
			"/assets/use-has-mounted-ChPFa2f8.js",
			"/assets/switch-D7ZPA3pL.js",
			"/assets/input-6XGLOL91.js",
			"/assets/iniciacion-BHrnujeb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
