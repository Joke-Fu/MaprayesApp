import type { ReactNode } from "react";
import type { GuardianId } from "@/lib/maprayes/guardians";
import { cn } from "@/lib/utils";

type Props = { id: GuardianId; className?: string };

function Svg({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-6 shrink-0", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

export function GuardianSigil({ id, className }: Props) {
  switch (id) {
    case "lino":
      return (
        <Svg className={className}>
          <path d="M16 26c5 0 8-4 8-9 0-6-5-10-8-13-3 3-8 7-8 13 0 5 3 9 8 9z" />
          <path d="M16 18c0-3 2-5 2-8" />
        </Svg>
      );
    case "garbanza":
      return (
        <Svg className={className}>
          <circle cx="16" cy="18" r="7" />
          <path d="M12 12c0-4 8-4 8 0" />
          <path d="M16 5v4" />
        </Svg>
      );
    case "yudmiry":
      return (
        <Svg className={className}>
          <circle cx="16" cy="16" r="5" />
          <path d="M4 16c4-7 20-7 24 0M4 16c4 7 20 7 24 0" />
        </Svg>
      );
    case "escrimedes":
      return (
        <Svg className={className}>
          <path d="M9 5h12v22H9z" />
          <path d="M12 10h6M12 15h6M12 20h4" />
        </Svg>
      );
    case "oithar":
      return (
        <Svg className={className}>
          <path d="M8 16c2-8 14-8 16 0-2 8-14 8-16 0z" />
          <path d="M10 16c1.5-5 10.5-5 12 0" />
        </Svg>
      );
    case "epheron":
      return (
        <Svg className={className}>
          <path d="M16 4c4 6 4 10 0 14-4-4-4-8 0-14z" />
          <path d="M10 26h12c-1-4-4-6-6-6s-5 2-6 6z" />
        </Svg>
      );
    case "willy":
      return (
        <Svg className={className}>
          <path d="M16 26c-6-4-8-10-6-16 3 2 5 2 6 0 1 2 3 2 6 0 2 6 0 12-6 16z" />
        </Svg>
      );
    case "triczy":
      return (
        <Svg className={className}>
          <path d="M8 12c0-4 3-7 8-7s8 3 8 7c0 8-8 15-8 15S8 20 8 12z" />
          <circle cx="13" cy="13" r="1.2" fill="currentColor" stroke="none" />
          <circle cx="19" cy="13" r="1.2" fill="currentColor" stroke="none" />
          <path d="M13 18c2 2 4 2 6 0" />
        </Svg>
      );
  }
}
