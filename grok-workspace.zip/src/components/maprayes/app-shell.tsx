import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";
import { useRoom } from "@/lib/store/room";
import { cn } from "@/lib/utils";

export function AppShell({
  title,
  wide,
  backTo = "/",
  children,
}: {
  title?: string;
  wide?: boolean;
  backTo?: "/" | "/iniciacion";
  children: ReactNode;
}) {
  const roomCode = useRoom((s) => s.code);
  return (
    <div className="flex min-h-dvh flex-col">
      {title ? (
        <header className="sticky top-0 z-30 border-b border-border/70 bg-bg/85 backdrop-blur-sm">
          <div
            className={cn(
              "mx-auto flex h-14 items-center gap-3 px-4",
              wide ? "max-w-3xl" : "max-w-lg",
            )}
          >
            <Link
              to={backTo}
              className="inline-flex h-11 items-center gap-1.5 rounded-md px-2 text-fg transition-colors duration-150 hover:bg-surface"
              aria-label="Regresar"
            >
              <ArrowLeft className="size-5" />
              <span className="text-sm font-medium">Atrás</span>
            </Link>
            <h1 className="truncate font-display text-lg font-medium tracking-tight">
              {title}
            </h1>
            {roomCode && title !== "Sala" ? (
              <Link
                to="/sala"
                className="ml-auto truncate font-mono text-xs tracking-wide text-olive"
              >
                {roomCode}
              </Link>
            ) : null}
          </div>
        </header>
      ) : null}
      <main
        className={cn(
          "mx-auto w-full flex-1 px-5 py-6",
          wide ? "max-w-3xl" : "max-w-lg",
        )}
      >
        {children}
      </main>
    </div>
  );
}
