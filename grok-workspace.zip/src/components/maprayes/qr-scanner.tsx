import { Camera, ImageIcon, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  cameraErrorMessage,
  decodeQrFromFile,
  decodeQrFromSource,
} from "@/lib/maprayes/qr-decode";
import { playSound } from "@/lib/maprayes/sound";
import { cn } from "@/lib/utils";

export function QrScanner({
  onScan,
  onClose,
  variant = "overlay",
}: {
  onScan: (text: string) => void;
  onClose?: () => void;
  variant?: "overlay" | "page";
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const foundRef = useRef(false);
  const onScanRef = useRef(onScan);
  onScanRef.current = onScan;
  const [status, setStatus] = useState("Abriendo cámara…");
  const [live, setLive] = useState(false);
  const [cameraFailed, setCameraFailed] = useState(false);
  const [busyFile, setBusyFile] = useState(false);

  useEffect(() => {
    foundRef.current = false;
    let cancelled = false;
    let raf = 0;
    let busy = false;
    let lastScan = 0;

    async function start() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraFailed(true);
        setStatus("Este entorno no permite la cámara en vivo. Usa una foto del código.");
        return;
      }
      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              facingMode: { ideal: "environment" },
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
          });
        } catch {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: true,
          });
        }
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (!video) return;
        video.srcObject = stream;
        await video.play();
        setLive(true);
        setStatus("Apunta al código Maprayés");
        const tick = () => {
          if (cancelled || foundRef.current) return;
          const now = performance.now();
          if (!busy && video.readyState >= 2 && now - lastScan > 140) {
            lastScan = now;
            busy = true;
            void decodeQrFromSource(video)
              .then((text) => {
                if (cancelled || foundRef.current || !text) return;
                foundRef.current = true;
                streamRef.current?.getTracks().forEach((t) => t.stop());
                onScanRef.current(text);
              })
              .finally(() => {
                busy = false;
              });
          }
          raf = window.requestAnimationFrame(tick);
        };
        raf = window.requestAnimationFrame(tick);
      } catch (err) {
        if (cancelled) return;
        setCameraFailed(true);
        setLive(false);
        setStatus(cameraErrorMessage(err));
      }
    }

    void start();

    return () => {
      cancelled = true;
      window.cancelAnimationFrame(raf);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      const video = videoRef.current;
      if (video) video.srcObject = null;
    };
  }, []);

  useEffect(() => {
    if (variant !== "overlay") return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose?.();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [variant, onClose]);

  async function onFile(file: File | undefined) {
    if (!file) return;
    setBusyFile(true);
    try {
      const text = await decodeQrFromFile(file);
      if (text) {
        foundRef.current = true;
        onScanRef.current(text);
      } else {
        playSound("error");
        setStatus("No se encontró un código en esa foto.");
      }
    } catch {
      playSound("error");
      setStatus("No se pudo leer esa imagen.");
    } finally {
      setBusyFile(false);
    }
  }

  const body = (
    <div className="flex flex-col gap-4">
      <div
        className={cn(
          "qr-stage relative w-full overflow-hidden rounded-xl bg-surface-2",
          live ? "aspect-[3/4] sm:aspect-video" : "min-h-56",
        )}
      >
        <video
          ref={videoRef}
          className={cn(
            "size-full object-cover",
            live ? "opacity-100" : "opacity-0",
          )}
          autoPlay
          muted
          playsInline
        />
        {live ? <div className="qr-finder" aria-hidden /> : null}
        {!live ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center">
            <Camera className="size-8 text-olive" />
            <p className="text-sm text-muted">{status}</p>
          </div>
        ) : null}
        {live ? (
          <p className="absolute inset-x-3 bottom-3 rounded-md bg-bg/80 px-3 py-1.5 text-center text-xs text-fg">
            {status}
          </p>
        ) : null}
      </div>
      <div className="flex flex-wrap gap-2">
        <label
          className={cn(
            buttonVariants({ variant: "outline" }),
            "cursor-pointer",
          )}
        >
          <ImageIcon />
          {cameraFailed ? "Tomar o elegir foto" : "Usar foto"}
          <input
            type="file"
            accept="image/*"
            capture={cameraFailed ? "environment" : undefined}
            className="sr-only"
            disabled={busyFile}
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              void onFile(file);
            }}
          />
        </label>
        {variant === "overlay" && onClose ? (
          <Button type="button" variant="ghost" onClick={onClose}>
            Cerrar
          </Button>
        ) : null}
      </div>
      <p className="text-xs leading-relaxed text-muted">
        Si la cámara no está disponible, elige una foto del código. En el
        teléfono también puedes tomarla al momento.
      </p>
    </div>
  );

  if (variant === "page") return body;

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end justify-center bg-bg/92 p-4 backdrop-blur-sm sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label="Leer código"
    >
      <div className="max-h-[min(92dvh,44rem)] w-full max-w-lg overflow-y-auto rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-display text-lg font-medium">Leer código</h2>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
            aria-label="Cerrar"
            onClick={onClose}
          >
            <X className="size-5" />
          </button>
        </div>
        {body}
      </div>
    </div>
  );
}
