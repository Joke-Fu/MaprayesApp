import { useEffect, useRef, useState } from "react";
import { CHAOS_MESSAGES } from "@/lib/maprayes/guardians";
import { useSession } from "@/lib/store/session";
import { useSettings } from "@/lib/store/settings";
import { Button } from "@/components/ui/button";
import { GuardianSigil } from "./sigils";
import { notify } from "./notify";
import { playSound } from "@/lib/maprayes/sound";

export function ChaosLayer() {
  const chaos = useSession((s) => s.chaos);
  const stability = useSession((s) => s.stability);
  const tickStability = useSession((s) => s.tickStability);
  const calmChaos = useSession((s) => s.calmChaos);
  const releaseChaos = useSession((s) => s.releaseChaos);
  const chaosFontUnlocked = useSettings((s) => s.chaosFontUnlocked);
  const [msg, setMsg] = useState("");
  const unlockedToast = useRef(false);
  const [pos, setPos] = useState({ x: 72, y: 120 });

  useEffect(() => {
    if (chaos === "active" && !msg) {
      setMsg(
        CHAOS_MESSAGES[Math.floor(Math.random() * CHAOS_MESSAGES.length)] ?? "",
      );
    }
  }, [chaos, msg]);

  useEffect(() => {
    if (chaos !== "active") return;
    // 100 ticks × 300ms ≈ 30s until the chaos font unlocks.
    const id = window.setInterval(tickStability, 300);
    return () => window.clearInterval(id);
  }, [chaos, tickStability]);

  useEffect(() => {
    if (chaos === "off") return;
    const ms = chaos === "active" ? 9000 : 14000;
    const id = window.setInterval(() => {
      setPos({
        x: 24 + Math.random() * Math.max(40, window.innerWidth - 80),
        y: 80 + Math.random() * Math.max(40, window.innerHeight - 160),
      });
    }, ms);
    return () => window.clearInterval(id);
  }, [chaos]);

  useEffect(() => {
    if (
      stability === 0 &&
      chaos === "active" &&
      chaosFontUnlocked &&
      !unlockedToast.current
    ) {
      unlockedToast.current = true;
      notify(
        "La estabilidad se ha roto. La fuente del caos ahora es tuya.",
        "chaos",
        5000,
      );
    }
  }, [stability, chaos, chaosFontUnlocked]);

  if (chaos === "off") return null;

  return (
    <>
      <div className="chaos-scan" />
      <div
        className="chaos-drift text-olive"
        style={{ left: pos.x, top: pos.y }}
      >
        <GuardianSigil id="triczy" className="size-8" />
      </div>
      {chaos === "active" ? (
        <div
          className="pointer-events-none fixed top-0 right-0 left-0 z-50 px-4 pt-[max(10px,env(safe-area-inset-top))]"
          aria-label="Estabilidad"
        >
          <div className="ml-auto h-1.5 w-28 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-olive transition-[width] duration-500"
              style={{ width: `${stability}%` }}
            />
          </div>
        </div>
      ) : null}
      <div className="fixed right-4 bottom-[max(1.25rem,env(safe-area-inset-bottom))] z-50 flex flex-col items-end gap-2">
        {chaos === "active" && msg ? (
          <p className="max-w-[14rem] text-right font-display text-xs italic text-muted">
            {msg}
          </p>
        ) : (
          <p className="max-w-[14rem] text-right font-display text-xs italic text-muted">
            Triczy se esconde… pero aún observa.
          </p>
        )}
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            if (chaos === "active") {
              calmChaos();
              playSound("clear");
              notify("La calma es solo aparente…", "triczy", 3200);
            } else {
              const farewell = releaseChaos();
              playSound("guardian-remove", { guardian: "triczy" });
              notify(farewell, "triczy", 4000);
            }
          }}
        >
          {chaos === "active" ? "Calmar a Triczy" : "Liberar por completo"}
        </Button>
      </div>
    </>
  );
}
