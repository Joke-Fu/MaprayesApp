export function HomeSeal({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 120 120"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <circle cx="60" cy="60" r="46" stroke="currentColor" strokeWidth="1.2" opacity="0.7" />
      <circle cx="60" cy="60" r="32" stroke="currentColor" strokeWidth="0.8" opacity="0.5" />
      <circle cx="60" cy="60" r="6" fill="currentColor" opacity="0.85" />
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i * Math.PI) / 4 - Math.PI / 2;
        const x1 = 60 + Math.cos(a) * 14;
        const y1 = 60 + Math.sin(a) * 14;
        const x2 = 60 + Math.cos(a) * 44;
        const y2 = 60 + Math.sin(a) * 44;
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="currentColor"
            strokeWidth="1.1"
            opacity="0.65"
          />
        );
      })}
    </svg>
  );
}
