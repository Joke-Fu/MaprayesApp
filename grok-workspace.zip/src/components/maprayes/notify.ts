import { toast } from "sonner";
import type { GuardianId } from "@/lib/maprayes/guardians";

export type ToastKind = GuardianId | "default" | "full" | "chaos";

export function notify(
  message: string,
  kind: ToastKind = "default",
  duration = 2400,
) {
  toast(message, {
    duration,
    className: `map-toast map-toast-${kind}`,
  });
}
