import { useEffect } from "react";
import { useSession } from "@/lib/store/session";
import { useSettings } from "@/lib/store/settings";

export function ThemeSync() {
  const theme = useSettings((s) => s.theme);
  const textSize = useSettings((s) => s.textSize);
  const font = useSettings((s) => s.font);
  const primordialUnlocked = useSettings((s) => s.primordialUnlocked);
  const chaosFontUnlocked = useSettings((s) => s.chaosFontUnlocked);
  const guardianTheme = useSettings((s) => s.guardianTheme);
  const chaos = useSession((s) => s.chaos);
  const sequence = useSession((s) => s.sequence);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = theme;
    root.dataset.size = textSize;
    const allowedFont =
      font === "maprayes" && !primordialUnlocked
        ? "normal"
        : font === "caos" && !chaosFontUnlocked
          ? "normal"
          : font;
    root.dataset.font = allowedFont;
    if (chaos === "off") delete root.dataset.chaos;
    else root.dataset.chaos = chaos;

    const last = sequence[sequence.length - 1];
    const tint = guardianTheme && chaos === "off" && last;
    if (tint) {
      root.style.setProperty("--olive", `var(--g-${last})`);
      root.dataset.guardian = last;
    } else {
      root.style.removeProperty("--olive");
      delete root.dataset.guardian;
    }
  }, [
    theme,
    textSize,
    font,
    primordialUnlocked,
    chaosFontUnlocked,
    chaos,
    guardianTheme,
    sequence,
  ]);

  return null;
}
