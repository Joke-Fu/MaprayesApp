import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { notify } from "./notify";
import { playSound } from "@/lib/maprayes/sound";

export function CopyButton({
  value,
  label = "Copiar",
}: {
  value: string;
  label?: string;
}) {
  const [done, setDone] = useState(false);

  async function copy() {
    if (!value) {
      playSound("error");
      notify("No hay nada que copiar.");
      return;
    }
    try {
      await navigator.clipboard.writeText(value);
      setDone(true);
      playSound("copy");
      notify("Copiado al portapapeles.", "yudmiry");
      window.setTimeout(() => setDone(false), 1600);
    } catch {
      playSound("error");
      notify("No se pudo copiar. Selecciona el texto a mano.", "triczy");
    }
  }

  return (
    <Button type="button" variant="outline" size="sm" onClick={copy}>
      {done ? <Check /> : <Copy />}
      {label}
    </Button>
  );
}
