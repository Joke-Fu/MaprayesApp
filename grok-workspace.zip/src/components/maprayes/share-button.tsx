import { Check, Share2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { playSound } from "@/lib/maprayes/sound";
import {
  canNativeShare,
  shareText,
  telegramHref,
  whatsappHref,
} from "@/lib/maprayes/share";
import { notify } from "./notify";

export function ShareButton({
  value,
  label = "Compartir",
}: {
  value: string;
  label?: string;
}) {
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState(false);
  const native = typeof navigator !== "undefined" && canNativeShare(value || ".");
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent) {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  async function nativeShare() {
    if (!value) {
      playSound("error");
      notify("No hay nada que compartir.");
      return;
    }
    const result = await shareText(value);
    if (result === "cancel") return;
    if (result === "fail") {
      playSound("error");
      notify("No se pudo compartir.", "triczy");
      return;
    }
    playSound("share");
    setDone(true);
    notify(
      result === "shared"
        ? "Elige WhatsApp, Messenger o Bluetooth en la hoja del sistema."
        : "Copiado. Pégalo en WhatsApp, Messenger o donde quieras.",
      "lino",
    );
    window.setTimeout(() => setDone(false), 1600);
  }

  if (native) {
    return (
      <Button type="button" variant="outline" size="sm" onClick={() => void nativeShare()}>
        {done ? <Check /> : <Share2 />}
        {label}
      </Button>
    );
  }

  return (
    <div ref={rootRef} className="relative">
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => {
          if (!value) {
            playSound("error");
            notify("No hay nada que compartir.");
            return;
          }
          setOpen((v) => !v);
        }}
      >
        {done ? <Check /> : <Share2 />}
        {label}
      </Button>
      {open ? (
        <div className="absolute top-full left-0 z-40 mt-1 min-w-44 overflow-hidden rounded-lg bg-surface py-1 shadow-[var(--shadow-border)]">
          <button
            type="button"
            className="block w-full px-3 py-2.5 text-left text-sm hover:bg-surface-2"
            onClick={() => {
              void nativeShare();
              setOpen(false);
            }}
          >
            Copiar mensaje
          </button>
          <a
            className="block px-3 py-2.5 text-sm hover:bg-surface-2"
            href={whatsappHref(value)}
            target="_blank"
            rel="noreferrer"
            onClick={() => {
              playSound("share");
              setOpen(false);
            }}
          >
            WhatsApp
          </a>
          <a
            className="block px-3 py-2.5 text-sm hover:bg-surface-2"
            href={telegramHref(value)}
            target="_blank"
            rel="noreferrer"
            onClick={() => {
              playSound("share");
              setOpen(false);
            }}
          >
            Telegram
          </a>
        </div>
      ) : null}
    </div>
  );
}
