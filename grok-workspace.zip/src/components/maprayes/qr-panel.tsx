import { Download, QrCode, Share2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { GUARDIANS, type GuardianId } from "@/lib/maprayes/guardians";
import { buildQrPayload } from "@/lib/maprayes/cipher";
import { shareFiles, shareText } from "@/lib/maprayes/share";
import { useSession } from "@/lib/store/session";
import { GuardianSigil } from "./sigils";
import { CopyButton } from "./copy-button";
import { notify } from "./notify";
import { playSound } from "@/lib/maprayes/sound";

export function QrPanel({ cleanCode }: { cleanCode: string }) {
  const sequence = useSession((s) => s.sequence);
  const modes = useSession((s) => s.modes);
  const farewellText = useSession((s) => s.farewellText);
  const setFarewell = useSession((s) => s.setFarewell);
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [payload, setPayload] = useState("");

  useEffect(() => {
    if (!farewellText) return;
    void render(farewellText);
  }, [farewellText]);

  async function render(text: string) {
    try {
      const QRCode = (await import("qrcode")).default;
      const url = await QRCode.toDataURL(text, {
        width: 280,
        margin: 2,
        color: { dark: "#2A261F", light: "#F6EEE2" },
        errorCorrectionLevel: "M",
      });
      setDataUrl(url);
      setPayload(text);
    } catch {
      playSound("error");
      notify("No se pudo generar el código.", "triczy");
    }
  }

  async function generate() {
    if (!cleanCode) {
      playSound("error");
      notify("Escribe un texto primero.");
      return;
    }
    setFarewell(null);
    const text = buildQrPayload(cleanCode, sequence, modes);
    await render(text);
    playSound("qr");
    notify("Código listo para compartir.", "lino");
  }

  function clear() {
    setDataUrl(null);
    setPayload("");
    setFarewell(null);
  }

  async function shareQr() {
    if (!payload) {
      playSound("error");
      notify("Genera un código primero.");
      return;
    }
    let result: "shared" | "copied" | "cancel" | "fail" = "fail";
    if (dataUrl) {
      try {
        const blob = await (await fetch(dataUrl)).blob();
        const file = new File([blob], "maprayes.png", { type: "image/png" });
        result = await shareFiles([file], payload);
      } catch {
        result = await shareText(payload);
      }
    } else {
      result = await shareText(payload);
    }
    if (result === "cancel") return;
    if (result === "fail") {
      playSound("error");
      notify("No se pudo compartir.", "triczy");
      return;
    }
    playSound("share");
    notify(
      result === "shared"
        ? "Elige WhatsApp, Messenger o Bluetooth en la hoja del sistema."
        : "Payload copiado.",
      "lino",
    );
  }

  return (
    <section className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={() => void generate()}>
          <QrCode />
          Generar código
        </Button>
        <Button type="button" variant="outline" onClick={clear}>
          Limpiar
        </Button>
        {payload ? <CopyButton value={payload} label="Copiar payload" /> : null}
        {payload ? (
          <Button type="button" variant="outline" size="sm" onClick={() => void shareQr()}>
            <Share2 />
            Compartir
          </Button>
        ) : null}
        {dataUrl ? (
          <Button asChild variant="outline" size="sm">
            <a href={dataUrl} download="maprayes.png">
              <Download />
              Descargar
            </a>
          </Button>
        ) : null}
      </div>
      {dataUrl ? (
        <div className="flex flex-col items-center gap-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
          {sequence.length > 0 && !farewellText ? (
            <div className="flex flex-wrap items-center justify-center gap-2 text-olive">
              {sequence.map((id: GuardianId) => (
                <span key={id} className="inline-flex items-center gap-1 text-xs text-muted">
                  <GuardianSigil id={id} className="size-4" />
                  {GUARDIANS[id].initials}
                </span>
              ))}
            </div>
          ) : null}
          <img
            src={dataUrl}
            alt="Código Maprayés"
            width={220}
            height={220}
            className="rounded-md outline outline-1 -outline-offset-1 outline-black/10"
          />
          <p className="max-w-sm text-center font-mono text-xs break-all text-muted">
            {payload}
          </p>
        </div>
      ) : null}
    </section>
  );
}
