import { useEffect, useRef } from "react";
import { notify } from "@/components/maprayes/notify";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import { isRoomMsg, type RoomMsg } from "@/lib/maprayes/room-protocol";
import { playSound } from "@/lib/maprayes/sound";
import { useRoom } from "@/lib/store/room";
import { useSession } from "@/lib/store/session";

export function RoomMesh() {
  const code = useRoom((s) => s.code);
  const name = useRoom((s) => s.name);
  if (!code) return null;
  return <RoomMeshInner key={code} code={code} name={name} />;
}

function RoomMeshInner({ code, name }: { code: string; name: string }) {
  const isHost = useRoom((s) => s.isHost);
  const p2p = useP2PRoom({ room: code, name });
  const sendArmed = useRef(isHost);
  const skipGuardians = useRef(false);
  const seenRef = useRef(new Set<string>());
  const lastPeerCount = useRef(0);

  useEffect(() => {
    useRoom.getState().setMesh({ selfId: p2p.selfId, joined: p2p.joined, peers: p2p.peers });
  }, [p2p.selfId, p2p.joined, p2p.peers]);

  useEffect(() => {
    if (sendArmed.current) return;
    const id = window.setTimeout(() => {
      sendArmed.current = true;
    }, 1600);
    return () => window.clearTimeout(id);
  }, []);

  useEffect(() => {
    const connected = p2p.peers.filter((p) => p.connectionState === "connected");
    const n = connected.length;
    if (n > lastPeerCount.current) {
      playSound("join");
      notify("Alguien cruzó el umbral.", "yudmiry");
    } else if (n < lastPeerCount.current && lastPeerCount.current > 0) {
      notify("Un viajero se alejó.", "epheron");
    }
    lastPeerCount.current = n;

    const newcomers = connected.filter((p) => !seenRef.current.has(p.id));
    if (newcomers.length > 0 && sendArmed.current) {
      const incumbents = [p2p.selfId, ...seenRef.current].sort();
      if (incumbents[0] === p2p.selfId) {
        const snap = currentSnapshot();
        for (const peer of newcomers) p2p.send(snap, peer.id);
      }
    }
    seenRef.current = new Set(connected.map((p) => p.id));
  }, [p2p.peers, p2p.selfId, p2p.send]);

  useEffect(
    () =>
      p2p.onMessage((_from, data) => {
        if (!isRoomMsg(data)) return;
        applyRemote(data, () => {
          skipGuardians.current = true;
        });
        sendArmed.current = true;
      }),
    [p2p.onMessage],
  );

  const sequence = useSession((s) => s.sequence);
  const modes = useSession((s) => s.modes);
  const plain = useRoom((s) => s.plain);
  const origin = useRoom((s) => s.origin);

  useEffect(() => {
    if (!p2p.joined || !sendArmed.current) return;
    if (skipGuardians.current) {
      skipGuardians.current = false;
      return;
    }
    const msg: RoomMsg = { t: "guardians", sequence, modes };
    p2p.send(msg);
  }, [sequence, modes, p2p.joined, p2p.send]);

  useEffect(() => {
    if (!p2p.joined || !sendArmed.current) return;
    if (origin !== "local") return;
    p2p.send({ t: "text", plain } satisfies RoomMsg);
  }, [plain, origin, p2p.joined, p2p.send]);

  return null;
}

function currentSnapshot(): RoomMsg {
  const session = useSession.getState();
  const room = useRoom.getState();
  return {
    t: "snapshot",
    plain: room.plain,
    sequence: session.sequence,
    modes: session.modes,
  };
}

function applyRemote(msg: RoomMsg, markGuardians: () => void) {
  if (msg.t === "text") {
    useRoom.getState().setRemotePlain(msg.plain);
    return;
  }
  if (msg.t === "guardians" || msg.t === "snapshot") {
    const current = useSession.getState();
    const same =
      current.sequence.join() === msg.sequence.join() &&
      JSON.stringify(current.modes) === JSON.stringify(msg.modes);
    if (!same) {
      markGuardians();
      current.adoptSequence(msg.sequence, msg.modes);
    }
  }
  if (msg.t === "snapshot") {
    useRoom.getState().setRemotePlain(msg.plain);
  }
}
