import * as React from "react";
import { cn } from "@/lib/utils";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      type={type}
      className={cn(
        "h-11 w-full rounded-md bg-surface px-3 text-fg shadow-[var(--shadow-border)] placeholder:text-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-olive/40",
        className,
      )}
      {...props}
    />
  );
}

export { Input };
