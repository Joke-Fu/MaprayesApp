import * as React from "react";
import { cn } from "@/lib/utils";

function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "w-full min-h-32 resize-y rounded-md bg-surface px-3 py-3 text-fg shadow-[var(--shadow-border)] placeholder:text-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-olive/40",
        className,
      )}
      {...props}
    />
  );
}

export { Textarea };
