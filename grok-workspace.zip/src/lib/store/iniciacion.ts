import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { GuardianId } from "@/lib/maprayes/guardians";
import type { PracticeLevel } from "@/lib/maprayes/iniciacion";

export type Hits = Record<PracticeLevel, number>;

type IniciacionState = {
  hits: Hits;
  guardianHits: Partial<Record<GuardianId, number>>;
  registerHit: (level: PracticeLevel) => void;
  registerExtremo: (sequence: GuardianId[]) => void;
};

const EMPTY_HITS: Hits = {
  facil: 0,
  medio: 0,
  dificil: 0,
  extremo: 0,
  libre: 0,
};

export const useIniciacion = create<IniciacionState>()(
  persist(
    (set, get) => ({
      hits: { ...EMPTY_HITS },
      guardianHits: {},
      registerHit: (level) => {
        const hits = { ...get().hits, [level]: (get().hits[level] ?? 0) + 1 };
        set({ hits });
      },
      registerExtremo: (sequence) => {
        const hits = { ...get().hits, extremo: (get().hits.extremo ?? 0) + 1 };
        const guardianHits = { ...get().guardianHits };
        for (const id of new Set(sequence)) {
          guardianHits[id] = (guardianHits[id] ?? 0) + 1;
        }
        set({ hits, guardianHits });
      },
    }),
    { name: "maprayes-iniciacion" },
  ),
);
