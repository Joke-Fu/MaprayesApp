import { create } from "zustand";
import {
  canAddGuardian,
  EXIT_MESSAGES,
  isChaosCombo,
  isFullAlignment,
  type GuardianId,
} from "@/lib/maprayes/guardians";
import { useSettings, type ThemeName } from "./settings";

export type ChaosPhase = "off" | "active" | "residual";

type SessionState = {
  sequence: GuardianId[];
  modes: Partial<Record<GuardianId, boolean>>;
  chaos: ChaosPhase;
  stability: number;
  preTheme: ThemeName;
  farewellText: string | null;
  pendingCipher: string | null;
  primordialSeen: boolean;
  addGuardian: (id: GuardianId) => "ok" | "already" | "limit" | "chaos" | "primordial";
  removeGuardian: (index: number) => GuardianId | null;
  clearGuardians: () => void;
  setMode: (id: GuardianId, plus: boolean) => "ok" | "primordial";
  adoptSequence: (
    sequence: GuardianId[],
    modes: Partial<Record<GuardianId, boolean>>,
  ) => void;
  enterChaos: () => void;
  calmChaos: () => void;
  releaseChaos: () => string;
  tickStability: () => void;
  setFarewell: (text: string | null) => void;
  setPendingCipher: (text: string | null) => void;
};

export const useSession = create<SessionState>((set, get) => ({
  sequence: [],
  modes: {},
  chaos: "off",
  stability: 100,
  preTheme: "light",
  farewellText: null,
  pendingCipher: null,
  primordialSeen: false,

  addGuardian: (id) => {
    const { sequence, modes, chaos } = get();
    const check = canAddGuardian(sequence, modes, id);
    if (!check.ok) return check.reason;
    const nextSeq = [...sequence, id];
    const nextModes = { ...modes, [id]: true };
    set({ sequence: nextSeq, modes: nextModes });
    if (isChaosCombo(nextSeq, nextModes) && chaos === "off") {
      get().enterChaos();
      return "chaos";
    }
    if (isFullAlignment(nextSeq, nextModes) && !get().primordialSeen) {
      set({ primordialSeen: true });
      useSettings.getState().unlockPrimordial();
      return "primordial";
    }
    return "ok";
  },

  removeGuardian: (index) => {
    const { sequence, modes } = get();
    const id = sequence[index];
    if (!id) return null;
    const nextSeq = sequence.filter((_, i) => i !== index);
    const nextModes = { ...modes };
    delete nextModes[id];
    set({ sequence: nextSeq, modes: nextModes });
    return id;
  },

  clearGuardians: () => set({ sequence: [], modes: {}, primordialSeen: false }),

  setMode: (id, plus) => {
    const nextModes = { ...get().modes, [id]: plus };
    set({ modes: nextModes });
    if (isFullAlignment(get().sequence, nextModes) && !get().primordialSeen) {
      set({ primordialSeen: true });
      useSettings.getState().unlockPrimordial();
      return "primordial";
    }
    return "ok";
  },

  adoptSequence: (sequence, modes) => {
    set({ sequence, modes });
    if (isChaosCombo(sequence, modes) && get().chaos === "off") {
      get().enterChaos();
    }
    if (isFullAlignment(sequence, modes) && !get().primordialSeen) {
      set({ primordialSeen: true });
      useSettings.getState().unlockPrimordial();
    }
  },

  enterChaos: () => {
    const theme = useSettings.getState().theme;
    set({
      chaos: "active",
      stability: 100,
      preTheme: theme,
      sequence: ["triczy", "garbanza", "lino"],
      modes: { triczy: true, garbanza: true, lino: true },
    });
  },

  calmChaos: () => {
    const pre = get().preTheme;
    useSettings.getState().setTheme(pre);
    set({ chaos: "residual" });
  },

  releaseChaos: () => {
    const msg =
      EXIT_MESSAGES[Math.floor(Math.random() * EXIT_MESSAGES.length)] ??
      "Triczy se retira… por ahora.";
    set({
      chaos: "off",
      sequence: [],
      modes: {},
      stability: 100,
      farewellText: msg,
    });
    return msg;
  },

  tickStability: () => {
    const { chaos, stability } = get();
    if (chaos !== "active") return;
    const next = Math.max(0, stability - 1);
    set({ stability: next });
    if (next === 0) useSettings.getState().unlockChaosFont();
  },

  setFarewell: (farewellText) => set({ farewellText }),
  setPendingCipher: (pendingCipher) => set({ pendingCipher }),
}));
