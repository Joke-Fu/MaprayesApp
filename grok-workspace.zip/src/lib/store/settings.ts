import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ThemeName = "light" | "dark" | "night";
export type TextSize = "small" | "normal" | "large";
export type FontName = "normal" | "maprayes" | "caos";

type SettingsState = {
  theme: ThemeName;
  textSize: TextSize;
  font: FontName;
  showCounters: boolean;
  soundEnabled: boolean;
  guardianTheme: boolean;
  favorites: string[];
  primordialUnlocked: boolean;
  chaosFontUnlocked: boolean;
  setTheme: (theme: ThemeName) => void;
  setTextSize: (size: TextSize) => void;
  setFont: (font: FontName) => void;
  setShowCounters: (value: boolean) => void;
  setSoundEnabled: (value: boolean) => void;
  setGuardianTheme: (value: boolean) => void;
  toggleFavorite: (code: string) => void;
  unlockPrimordial: () => void;
  unlockChaosFont: () => void;
};

export const useSettings = create<SettingsState>()(
  persist(
    (set, get) => ({
      theme: "light",
      textSize: "normal",
      font: "normal",
      showCounters: false,
      soundEnabled: true,
      guardianTheme: true,
      favorites: [],
      primordialUnlocked: false,
      chaosFontUnlocked: false,
      setTheme: (theme) => set({ theme }),
      setTextSize: (textSize) => set({ textSize }),
      setFont: (font) => set({ font }),
      setShowCounters: (showCounters) => set({ showCounters }),
      setSoundEnabled: (soundEnabled) => set({ soundEnabled }),
      setGuardianTheme: (guardianTheme) => set({ guardianTheme }),
      toggleFavorite: (code) => {
        const current = get().favorites;
        const favorites = current.includes(code)
          ? current.filter((c) => c !== code)
          : [...current, code];
        set({ favorites });
      },
      unlockPrimordial: () => set({ primordialUnlocked: true }),
      unlockChaosFont: () => set({ chaosFontUnlocked: true }),
    }),
    {
      name: "maprayes-settings",
      partialize: (s) => ({
        theme: s.theme,
        textSize: s.textSize,
        font: s.font,
        showCounters: s.showCounters,
        soundEnabled: s.soundEnabled,
        guardianTheme: s.guardianTheme,
        favorites: s.favorites,
        primordialUnlocked: s.primordialUnlocked,
        chaosFontUnlocked: s.chaosFontUnlocked,
      }),
    },
  ),
);
