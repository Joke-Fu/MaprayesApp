import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { PeerInfo } from "@/lib/multiplayer";
import { generateRoomCode, parseRoomCode } from "@/lib/maprayes/room-code";
import type { RoomView } from "@/lib/maprayes/room-protocol";

type Origin = "local" | "remote";

type RoomState = {
  name: string;
  view: RoomView;
  code: string | null;
  isHost: boolean;
  selfId: string | null;
  joined: boolean;
  peers: PeerInfo[];
  plain: string;
  origin: Origin;
  setName: (name: string) => void;
  setView: (view: RoomView) => void;
  createRoom: () => string;
  joinRoom: (raw: string) => string | null;
  leaveRoom: () => void;
  setMesh: (patch: { selfId?: string; joined?: boolean; peers?: PeerInfo[] }) => void;
  setLocalPlain: (plain: string) => void;
  setRemotePlain: (plain: string) => void;
};

function cleanName(name: string): string {
  const trimmed = name.trim().slice(0, 24);
  return trimmed || "Viajero";
}

export const useRoom = create<RoomState>()(
  persist(
    (set, get) => ({
      name: "Viajero",
      view: "plain",
      code: null,
      isHost: false,
      selfId: null,
      joined: false,
      peers: [],
      plain: "",
      origin: "local",
      setName: (name) => set({ name: cleanName(name) }),
      setView: (view) => set({ view }),
      createRoom: () => {
        const code = generateRoomCode();
        set({
          code,
          isHost: true,
          joined: false,
          peers: [],
          selfId: null,
          plain: get().plain,
          origin: "local",
        });
        return code;
      },
      joinRoom: (raw) => {
        const code = parseRoomCode(raw);
        if (!code) return null;
        set({
          code,
          isHost: false,
          joined: false,
          peers: [],
          selfId: null,
          plain: "",
          origin: "local",
        });
        return code;
      },
      leaveRoom: () =>
        set({
          code: null,
          isHost: false,
          joined: false,
          peers: [],
          selfId: null,
        }),
      setMesh: (patch) => set(patch),
      setLocalPlain: (plain) => {
        const cur = get();
        if (cur.plain === plain && cur.origin === "local") return;
        set({ plain, origin: "local" });
      },
      setRemotePlain: (plain) => set({ plain, origin: "remote" }),
    }),
    {
      name: "maprayes-room",
      partialize: (s) => ({ name: s.name, view: s.view }),
    },
  ),
);
