import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  recordAffinity,
  type AffinityCounts,
  type AffinityPairs,
} from "@/lib/maprayes/affinity";
import type { GuardianId } from "@/lib/maprayes/guardians";

type AffinityState = {
  counts: AffinityCounts;
  pairs: AffinityPairs;
  record: (sequence: GuardianId[]) => void;
  forget: () => void;
};

export const useAffinity = create<AffinityState>()(
  persist(
    (set, get) => ({
      counts: {},
      pairs: {},
      record: (sequence) => {
        const next = recordAffinity(get().counts, get().pairs, sequence);
        set(next);
      },
      forget: () => set({ counts: {}, pairs: {} }),
    }),
    { name: "maprayes-affinity" },
  ),
);
