import assert from "node:assert/strict";
import test from "node:test";
import { generateRoomCode, parseRoomCode } from "./room-code.ts";

test("generated codes match MAP-XXXX", () => {
  for (let i = 0; i < 20; i += 1) {
    const code = generateRoomCode();
    assert.match(code, /^MAP-[A-Z0-9]{4}$/);
    assert.equal(parseRoomCode(code), code);
  }
});

test("parse accepts loose typing", () => {
  assert.equal(parseRoomCode("map-7x3k"), "MAP-7X3K");
  assert.equal(parseRoomCode("7X3K"), "MAP-7X3K");
  assert.equal(parseRoomCode("  MAP 7x3k "), "MAP-7X3K");
  assert.equal(parseRoomCode("no"), null);
  assert.equal(parseRoomCode("MAP-7"), null);
  assert.equal(parseRoomCode("MAP-****"), null);
});
