export const GUARDIAN_IDS = [
  "lino",
  "garbanza",
  "yudmiry",
  "escrimedes",
  "oithar",
  "epheron",
  "willy",
  "triczy",
] as const;

export type GuardianId = (typeof GUARDIAN_IDS)[number];

export const REQUIRED_ORDER: GuardianId[] = [
  "lino",
  "garbanza",
  "yudmiry",
  "escrimedes",
  "oithar",
  "epheron",
  "willy",
  "triczy",
];

export type Guardian = {
  id: GuardianId;
  name: string;
  epithet: string;
  lore: string;
  help: string;
  initials: string;
  displacement: string;
  /** Fixed Caesar shift. Dual-mode guardians leave this undefined. */
  shift?: number;
  plus?: number;
  minus?: number;
  plusLabel?: string;
  minusLabel?: string;
  addPhrase: string;
  removePhrase: string;
  accent: string;
};

export const GUARDIANS: Record<GuardianId, Guardian> = {
  lino: {
    id: "lino",
    name: "Lino Mapray",
    epithet: "El instinto. El origen. La llama que no necesita aprobación.",
    lore: "Lino, felino de pelaje capuchino y alma de león, representa la autenticidad y el impulso puro. Desplaza el lenguaje con decisión, sin filtros ni adornos.",
    help: "La llama habla claro y directo.",
    initials: "LI",
    displacement: "+1",
    shift: 1,
    addPhrase: "La llama habla sin filtros. Puro instinto.",
    removePhrase: "La llama se apaga… por ahora.",
    accent: "var(--g-lino)",
  },
  garbanza: {
    id: "garbanza",
    name: "Garbanza",
    epithet: "Ternura en desequilibrio. Dama de la contradicción.",
    lore: "Gata cálico de moño rojo, Garbanza cambia entre dulzura y picardía. Su traducción oscila: una caricia o una broma con filo.",
    help: "¿Dulce o picante? Depende de su humor.",
    initials: "GA",
    displacement: "+5 picante o −5 suave",
    plus: 5,
    minus: -5,
    plusLabel: "Picante +5",
    minusLabel: "Suave −5",
    addPhrase: "Prrr~ ¿Dulce hoy… o con picante?",
    removePhrase: "Garbanza se va enfurruñada.",
    accent: "var(--g-garbanza)",
  },
  yudmiry: {
    id: "yudmiry",
    name: "Yudmiry",
    epithet: "Dualidad, espejos, umbrales.",
    lore: "Yudmiry abre portales donde otros ven paredes. Simboliza el cruce entre lo real y lo invisible. Su desplazamiento transforma el mensaje con suavidad, pero dejando marcas.",
    help: "Todo tiene dos caras. Elige la que quieras ver.",
    initials: "YU",
    displacement: "+2",
    shift: 2,
    addPhrase: "Dos caras del espejo. Elige una.",
    removePhrase: "El portal se cierra. El reflejo desaparece.",
    accent: "var(--g-yudmiry)",
  },
  escrimedes: {
    id: "escrimedes",
    name: "Escrímedes",
    epithet: "El testigo, el escriba del tiempo.",
    lore: "Habitante de la memoria antigua, corrige con firmeza lo que otros olvidan. Cada letra que toca revive algo que alguna vez se escribió.",
    help: "Nada se pierde. Todo se reescribe.",
    initials: "ES",
    displacement: "−3",
    shift: -3,
    addPhrase: "Nada se pierde. Todo se reescribe.",
    removePhrase: "El pergamino se guarda. La memoria espera.",
    accent: "var(--g-escrimedes)",
  },
  oithar: {
    id: "oithar",
    name: "Oithar",
    epithet: "Espasmo de mente, distorsión lúcida.",
    lore: "Criatura nacida del vértigo entre parálisis y lucidez. Oithar vibra entre lo que fue y lo que podría ser. Sus traducciones tiemblan, como si la lengua misma dudara.",
    help: "El mensaje tiembla… pero llega.",
    initials: "OI",
    displacement: "+8 vértigo o −8 lucidez",
    plus: 8,
    minus: -8,
    plusLabel: "Vértigo +8",
    minusLabel: "Lucidez −8",
    addPhrase: "El mensaje tiembla… pero siempre llega.",
    removePhrase: "El vértigo cesa. Todo vuelve a estar quieto.",
    accent: "var(--g-oithar)",
  },
  epheron: {
    id: "epheron",
    name: "Ephëron",
    epithet: "El susurro final. El lenguaje que muere y renace.",
    lore: "Ephëron no traduce: purga. Cada desplazamiento arrastra palabras al umbral del olvido. Lo que queda, brilla con una luz melancólica.",
    help: "Solo queda lo que realmente importa.",
    initials: "EP",
    displacement: "−9",
    shift: -9,
    addPhrase: "La luz se atenúa. Solo queda lo esencial.",
    removePhrase: "La vela se apaga. El silencio brilla.",
    accent: "var(--g-epheron)",
  },
  willy: {
    id: "willy",
    name: "Willy",
    epithet: "El susurro silencioso. El alma del refugio.",
    lore: "Willy es un ser introvertido y reservado, que prefiere observar desde las sombras. Representa la introspección y la sensibilidad oculta. Su lenguaje es suave y sus acciones pasan desapercibidas, pero su presencia es un bálsamo para quienes buscan consuelo en la quietud.",
    help: "El silencio entiende lo que las palabras no dicen.",
    initials: "WI",
    displacement: "+4 sutil o −2 invisible",
    plus: 4,
    minus: -2,
    plusLabel: "Sutil +4",
    minusLabel: "Invisible −2",
    addPhrase: "La quietud susurra… y entiende.",
    removePhrase: "El susurro se aleja… pero deja paz.",
    accent: "var(--g-willy)",
  },
  triczy: {
    id: "triczy",
    name: "Triczy",
    epithet: "Juguetón, impredecible, travieso.",
    lore: "Triczy, criatura indefinida que cambia de forma a voluntad, es el maestro del caos lúdico. Susurra trampas, teje engaños y altera el lenguaje como parte de su juego eterno.",
    help: "¿Seguro que entendiste bien?",
    initials: "TR",
    displacement: "ciclo caótico +6, −4, +1, −4, +3, −2",
    addPhrase: "Jejeje… ¿de verdad me has invitado?",
    removePhrase: "Triczy guiña un ojo y se esfuma.",
    accent: "var(--g-triczy)",
  },
};

export const TRICZY_SHIFTS = [6, -4, 1, -4, 3, -2];

export const WHISPERS = [
  "Los Guardianes están observando…",
  "Triczy ya sabe qué vas a escribir hoy.",
  "Lino no necesita que lo saludes.",
  "Yudmiry te devuelve la mirada.",
  "Ephëron cuenta los segundos que faltan.",
  "Willy susurra desde las sombras.",
  "El caos nunca duerme… solo espera.",
  "Garbanza tiene ganas de jugar.",
  "Oithar entra en lucidez.",
  "Maprayés recuerda tu nombre.",
  "Escrímedes toma la pluma.",
  "Triczy quiere seguir jugando.",
];

export const CHAOS_MESSAGES = [
  "Triczy teje sombras en el código…",
  "El caos susurra tu nombre.",
  "¿Seguro que quieres seguir descifrando?",
  "Triczy cambió una letra… ¿la notas?",
  "El mensaje miente. O quizás no.",
  "Jejeje… ¿crees que me controlas?",
];

export const EXIT_MESSAGES = [
  "Triczy se desvanece… por ahora.",
  "El caos retrocede. Pero vuelve siempre.",
  "Has escapado… esta vez.",
  "Triczy guiña un ojo y desaparece.",
  "Silencio. Demasiado silencio.",
  "El portal se cierra… ¿o no?",
  "Triczy dejó un regalito en tu código.",
  "No mires atrás.",
  "El código está limpio… ¿seguro?",
  "Triczy promete portarse bien… mentira.",
];

export const PRIMORDIAL_LORE =
  "Maprayés solo permite seis guardianes a la vez. El equilibrio se rompería de otro modo… Salvo cuando los ocho se alinean en el orden antiguo, con la voluntad traviesa justa, el vértigo controlado y el alma del refugio oculta, callada, sin eco. Entonces Triczy, guardián del caos lúdico, rompe el límite por diversión y deja pasar el mensaje completo. Se dice que en ese instante el lenguaje recuerda su primer aliento y revela su forma primordial.";

export function isDualMode(id: GuardianId): boolean {
  const g = GUARDIANS[id];
  return g.plus !== undefined && g.minus !== undefined;
}

export function canAddGuardian(
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
  guardian: GuardianId,
): { ok: true } | { ok: false; reason: "already" | "limit" } {
  if (sequence.includes(guardian)) return { ok: false, reason: "already" };
  const nextIndex = sequence.length;
  const prefixMatch = sequence.every((g, i) => g === REQUIRED_ORDER[i]);
  const nextIsRequired = REQUIRED_ORDER[nextIndex] === guardian;
  const modesOk =
    modes.garbanza === true && (nextIndex < 4 || modes.oithar === true);
  const allowingFull =
    nextIndex < 8 && prefixMatch && nextIsRequired && (nextIndex < 1 || modesOk);
  if (sequence.length >= 6 && !allowingFull) {
    return { ok: false, reason: "limit" };
  }
  return { ok: true };
}

export function isChaosCombo(
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): boolean {
  return (
    sequence.length === 3 &&
    sequence[0] === "triczy" &&
    sequence[1] === "garbanza" &&
    sequence[2] === "lino" &&
    modes.garbanza === true
  );
}

export function isFullAlignment(
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): boolean {
  return (
    sequence.length === 8 &&
    sequence.every((g, i) => g === REQUIRED_ORDER[i]) &&
    modes.garbanza === true &&
    modes.oithar === true &&
    modes.willy === false
  );
}

export function isFullPrefix(
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): boolean {
  return (
    sequence.length === 8 &&
    sequence.every((g, i) => g === REQUIRED_ORDER[i]) &&
    modes.garbanza === true &&
    modes.oithar === true
  );
}

export function mythicPower(
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): number {
  if (sequence.length === 0) return 0;
  let power = sequence.length * 15;
  if (sequence.includes("triczy")) power += 30;
  if (sequence.includes("oithar") && modes.oithar) power += 20;
  if (sequence.includes("garbanza") && modes.garbanza) power += 10;
  return Math.min(power, 100);
}
