import { GUARDIAN_IDS, GUARDIANS, type GuardianId } from "./guardians.ts";
import type { PracticeLevel } from "./iniciacion.ts";

export type Relic = {
  id: string;
  title: string;
  hint: string;
  kind: "level" | "guardian";
  level?: Exclude<PracticeLevel, "libre">;
  guardian?: GuardianId;
  threshold: number;
};

const LEVEL_TITLES: Record<Exclude<PracticeLevel, "libre">, Record<number, string>> = {
  facil: {
    10: "Primer aliento",
    25: "Aprendiz del velo",
    50: "Lectura clara",
    75: "Ojo despierto",
    100: "Escriba novicio",
  },
  medio: {
    10: "Paso del umbral",
    25: "Eco doble",
    50: "Manuscrito vivo",
    75: "Traductor errante",
    100: "Custodio menor",
  },
  dificil: {
    10: "Lengua antigua",
    25: "Cifrado profundo",
    50: "Velo rasgado",
    75: "Arquitecto del signo",
    100: "Oráculo del código",
  },
  extremo: {
    10: "Primer pacto",
    25: "Concilio breve",
    50: "Alquimia de voluntades",
    75: "Consejo velado",
    100: "Alineación vivida",
  },
};

const LEVEL_HINT: Record<Exclude<PracticeLevel, "libre">, string> = {
  facil: "Aciertos en Fácil",
  medio: "Aciertos en Medio",
  dificil: "Aciertos en Difícil",
  extremo: "Aciertos en Extremo",
};

const GUARDIAN_RELIC: Record<GuardianId, string> = {
  lino: "Llama fiel",
  garbanza: "Moño de contradicción",
  yudmiry: "Espejo abierto",
  escrimedes: "Tinta eterna",
  oithar: "Vértigo lúcido",
  epheron: "Vela última",
  willy: "Pacto sereno",
  triczy: "Travesura contenida",
};

const THRESHOLDS = [10, 25, 50, 75, 100] as const;
const GUARDIAN_THRESHOLD = 10;

export const RELICS: Relic[] = [
  ...(["facil", "medio", "dificil", "extremo"] as const).flatMap((level) =>
    THRESHOLDS.map((threshold) => ({
      id: `${level}-${threshold}`,
      title: LEVEL_TITLES[level][threshold] ?? `${threshold}`,
      hint: `${LEVEL_HINT[level]}: ${threshold}`,
      kind: "level" as const,
      level,
      threshold,
    })),
  ),
  ...GUARDIAN_IDS.map((guardian) => ({
    id: `guardian-${guardian}`,
    title: GUARDIAN_RELIC[guardian],
    hint: `${GUARDIAN_THRESHOLD} aciertos en Extremo con ${GUARDIANS[guardian].name}`,
    kind: "guardian" as const,
    guardian,
    threshold: GUARDIAN_THRESHOLD,
  })),
];

export type RelicStats = {
  hits: Record<PracticeLevel, number>;
  guardianHits: Partial<Record<GuardianId, number>>;
};

export function relicUnlocked(relic: Relic, stats: RelicStats): boolean {
  if (relic.kind === "guardian" && relic.guardian) {
    return (stats.guardianHits[relic.guardian] ?? 0) >= relic.threshold;
  }
  if (relic.level) return (stats.hits[relic.level] ?? 0) >= relic.threshold;
  return false;
}

export function unlockedCount(stats: RelicStats): number {
  return RELICS.filter((relic) => relicUnlocked(relic, stats)).length;
}
