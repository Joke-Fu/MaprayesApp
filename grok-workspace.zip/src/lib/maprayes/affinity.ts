import { hasEncodableGlyph } from "./cipher.ts";
import { GUARDIAN_IDS, type GuardianId } from "./guardians.ts";

export type AffinityCounts = Partial<Record<GuardianId, number>>;
export type AffinityPairs = Record<string, number>;

export function pairKey(a: GuardianId, b: GuardianId): string {
  return a < b ? `${a}|${b}` : `${b}|${a}`;
}

export function parsePairKey(key: string): [GuardianId, GuardianId] | null {
  const [a, b] = key.split("|");
  if (!a || !b) return null;
  if (!GUARDIAN_IDS.includes(a as GuardianId)) return null;
  if (!GUARDIAN_IDS.includes(b as GuardianId)) return null;
  return [a as GuardianId, b as GuardianId];
}

export function recordAffinity(
  counts: AffinityCounts,
  pairs: AffinityPairs,
  sequence: GuardianId[],
): { counts: AffinityCounts; pairs: AffinityPairs } {
  const unique = [...new Set(sequence)];
  if (unique.length < 2) return { counts, pairs };
  const nextCounts = { ...counts };
  const nextPairs = { ...pairs };
  for (const id of unique) {
    nextCounts[id] = (nextCounts[id] ?? 0) + 1;
  }
  for (let i = 0; i < unique.length; i += 1) {
    for (let j = i + 1; j < unique.length; j += 1) {
      const left = unique[i];
      const right = unique[j];
      if (!left || !right) continue;
      const key = pairKey(left, right);
      nextPairs[key] = (nextPairs[key] ?? 0) + 1;
    }
  }
  return { counts: nextCounts, pairs: nextPairs };
}

export function maxValue(values: number[]): number {
  let max = 0;
  for (const n of values) if (n > max) max = n;
  return max;
}

/** Affinity is only recorded when a real message is encoded with 2+ guardians. */
export function shouldRecordAffinity(sequence: GuardianId[], text: string): boolean {
  if (sequence.length < 2) return false;
  if (!text.trim()) return false;
  return hasEncodableGlyph(text);
}
