import assert from "node:assert/strict";
import test from "node:test";
import { pairKey, parsePairKey, recordAffinity, shouldRecordAffinity } from "./affinity.ts";

test("pair keys are order-invariant", () => {
  assert.equal(pairKey("lino", "garbanza"), pairKey("garbanza", "lino"));
  assert.deepEqual(parsePairKey(pairKey("willy", "triczy")), ["triczy", "willy"]);
});

test("recordAffinity ignores lonely guardians", () => {
  const next = recordAffinity({}, {}, ["lino"]);
  assert.deepEqual(next.counts, {});
  assert.deepEqual(next.pairs, {});
});

test("recordAffinity counts pairs and nodes", () => {
  const first = recordAffinity({}, {}, ["lino", "garbanza", "yudmiry"]);
  assert.equal(first.counts.lino, 1);
  assert.equal(first.counts.garbanza, 1);
  assert.equal(first.counts.yudmiry, 1);
  assert.equal(first.pairs[pairKey("lino", "garbanza")], 1);
  assert.equal(first.pairs[pairKey("lino", "yudmiry")], 1);
  assert.equal(first.pairs[pairKey("garbanza", "yudmiry")], 1);
  const second = recordAffinity(first.counts, first.pairs, ["lino", "garbanza"]);
  assert.equal(second.counts.lino, 2);
  assert.equal(second.pairs[pairKey("lino", "garbanza")], 2);
  assert.equal(second.pairs[pairKey("lino", "yudmiry")], 1);
});

test("shouldRecordAffinity waits for a real encoded glyph and a pair", () => {
  assert.equal(shouldRecordAffinity([], "hola"), false);
  assert.equal(shouldRecordAffinity(["lino"], "hola"), false);
  assert.equal(shouldRecordAffinity(["lino", "garbanza"], "   "), false);
  assert.equal(shouldRecordAffinity(["lino", "garbanza"], "😂"), false);
  assert.equal(shouldRecordAffinity(["lino", "garbanza"], "hola"), true);
});
