import assert from "node:assert/strict";
import test from "node:test";
import { encodeToMaprayes, encodeWithGuardians, hasEncodableGlyph } from "./cipher.ts";
import { PHRASES, WORDS } from "./iniciacion-data.ts";
import {
  answersMatch,
  makeDrillPrompt,
  makeExtremoChallenge,
  normalizePractice,
} from "./iniciacion.ts";
import { RELICS, relicUnlocked } from "./reliquias.ts";

test("corpus encodes without invalid glyphs", () => {
  const all = [
    ...WORDS.facil,
    ...WORDS.medio,
    ...WORDS.dificil,
    ...PHRASES.facil,
    ...PHRASES.medio,
    ...PHRASES.dificil,
  ];
  assert.ok(all.length >= 40);
  for (const item of all) {
    const { invalid, code } = encodeToMaprayes(item);
    assert.equal(invalid, false, item);
    assert.ok(code.length > 0, item);
    assert.equal(hasEncodableGlyph(item), true, item);
  }
});

test("answersMatch ignores case and extra spaces", () => {
  assert.equal(answersMatch("hola mundo", "  HOLA   MUNDO "), true);
  assert.equal(answersMatch("café", "cafe"), false);
  assert.equal(normalizePractice("río  alto"), "RÍO ALTO");
});

test("drill prompt encodes the plaintext", () => {
  const used = new Set<string>();
  const prompt = makeDrillPrompt("facil", "palabras", used);
  const { code } = encodeToMaprayes(prompt.plaintext);
  assert.equal(prompt.cipher, code);
  assert.ok(prompt.plaintext.length > 0);
});

test("extremo challenge differs from the unguarded encoding", () => {
  const used = new Set<string>();
  const challenge = makeExtremoChallenge(used);
  const base = encodeToMaprayes(challenge.plaintext).code;
  assert.notEqual(challenge.target, base);
  const { code } = encodeWithGuardians(
    challenge.plaintext,
    challenge.sequence,
    challenge.modes,
  );
  assert.equal(code, challenge.target);
  assert.ok(challenge.sequence.length >= 1);
});

test("relics unlock from persisted hits", () => {
  const empty = {
    hits: { facil: 0, medio: 0, dificil: 0, extremo: 0, libre: 0 },
    guardianHits: {},
  };
  const first = RELICS.find((r) => r.id === "facil-10");
  assert.ok(first);
  assert.equal(relicUnlocked(first, empty), false);
  assert.equal(
    relicUnlocked(first, { ...empty, hits: { ...empty.hits, facil: 10 } }),
    true,
  );
  const lino = RELICS.find((r) => r.id === "guardian-lino");
  assert.ok(lino);
  assert.equal(
    relicUnlocked(lino, { ...empty, guardianHits: { lino: 10 } }),
    true,
  );
});
