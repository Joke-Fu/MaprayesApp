import assert from "node:assert/strict";
import test from "node:test";
import {
  applySequence,
  buildMythicPrefix,
  decodeFromMaprayes,
  decodeWithGuardians,
  encodeToMaprayes,
  encodeWithGuardians,
  hasEncodableGlyph,
  parseMythicPrefix,
} from "./cipher.ts";
import { ALFABETO, LETTERS } from "./alphabet.ts";
import {
  canAddGuardian,
  isChaosCombo,
  isFullAlignment,
  REQUIRED_ORDER,
  type GuardianId,
} from "./guardians.ts";
import { looksLikeMaprayes } from "./qr-decode.ts";

test("Hola roundtrips to uppercase", () => {
  const { code, invalid } = encodeToMaprayes("Hola");
  assert.equal(invalid, false);
  assert.equal(decodeFromMaprayes(code), "HOLA");
  assert.equal(hasEncodableGlyph("Hola"), true);
  assert.equal(hasEncodableGlyph("   "), false);
});

test("spaces become word separators", () => {
  const { code } = encodeToMaprayes("hola mundo");
  assert.equal(code.includes("||"), true);
  assert.equal(decodeFromMaprayes(code), "HOLA MUNDO");
});

test("every letter roundtrips", () => {
  for (const letter of LETTERS) {
    const { code, invalid } = encodeToMaprayes(letter);
    assert.equal(invalid, false, letter);
    assert.equal(decodeFromMaprayes(code), letter, letter);
  }
});

test("digits 0-9 roundtrip", () => {
  for (let n = 0; n <= 9; n++) {
    const ch = String(n);
    const { code } = encodeToMaprayes(ch);
    assert.equal(decodeFromMaprayes(code), ch, ch);
  }
});

test("lino +1 turns A into B", () => {
  const { code } = encodeWithGuardians("A", ["lino"], { lino: true });
  assert.equal(decodeFromMaprayes(code), "B");
});

test("guardian sequence roundtrips through reverse", () => {
  const seq: GuardianId[] = ["lino", "yudmiry", "escrimedes"];
  const modes = { lino: true, yudmiry: true, escrimedes: true };
  const { code } = encodeWithGuardians("Maprayes", seq, modes);
  const reversed = applySequence(code, seq, modes, true);
  assert.equal(decodeFromMaprayes(reversed), "MAPRAYES");
});

test("garbanza picante +5 and reverse", () => {
  const { code } = encodeWithGuardians("A", ["garbanza"], { garbanza: true });
  assert.equal(decodeFromMaprayes(code), "F");
  const back = applySequence(code, ["garbanza"], { garbanza: true }, true);
  assert.equal(decodeFromMaprayes(back), "A");
});

test("accented letters cycle independently", () => {
  const { code } = encodeWithGuardians("Á", ["lino"], { lino: true });
  assert.equal(decodeFromMaprayes(code), "É");
});

test("mythic prefix encodes dual modes", () => {
  const prefix = buildMythicPrefix(
    ["lino", "garbanza", "willy"],
    { lino: true, garbanza: false, willy: false },
  );
  assert.equal(prefix, "[MYTHIC:LI,GA-5,WI-2] ");
  const parsed = parseMythicPrefix(prefix + "(1)1");
  assert.deepEqual(parsed.sequence, ["lino", "garbanza", "willy"]);
  assert.equal(parsed.modes.garbanza, false);
  assert.equal(parsed.modes.willy, false);
  assert.equal(parsed.clean, "(1)1");
});

test("decodeWithGuardians adopts prefix sequence", () => {
  const { code } = encodeWithGuardians("Casa", ["lino"], { lino: true });
  const payload = buildMythicPrefix(["lino"], { lino: true }) + code;
  const { text, parsed } = decodeWithGuardians(payload, [], {});
  assert.equal(text, "CASA");
  assert.deepEqual(parsed.sequence, ["lino"]);
});

test("chaos combo is triczy, garbanza picante, lino", () => {
  assert.equal(
    isChaosCombo(["triczy", "garbanza", "lino"], { garbanza: true }),
    true,
  );
  assert.equal(
    isChaosCombo(["triczy", "garbanza", "lino"], { garbanza: false }),
    false,
  );
});

test("seventh guardian only in ancient-order prefix", () => {
  const sixRandom: GuardianId[] = [
    "triczy",
    "lino",
    "garbanza",
    "yudmiry",
    "oithar",
    "epheron",
  ];
  const blocked = canAddGuardian(sixRandom, { garbanza: true, oithar: true }, "willy");
  assert.equal(blocked.ok, false);

  const sixOrder = REQUIRED_ORDER.slice(0, 6);
  const allowed = canAddGuardian(sixOrder, { garbanza: true, oithar: true }, "willy");
  assert.equal(allowed.ok, true);
});

test("full alignment requires willy invisible", () => {
  const modesTrue = {
    garbanza: true,
    oithar: true,
    willy: true,
    lino: true,
  };
  assert.equal(isFullAlignment(REQUIRED_ORDER, modesTrue), false);
  assert.equal(
    isFullAlignment(REQUIRED_ORDER, { ...modesTrue, willy: false }),
    true,
  );
});

test("unknown characters flag invalid", () => {
  const { invalid, code } = encodeToMaprayes("hola😀");
  assert.equal(invalid, true);
  assert.equal(code.includes("?"), true);
});

test("codebook has 27 letters including Ñ", () => {
  const letters = Object.values(ALFABETO).filter((c) => /^[A-ZÑÁÉÍÓÚ]$/.test(c));
  assert.equal(letters.includes("Ñ"), true);
  assert.equal(LETTERS.length, 27);
});

test("looksLikeMaprayes detects codes and mythic prefixes", () => {
  assert.equal(looksLikeMaprayes("(1)8(2)7(2)3(1)1"), true);
  assert.equal(looksLikeMaprayes("[MYTHIC:LI] (1)1"), true);
  assert.equal(looksLikeMaprayes("hola mundo"), false);
});
