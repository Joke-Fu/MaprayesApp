export function canNativeShare(text: string, files?: File[]): boolean {
  if (typeof navigator === "undefined" || typeof navigator.share !== "function") {
    return false;
  }
  try {
    if (typeof navigator.canShare === "function") {
      return navigator.canShare(files?.length ? { text, files } : { text });
    }
  } catch {
    return false;
  }
  return true;
}

export async function shareText(text: string, title = "Maprayés"): Promise<"shared" | "copied" | "cancel" | "fail"> {
  if (!text) return "fail";
  if (canNativeShare(text)) {
    try {
      await navigator.share({ title, text });
      return "shared";
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return "cancel";
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    return "copied";
  } catch {
    return "fail";
  }
}

export async function shareFiles(
  files: File[],
  text: string,
  title = "Maprayés",
): Promise<"shared" | "copied" | "cancel" | "fail"> {
  if (canNativeShare(text, files)) {
    try {
      await navigator.share({ title, text, files });
      return "shared";
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return "cancel";
    }
  }
  return shareText(text, title);
}

export function whatsappHref(text: string): string {
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
}

export function telegramHref(text: string): string {
  return `https://t.me/share/url?url=${encodeURIComponent(text)}`;
}
