import {
  ACCENTED,
  ACCENTED_CODES,
  BASE_CODES,
  CHAR_TO_CODE,
  CODE_TO_CHAR,
  LETTERS,
  MAX_CODE_LEN,
} from "./alphabet.ts";
import {
  GUARDIANS,
  TRICZY_SHIFTS,
  isDualMode,
  isFullPrefix,
  type GuardianId,
} from "./guardians.ts";

export function hasEncodableGlyph(text: string): boolean {
  let i = 0;
  while (i < text.length) {
    if (text.slice(i, i + 3) === "..." && CHAR_TO_CODE["..."]) return true;
    const ch = text[i] ?? "";
    const code =
      CHAR_TO_CODE[ch] ??
      CHAR_TO_CODE[ch.toUpperCase()] ??
      CHAR_TO_CODE[ch.toLowerCase()];
    if (code && code !== "||") return true;
    i += 1;
  }
  return false;
}

export function encodeToMaprayes(text: string): {
  code: string;
  invalid: boolean;
} {
  const words = text.split(/\s+/).filter((w) => w.length > 0);
  let invalid = false;
  const encoded = words.map((word) => {
    let out = "";
    let i = 0;
    while (i < word.length) {
      if (word.slice(i, i + 3) === "..." && CHAR_TO_CODE["..."]) {
        out += CHAR_TO_CODE["..."];
        i += 3;
        continue;
      }
      const ch = word[i] ?? "";
      const code =
        CHAR_TO_CODE[ch] ??
        CHAR_TO_CODE[ch.toUpperCase()] ??
        CHAR_TO_CODE[ch.toLowerCase()];
      if (code && code !== "||") {
        out += code;
      } else if (ch) {
        out += "?";
        invalid = true;
      }
      i += 1;
    }
    return out;
  });
  return { code: encoded.join("||"), invalid };
}

export function decodeFromMaprayes(input: string): string {
  const parts = input.split(/\|\|/);
  const words: string[] = [];
  for (const part of parts) {
    let word = "";
    let i = 0;
    while (i < part.length) {
      const match = longestMatch(part, i);
      if (match) {
        word += CODE_TO_CHAR[match] ?? "?";
        i += match.length;
      } else {
        word += "?";
        i += 1;
      }
    }
    words.push(word);
  }
  return words.join(" ").trim();
}

function longestMatch(part: string, i: number): string | null {
  const max = Math.min(MAX_CODE_LEN, part.length - i);
  for (let len = max; len >= 1; len--) {
    const sub = part.slice(i, i + len);
    if (CODE_TO_CHAR[sub]) return sub;
  }
  return null;
}

function shiftAmount(
  id: GuardianId,
  isPlus: boolean,
  isReverse: boolean,
  letterIndex: number,
): { shift: number; nextIndex: number } {
  if (id === "triczy") {
    const arr = isReverse ? TRICZY_SHIFTS.map((n) => -n) : TRICZY_SHIFTS;
    return {
      shift: arr[letterIndex % arr.length] ?? 0,
      nextIndex: letterIndex + 1,
    };
  }
  const g = GUARDIANS[id];
  let shift = 0;
  if (isDualMode(id)) {
    shift = isPlus ? (g.plus ?? 0) : (g.minus ?? 0);
  } else {
    shift = g.shift ?? 0;
  }
  if (isReverse) shift = -shift;
  return { shift, nextIndex: letterIndex };
}

function applyLetterShift(letter: string, shift: number, fallbackCode: string): string {
  const upper = letter.toUpperCase();
  if ((ACCENTED as readonly string[]).includes(upper)) {
    const index = ACCENTED.indexOf(upper as (typeof ACCENTED)[number]);
    const effective = ((shift % 5) + 5) % 5;
    const next = ACCENTED[(index + effective) % 5];
    return ACCENTED_CODES[next ?? upper] ?? fallbackCode;
  }
  if (LETTERS.includes(upper)) {
    const index = LETTERS.indexOf(upper);
    const nextIndex =
      (index + shift + LETTERS.length * 100) % LETTERS.length;
    const next = LETTERS[nextIndex] ?? upper;
    return BASE_CODES[next] ?? fallbackCode;
  }
  return fallbackCode;
}

export function applyMythicShift(
  code: string,
  character: GuardianId,
  isPlus: boolean,
  isReverse: boolean,
): string {
  const parts = code.split(/\|\|/);
  const shifted = parts.map((part) => {
    let out = "";
    let letterIndex = 0;
    let i = 0;
    while (i < part.length) {
      const match = longestMatch(part, i);
      if (match) {
        const letter = (CODE_TO_CHAR[match] ?? "").toUpperCase();
        const { shift, nextIndex } = shiftAmount(
          character,
          isPlus,
          isReverse,
          letterIndex,
        );
        letterIndex = nextIndex;
        out += applyLetterShift(letter, shift, match);
        i += match.length;
      } else {
        out += part[i] ?? "";
        i += 1;
      }
    }
    return out;
  });
  return shifted.join("||");
}

export function applySequence(
  code: string,
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
  reverse = false,
): string {
  let current = code;
  const seq = reverse ? [...sequence].reverse() : sequence;
  for (const g of seq) {
    const isPlus = modes[g] !== false;
    current = applyMythicShift(current, g, isPlus, reverse);
  }
  return current;
}

export type MythicParse = {
  clean: string;
  sequence: GuardianId[];
  modes: Partial<Record<GuardianId, boolean>>;
  isFull: boolean;
};

const INITIALS: Record<string, GuardianId> = Object.fromEntries(
  Object.values(GUARDIANS).map((g) => [g.initials, g.id]),
) as Record<string, GuardianId>;

export function parseMythicPrefix(input: string): MythicParse {
  const match = input.match(/\[MYTHIC:([^\]]+)\]\s*(.*)/s);
  if (!match) {
    return { clean: input, sequence: [], modes: {}, isFull: false };
  }
  let prefix = match[1] ?? "";
  let isFull = false;
  if (prefix.startsWith("FULL,")) {
    isFull = true;
    prefix = prefix.slice(5);
  }
  const sequence: GuardianId[] = [];
  const modes: Partial<Record<GuardianId, boolean>> = {};
  for (const raw of prefix.split(",")) {
    const p = raw.trim();
    if (!p) continue;
    const signed = p.match(/^([A-Z]{2})([+-]\d+)$/);
    if (signed) {
      const id = INITIALS[signed[1] ?? ""];
      if (id) {
        sequence.push(id);
        modes[id] = (signed[2] ?? "").startsWith("+");
      }
    } else {
      const id = INITIALS[p];
      if (id) {
        sequence.push(id);
        modes[id] = true;
      }
    }
  }
  return { clean: match[2] ?? "", sequence, modes, isFull };
}

export function buildMythicPrefix(
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): string {
  if (sequence.length === 0) return "";
  const body = sequence
    .map((g) => {
      const initial = GUARDIANS[g].initials;
      if (g === "garbanza") return `${initial}${modes[g] !== false ? "+5" : "-5"}`;
      if (g === "oithar") return `${initial}${modes[g] !== false ? "+8" : "-8"}`;
      if (g === "willy") return `${initial}${modes[g] !== false ? "+4" : "-2"}`;
      return initial;
    })
    .join(",");
  const full = isFullPrefix(sequence, modes) ? "FULL," : "";
  return `[MYTHIC:${full}${body}] `;
}

export function buildQrPayload(
  cleanCode: string,
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): string {
  return `${buildMythicPrefix(sequence, modes)}${cleanCode}`;
}

export function encodeWithGuardians(
  text: string,
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): { code: string; invalid: boolean } {
  const { code, invalid } = encodeToMaprayes(text);
  if (!code) return { code: "", invalid };
  if (sequence.length === 0) return { code, invalid };
  return { code: applySequence(code, sequence, modes, false), invalid };
}

export function decodeWithGuardians(
  input: string,
  sequence: GuardianId[],
  modes: Partial<Record<GuardianId, boolean>>,
): { text: string; parsed: MythicParse } {
  const parsed = parseMythicPrefix(input);
  const seq = parsed.sequence.length > 0 ? parsed.sequence : sequence;
  const md = parsed.sequence.length > 0 ? parsed.modes : modes;
  const reversed = applySequence(parsed.clean, seq, md, true);
  return { text: decodeFromMaprayes(reversed), parsed };
}
