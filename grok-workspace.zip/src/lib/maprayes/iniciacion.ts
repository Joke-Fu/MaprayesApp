import { ALFABETO, LETTERS } from "./alphabet.ts";
import { encodeToMaprayes, encodeWithGuardians } from "./cipher.ts";
import {
  GUARDIAN_IDS,
  isChaosCombo,
  isDualMode,
  type GuardianId,
} from "./guardians.ts";
import {
  PHRASES,
  WORDS,
  type CorpusLevel,
} from "./iniciacion-data.ts";

export type PracticeLevel = "facil" | "medio" | "dificil" | "extremo" | "libre";
export type DrillKind = "letras" | "numeros" | "simbolos" | "palabras" | "frases";

export const DRILL_LEVELS: PracticeLevel[] = [
  "facil",
  "medio",
  "dificil",
  "extremo",
  "libre",
];

export const DRILL_KINDS: DrillKind[] = [
  "letras",
  "numeros",
  "simbolos",
  "palabras",
  "frases",
];

export const LEVEL_LABEL: Record<PracticeLevel, string> = {
  facil: "Fácil",
  medio: "Medio",
  dificil: "Difícil",
  extremo: "Extremo",
  libre: "Modo Libre",
};

export const KIND_LABEL: Record<DrillKind, string> = {
  letras: "Letras",
  numeros: "Números",
  simbolos: "Símbolos",
  palabras: "Palabras",
  frases: "Frases",
};

export const LEVEL_HINT: Record<PracticeLevel, string> = {
  facil: "El primer aliento del código.",
  medio: "El velo ya pide atención.",
  dificil: "Frases y signos que no perdonan.",
  extremo: "No se escribe: se convoca.",
  libre: "Elige el material. El ritmo es tuyo.",
};

const DIGITS = "0123456789";
const SYMBOLS = Object.values(ALFABETO)
  .filter((ch) => !/^[A-ZÁÉÍÓÚÑ0-9]$/.test(ch) && ch !== " " && ch !== "...")
  .join("");

const LENGTHS: Record<Exclude<PracticeLevel, "extremo">, Record<DrillKind, number>> = {
  facil: { letras: 1, numeros: 1, simbolos: 1, palabras: 1, frases: 1 },
  medio: { letras: 3, numeros: 2, simbolos: 2, palabras: 1, frases: 1 },
  dificil: { letras: 5, numeros: 4, simbolos: 3, palabras: 1, frases: 1 },
  libre: { letras: 4, numeros: 3, simbolos: 2, palabras: 1, frases: 1 },
};

export type DrillPrompt = {
  kind: DrillKind;
  plaintext: string;
  cipher: string;
};

export type ExtremoChallenge = {
  plaintext: string;
  target: string;
  sequence: GuardianId[];
  modes: Partial<Record<GuardianId, boolean>>;
};

export function normalizePractice(value: string): string {
  return value.trim().replace(/\s+/g, " ").toLocaleUpperCase("es-MX");
}

export function answersMatch(expected: string, given: string): boolean {
  return normalizePractice(expected) === normalizePractice(given);
}

function corpusLevel(level: PracticeLevel): CorpusLevel {
  if (level === "dificil") return "dificil";
  if (level === "medio") return "medio";
  return "facil";
}

function pickFrom<T>(items: readonly T[], used: Set<string>, key: (item: T) => string): T {
  const unused = items.filter((item) => !used.has(key(item)));
  const pool = unused.length > 0 ? unused : [...items];
  const item = pool[Math.floor(Math.random() * pool.length)];
  if (item === undefined) throw new Error("empty pool");
  used.add(key(item));
  return item;
}

function randomGlyphs(alphabet: string, count: number): string {
  let out = "";
  for (let i = 0; i < count; i += 1) {
    const ch = alphabet[Math.floor(Math.random() * alphabet.length)];
    if (ch) out += ch;
  }
  return out;
}

function wordPool(level: PracticeLevel): readonly string[] {
  if (level === "libre") return [...WORDS.facil, ...WORDS.medio, ...WORDS.dificil];
  return WORDS[corpusLevel(level)];
}

function phrasePool(level: PracticeLevel): readonly string[] {
  if (level === "libre") return [...PHRASES.facil, ...PHRASES.medio, ...PHRASES.dificil];
  return PHRASES[corpusLevel(level)];
}

export function makeDrillPrompt(
  level: Exclude<PracticeLevel, "extremo">,
  kind: DrillKind,
  used: Set<string>,
): DrillPrompt {
  const n = LENGTHS[level][kind];
  let plaintext = "";
  if (kind === "letras") plaintext = randomGlyphs(LETTERS, n);
  else if (kind === "numeros") plaintext = randomGlyphs(DIGITS, n);
  else if (kind === "simbolos") plaintext = randomGlyphs(SYMBOLS, n);
  else if (kind === "palabras") plaintext = pickFrom(wordPool(level), used, (w) => `w:${w}`);
  else plaintext = pickFrom(phrasePool(level), used, (p) => `p:${p}`);

  const { code } = encodeToMaprayes(plaintext);
  return { kind, plaintext, cipher: code };
}

function randomModes(id: GuardianId): boolean {
  if (!isDualMode(id)) return true;
  return Math.random() < 0.5;
}

function randomSequence(size: number): {
  sequence: GuardianId[];
  modes: Partial<Record<GuardianId, boolean>>;
} {
  const shuffled = [...GUARDIAN_IDS].sort(() => Math.random() - 0.5);
  const sequence = shuffled.slice(0, size);
  const modes: Partial<Record<GuardianId, boolean>> = {};
  for (const id of sequence) modes[id] = randomModes(id);
  return { sequence, modes };
}

export function makeExtremoChallenge(used: Set<string>): ExtremoChallenge {
  const pool = [...PHRASES.medio, ...PHRASES.dificil, ...WORDS.dificil];
  const plaintext = pickFrom(pool, used, (p) => `x:${p}`);
  const base = encodeToMaprayes(plaintext).code;

  for (let attempt = 0; attempt < 24; attempt += 1) {
    const roll = Math.random();
    const size = roll < 0.4 ? 1 : roll < 0.8 ? 2 : 3;
    const { sequence, modes } = randomSequence(size);
    if (isChaosCombo(sequence, modes)) continue;
    const { code } = encodeWithGuardians(plaintext, sequence, modes);
    if (!code || code === base) continue;
    return { plaintext, target: code, sequence, modes };
  }

  const sequence: GuardianId[] = ["lino"];
  const modes = { lino: true };
  const { code } = encodeWithGuardians(plaintext, sequence, modes);
  return { plaintext, target: code || base, sequence, modes };
}
