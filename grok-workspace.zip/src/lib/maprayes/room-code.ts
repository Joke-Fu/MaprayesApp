const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateRoomCode(): string {
  let body = "";
  for (let i = 0; i < 4; i += 1) {
    body += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  }
  return `MAP-${body}`;
}

/** Accepts `MAP-7X3K`, `map 7x3k`, or just `7X3K`. */
export function parseRoomCode(raw: string): string | null {
  const s = raw.trim().toUpperCase().replace(/[\s_]+/g, "");
  const withPrefix = s.startsWith("MAP-") || s.startsWith("MAP")
    ? s.replace(/^MAP-?/, "MAP-")
    : `MAP-${s}`;
  if (/^MAP-[A-Z0-9]{4}$/.test(withPrefix)) return withPrefix;
  return null;
}

export function inviteText(code: string): string {
  return `Entra a mi sala Maprayés: ${code}`;
}
