import type { GuardianId } from "./guardians.ts";

export type RoomView = "cipher" | "plain";

export type RoomMsg =
  | {
      t: "snapshot";
      plain: string;
      sequence: GuardianId[];
      modes: Partial<Record<GuardianId, boolean>>;
    }
  | {
      t: "text";
      plain: string;
    }
  | {
      t: "guardians";
      sequence: GuardianId[];
      modes: Partial<Record<GuardianId, boolean>>;
    };

export function isRoomMsg(data: unknown): data is RoomMsg {
  if (!data || typeof data !== "object") return false;
  const t = (data as { t?: unknown }).t;
  return t === "snapshot" || t === "text" || t === "guardians";
}
