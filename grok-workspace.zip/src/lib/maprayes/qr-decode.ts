export function looksLikeMaprayes(text: string): boolean {
  return /\[MYTHIC:/i.test(text) || /\(\d\)\d/.test(text) || text.includes("||");
}

type Detected = { rawValue?: string };

type DetectorCtor = new (opts?: { formats: string[] }) => {
  detect: (source: CanvasImageSource) => Promise<Detected[]>;
};

function getDetector(): DetectorCtor | null {
  if (typeof window === "undefined") return null;
  return (
    (window as unknown as { BarcodeDetector?: DetectorCtor }).BarcodeDetector ??
    null
  );
}

export async function decodeQrFromSource(
  source: CanvasImageSource,
): Promise<string | null> {
  const Detector = getDetector();
  if (Detector) {
    try {
      const detector = new Detector({ formats: ["qr_code"] });
      const codes = await detector.detect(source);
      const value = codes[0]?.rawValue?.trim();
      if (value) return value;
    } catch {
      // Native detector missing format support — fall through to jsQR.
    }
  }
  return decodeWithJsQr(source);
}

function sourceToImageData(source: CanvasImageSource): ImageData | null {
  const canvas = document.createElement("canvas");
  let width = 0;
  let height = 0;
  if (source instanceof HTMLVideoElement) {
    width = source.videoWidth;
    height = source.videoHeight;
  } else if (source instanceof HTMLImageElement) {
    width = source.naturalWidth || source.width;
    height = source.naturalHeight || source.height;
  } else if (source instanceof HTMLCanvasElement) {
    width = source.width;
    height = source.height;
  } else if (typeof ImageBitmap !== "undefined" && source instanceof ImageBitmap) {
    width = source.width;
    height = source.height;
  }
  if (width < 8 || height < 8) return null;
  const max = 1280;
  const scale = Math.min(1, max / Math.max(width, height));
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  return ctx.getImageData(0, 0, canvas.width, canvas.height);
}

export async function decodeWithJsQr(
  source: CanvasImageSource,
): Promise<string | null> {
  const image = sourceToImageData(source);
  if (!image) return null;
  const { default: jsQR } = await import("jsqr");
  const result = jsQR(image.data, image.width, image.height, {
    inversionAttempts: "attemptBoth",
  });
  return result?.data?.trim() || null;
}

export async function decodeQrFromFile(file: File): Promise<string | null> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    return decodeQrFromSource(img);
  } finally {
    URL.revokeObjectURL(url);
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("image"));
    img.src = src;
  });
}

export function cameraErrorMessage(err: unknown): string {
  const name =
    err && typeof err === "object" && "name" in err
      ? String((err as { name: string }).name)
      : "";
  if (name === "NotAllowedError") {
    return "Sin permiso de cámara. Puedes usar una foto del código.";
  }
  if (name === "NotFoundError") {
    return "No hay cámara en este dispositivo. Usa una foto.";
  }
  if (name === "SecurityError" || name === "NotSupportedError") {
    return "Este entorno no permite la cámara en vivo. Usa una foto del código.";
  }
  return "No se pudo abrir la cámara. Usa una foto del código.";
}
