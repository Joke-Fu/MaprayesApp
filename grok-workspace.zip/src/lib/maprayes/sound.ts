import type { GuardianId } from "./guardians";
import { useSettings } from "@/lib/store/settings";

export type SoundKind =
  | "translate"
  | "decode"
  | "copy"
  | "qr"
  | "scan"
  | "error"
  | "guardian-add"
  | "guardian-remove"
  | "guardian-mode"
  | "clear"
  | "chaos"
  | "primordial"
  | "toggle"
  | "share"
  | "join";

const GUARDIAN_HZ: Record<GuardianId, number> = {
  lino: 196,
  garbanza: 233,
  yudmiry: 261,
  escrimedes: 174,
  oithar: 311,
  epheron: 146,
  willy: 220,
  triczy: 185,
};

let ctx: AudioContext | null = null;

function Ctor(): typeof AudioContext | null {
  if (typeof window === "undefined") return null;
  return (
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext ||
    null
  );
}

function getCtx(): AudioContext | null {
  const Audio = Ctor();
  if (!Audio) return null;
  if (!ctx) ctx = new Audio();
  return ctx;
}

export function unlockSound() {
  const c = getCtx();
  if (c && c.state === "suspended") void c.resume();
}

function tone(
  c: AudioContext,
  freq: number,
  start: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  slideTo?: number,
) {
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, start);
  if (slideTo !== undefined) {
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), start + dur);
  }
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(gain, start + 0.014);
  g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  osc.connect(g);
  g.connect(c.destination);
  osc.start(start);
  osc.stop(start + dur + 0.03);
}

export function playSound(
  kind: SoundKind,
  extra?: { guardian?: GuardianId },
) {
  if (!useSettings.getState().soundEnabled) return;
  const c = getCtx();
  if (!c) return;
  if (c.state === "suspended") void c.resume();
  const t = c.currentTime;

  try {
    switch (kind) {
      case "translate":
        tone(c, 523, t, 0.09, "triangle", 0.07);
        tone(c, 659, t + 0.08, 0.12, "triangle", 0.08);
        break;
      case "decode":
        tone(c, 659, t, 0.09, "triangle", 0.07);
        tone(c, 494, t + 0.08, 0.14, "sine", 0.08);
        break;
      case "copy":
        tone(c, 880, t, 0.05, "sine", 0.05);
        break;
      case "qr":
        tone(c, 196, t, 0.05, "square", 0.04);
        tone(c, 784, t + 0.05, 0.1, "triangle", 0.07);
        break;
      case "scan":
        tone(c, 784, t, 0.08, "sine", 0.08);
        tone(c, 1046, t + 0.07, 0.16, "triangle", 0.09);
        break;
      case "error":
        tone(c, 110, t, 0.18, "square", 0.05);
        break;
      case "guardian-add": {
        const f = GUARDIAN_HZ[extra?.guardian ?? "lino"];
        tone(c, f, t, 0.14, "triangle", 0.08);
        tone(c, f * 2, t + 0.06, 0.18, "sine", 0.05);
        break;
      }
      case "guardian-remove": {
        const f = GUARDIAN_HZ[extra?.guardian ?? "lino"];
        tone(c, f, t, 0.16, "sine", 0.06, f * 0.6);
        break;
      }
      case "guardian-mode":
        tone(c, 440, t, 0.04, "triangle", 0.05);
        break;
      case "clear":
        tone(c, 330, t, 0.08, "sine", 0.05);
        tone(c, 196, t + 0.09, 0.14, "sine", 0.05);
        break;
      case "chaos":
        tone(c, 73, t, 0.32, "square", 0.05);
        tone(c, 110, t + 0.04, 0.22, "sawtooth", 0.035);
        tone(c, 311, t + 0.18, 0.12, "square", 0.04);
        break;
      case "primordial":
        tone(c, 261, t, 0.16, "sine", 0.07);
        tone(c, 329, t + 0.12, 0.16, "sine", 0.07);
        tone(c, 392, t + 0.24, 0.18, "sine", 0.07);
        tone(c, 523, t + 0.38, 0.28, "triangle", 0.08);
        break;
      case "toggle":
        tone(c, 523, t, 0.07, "sine", 0.06);
        tone(c, 784, t + 0.07, 0.12, "triangle", 0.07);
        break;
      case "share":
        tone(c, 392, t, 0.07, "triangle", 0.06);
        tone(c, 523, t + 0.08, 0.12, "sine", 0.07);
        break;
      case "join":
        tone(c, 330, t, 0.1, "sine", 0.07);
        tone(c, 494, t + 0.1, 0.16, "triangle", 0.08);
        break;
      default:
        break;
    }
  } catch {
    // Audio can fail in restricted contexts; never surface it.
  }
}
