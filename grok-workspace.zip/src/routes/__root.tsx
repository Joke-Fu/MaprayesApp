import {
  createRootRoute,
  HeadContent,
  Outlet,
  Scripts,
} from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { ThemeSync } from "@/components/maprayes/theme-sync";
import { SoundGate } from "@/components/maprayes/sound-gate";
import { ChaosLayer } from "@/components/maprayes/chaos-layer";
import { RoomMesh } from "@/components/maprayes/room-mesh";
import { Toaster } from "sonner";
import appCss from "../styles.css?url";

const APP_NAME = "Maprayés";

const themeBoot = `(function(){try{var r=localStorage.getItem("maprayes-settings");if(!r)return;var s=JSON.parse(r).state||{};var d=document.documentElement;if(s.theme)d.setAttribute("data-theme",s.theme);if(s.textSize)d.setAttribute("data-size",s.textSize);if(s.font)d.setAttribute("data-font",s.font);}catch(e){}})();`;

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "Traductor del lenguaje secreto Maprayés. Guardianes, códigos y un poco de caos.",
      },
      { name: "theme-color", content: "#5A614E" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;1,9..144,500&family=Source+Sans+3:ital,wght@0,400;0,500;0,600;1,400&family=VT323&display=swap",
      },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: RootDocument,
});

function RootDocument() {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <HeadContent />
        <script dangerouslySetInnerHTML={{ __html: themeBoot }} />
      </head>
      <body className="bg-bg text-fg antialiased">
        <PreviewHostBridge />
        <AuthProvider>
          <ThemeSync />
          <SoundGate />
          <RoomMesh />
          <Outlet />
          <ChaosLayer />
          <Toaster
            position="bottom-center"
            toastOptions={{ className: "map-toast" }}
            offset={28}
          />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}
