import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/maprayes/app-shell";
import { GuardianSigil } from "@/components/maprayes/sigils";
import { Button } from "@/components/ui/button";
import { maxValue, parsePairKey } from "@/lib/maprayes/affinity";
import { GUARDIAN_IDS, GUARDIANS, type GuardianId } from "@/lib/maprayes/guardians";
import { playSound } from "@/lib/maprayes/sound";
import { useAffinity } from "@/lib/store/affinity";
import { useHasMounted } from "@/hooks/use-has-mounted";

export const Route = createFileRoute("/afinidad")({ component: Afinidad });

const SIZE = 320;
const CX = 160;
const CY = 156;
const RING = 112;

type Node = { id: GuardianId; x: number; y: number; lx: number; ly: number };

function nodes(): Node[] {
  return GUARDIAN_IDS.map((id, i) => {
    const a = (i / GUARDIAN_IDS.length) * Math.PI * 2 - Math.PI / 2;
    const x = CX + Math.cos(a) * RING;
    const y = CY + Math.sin(a) * RING;
    const lx = CX + Math.cos(a) * (RING + 28);
    const ly = CY + Math.sin(a) * (RING + 28);
    return { id, x, y, lx, ly };
  });
}

function Afinidad() {
  const mounted = useHasMounted();
  const counts = useAffinity((s) => s.counts);
  const pairs = useAffinity((s) => s.pairs);
  const forget = useAffinity((s) => s.forget);
  const [armed, setArmed] = useState(false);
  const sky = useMemo(() => nodes(), []);

  const pairEntries = useMemo(() => {
    return Object.entries(pairs)
      .map(([key, n]) => {
        const parsed = parsePairKey(key);
        if (!parsed || n <= 0) return null;
        return { key, a: parsed[0], b: parsed[1], n };
      })
      .filter((v): v is { key: string; a: GuardianId; b: GuardianId; n: number } => v != null)
      .sort((x, y) => y.n - x.n);
  }, [pairs]);

  const maxPair = maxValue(pairEntries.map((p) => p.n));
  const maxCount = maxValue(GUARDIAN_IDS.map((id) => counts[id] ?? 0));
  const hasLazos = mounted && pairEntries.length > 0;
  const byId = Object.fromEntries(sky.map((n) => [n.id, n])) as Record<GuardianId, Node>;

  return (
    <AppShell title="Mapa de afinidad">
      <div className="space-y-6">
        <p className="text-sm text-muted">
          Cada vez que dos o más guardianes custodian un mismo mensaje, se teje
          un hilo. El cielo recuerda quiénes viajan juntos.
        </p>

        <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
          <svg
            viewBox={`0 0 ${SIZE} ${SIZE + 24}`}
            role="img"
            aria-label="Constelación de guardianes"
            className="mx-auto block w-full max-w-md"
          >
            <title>Constelación de afinidad</title>
            <circle
              cx={CX}
              cy={CY}
              r={RING}
              fill="none"
              stroke="currentColor"
              strokeOpacity="0.08"
            />
            {hasLazos
              ? pairEntries.map((edge) => {
                  const na = byId[edge.a];
                  const nb = byId[edge.b];
                  if (!na || !nb) return null;
                  const t = edge.n / maxPair;
                  return (
                    <line
                      key={edge.key}
                      x1={na.x}
                      y1={na.y}
                      x2={nb.x}
                      y2={nb.y}
                      stroke="var(--khaki)"
                      strokeWidth={1 + t * 4}
                      strokeOpacity={0.22 + t * 0.62}
                      strokeLinecap="round"
                    />
                  );
                })
              : null}
            {sky.map((node) => {
              const n = mounted ? (counts[node.id] ?? 0) : 0;
              const t = maxCount > 0 ? n / maxCount : 0;
              const r = 11 + t * 9;
              const accent = GUARDIANS[node.id].accent;
              return (
                <g key={node.id}>
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={r + 4}
                    fill={accent}
                    fillOpacity={0.12 + t * 0.18}
                  />
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={r}
                    fill="var(--surface)"
                    stroke={accent}
                    strokeWidth={1.5}
                  />
                  <foreignObject
                    x={node.x - 8}
                    y={node.y - 8}
                    width={16}
                    height={16}
                  >
                    <div className="flex size-4 items-center justify-center">
                      <GuardianSigil
                        id={node.id}
                        className="size-4 text-olive"
                      />
                    </div>
                  </foreignObject>
                  <text
                    x={node.lx}
                    y={node.ly}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill="var(--muted)"
                    fontSize="9"
                    fontFamily="var(--font-sans)"
                  >
                    {GUARDIANS[node.id].initials}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {hasLazos ? (
          <section className="space-y-2">
            <h2 className="font-display text-lg font-medium">Lazos más densos</h2>
            <ul className="space-y-2">
              {pairEntries.slice(0, 6).map((edge) => (
                <li
                  key={edge.key}
                  className="flex items-center justify-between gap-3 rounded-lg bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]"
                >
                  <span className="flex items-center gap-2">
                    <GuardianSigil id={edge.a} className="size-4 text-olive" />
                    <span>{GUARDIANS[edge.a].name}</span>
                    <span className="text-muted">·</span>
                    <GuardianSigil id={edge.b} className="size-4 text-olive" />
                    <span>{GUARDIANS[edge.b].name}</span>
                  </span>
                  <span className="tabular-nums text-xs text-muted">{edge.n}</span>
                </li>
              ))}
            </ul>
          </section>
        ) : (
          <p className="text-center font-display text-sm italic text-muted">
            Los guardianes aún no han tejido lazos. Elige dos o más en el
            traductor.
          </p>
        )}

        {hasLazos ? (
          <div className="pt-2 text-center">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                if (!armed) {
                  setArmed(true);
                  return;
                }
                forget();
                setArmed(false);
                playSound("clear");
              }}
            >
              {armed ? "Confirmar olvido" : "Olvidar lazos"}
            </Button>
          </div>
        ) : null}
      </div>
    </AppShell>
  );
}
