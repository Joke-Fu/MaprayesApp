import { createFileRoute, Link } from "@tanstack/react-router";
import { Camera, Eraser, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { AppShell } from "@/components/maprayes/app-shell";
import { CopyButton } from "@/components/maprayes/copy-button";
import { notify } from "@/components/maprayes/notify";
import { QrPanel } from "@/components/maprayes/qr-panel";
import { QrScanner } from "@/components/maprayes/qr-scanner";
import { ShareButton } from "@/components/maprayes/share-button";
import { GuardianSigil } from "@/components/maprayes/sigils";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  decodeWithGuardians,
  encodeWithGuardians,
  parseMythicPrefix,
} from "@/lib/maprayes/cipher";
import { looksLikeMaprayes } from "@/lib/maprayes/qr-decode";
import {
  GUARDIAN_IDS,
  GUARDIANS,
  isDualMode,
  isFullAlignment,
  mythicPower,
  type GuardianId,
} from "@/lib/maprayes/guardians";
import { playSound } from "@/lib/maprayes/sound";
import { shouldRecordAffinity } from "@/lib/maprayes/affinity";
import { useAffinity } from "@/lib/store/affinity";
import { useRoom } from "@/lib/store/room";
import { useSession } from "@/lib/store/session";
import { useSettings } from "@/lib/store/settings";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/traductor")({ component: Traductor });

function Traductor() {
  const [plain, setPlain] = useState("");
  const [cipherIn, setCipherIn] = useState("");
  const [scannerOpen, setScannerOpen] = useState(false);
  const sequence = useSession((s) => s.sequence);
  const modes = useSession((s) => s.modes);
  const pendingCipher = useSession((s) => s.pendingCipher);
  const setPendingCipher = useSession((s) => s.setPendingCipher);
  const roomCode = useRoom((s) => s.code);
  const roomPlain = useRoom((s) => s.plain);
  const roomOrigin = useRoom((s) => s.origin);
  const setLocalPlain = useRoom((s) => s.setLocalPlain);
  const roomView = useRoom((s) => s.view);
  const setRoomView = useRoom((s) => s.setView);
  const roomPeers = useRoom((s) => s.peers);
  const showCounters = useSettings((s) => s.showCounters);
  const invalidOnce = useRef(false);
  const skipDecodeSound = useRef(false);
  const firstEncode = useRef(true);
  const firstDecode = useRef(true);
  const lastAffinityKey = useRef("");

  const encoded = useMemo(() => {
    if (!plain.trim()) return { code: "", invalid: false };
    return encodeWithGuardians(plain, sequence, modes);
  }, [plain, sequence, modes]);

  const decoded = useMemo(() => {
    if (!cipherIn.trim()) return { text: "", parsed: null };
    return decodeWithGuardians(cipherIn, sequence, modes);
  }, [cipherIn, sequence, modes]);

  useEffect(() => {
    if (!pendingCipher) return;
    skipDecodeSound.current = true;
    setCipherIn(pendingCipher);
    setPendingCipher(null);
  }, [pendingCipher, setPendingCipher]);

  const skipRoomEcho = useRef(false);
  const roomSeeded = useRef(false);

  useEffect(() => {
    if (!roomCode) {
      roomSeeded.current = false;
      return;
    }
    if (roomSeeded.current) return;
    roomSeeded.current = true;
    if (roomPlain && !plain) {
      skipRoomEcho.current = true;
      firstEncode.current = true;
      setPlain(roomPlain);
    }
  }, [roomCode, roomPlain, plain]);

  useEffect(() => {
    if (!roomCode) return;
    if (roomOrigin !== "remote") return;
    if (roomPlain === plain) return;
    skipRoomEcho.current = true;
    firstEncode.current = true;
    setPlain(roomPlain);
  }, [roomCode, roomOrigin, roomPlain, plain]);

  useEffect(() => {
    if (!roomCode) return;
    if (skipRoomEcho.current) {
      skipRoomEcho.current = false;
      return;
    }
    const id = window.setTimeout(() => setLocalPlain(plain), 180);
    return () => window.clearTimeout(id);
  }, [plain, roomCode, setLocalPlain]);

  useEffect(() => {
    const parsed = parseMythicPrefix(cipherIn);
    if (parsed.sequence.length === 0) return;
    const current = useSession.getState();
    const same =
      current.sequence.join() === parsed.sequence.join() &&
      JSON.stringify(current.modes) === JSON.stringify(parsed.modes);
    if (same) return;
    current.adoptSequence(parsed.sequence, parsed.modes);
  }, [cipherIn]);

  useEffect(() => {
    if (encoded.invalid && !invalidOnce.current) {
      invalidOnce.current = true;
      notify("Algunos caracteres no tienen código.", "escrimedes");
    }
    if (!encoded.invalid) invalidOnce.current = false;
  }, [encoded.invalid]);

  useEffect(() => {
    if (firstEncode.current) {
      firstEncode.current = false;
      return;
    }
    if (!encoded.code) return;
    const id = window.setTimeout(() => playSound("translate"), 420);
    return () => window.clearTimeout(id);
  }, [encoded.code]);

  useEffect(() => {
    if (firstDecode.current) {
      firstDecode.current = false;
      return;
    }
    if (!decoded.text) return;
    if (skipDecodeSound.current) {
      skipDecodeSound.current = false;
      return;
    }
    const id = window.setTimeout(() => playSound("decode"), 420);
    return () => window.clearTimeout(id);
  }, [decoded.text]);

  useEffect(() => {
    if (!shouldRecordAffinity(sequence, plain)) return;
    if (!encoded.code) return;
    const key = sequence.join(",");
    if (key === lastAffinityKey.current) return;
    lastAffinityKey.current = key;
    useAffinity.getState().record(sequence);
  }, [plain, sequence, encoded.code]);

  const aligned = isFullAlignment(sequence, modes);
  const power = mythicPower(sequence, modes);

  function applyScan(text: string) {
    skipDecodeSound.current = true;
    setCipherIn(text);
    setScannerOpen(false);
    playSound("scan");
    notify(
      looksLikeMaprayes(text)
        ? "Código Maprayés leído."
        : "Código leído.",
      "yudmiry",
    );
  }

  return (
    <AppShell title="Traductor" wide>
      <div className="space-y-10">
        {roomCode ? (
          <RoomStrip
            code={roomCode}
            peers={roomPeers.filter((p) => p.connectionState === "connected").length}
            view={roomView}
            onView={setRoomView}
          />
        ) : null}
        <section className="space-y-3">
          <h2 className="font-display text-xl font-medium">Texto a Maprayés</h2>
          <Field
            id="inputText"
            value={plain}
            onChange={setPlain}
            placeholder="Escribe tu texto aquí…"
            showCount={showCounters}
            emphasize={!!roomCode && roomView === "plain"}
          />
          <Field
            id="maprayesOutput"
            value={encoded.code}
            readOnly
            placeholder="Resultado en Maprayés…"
            showCount={showCounters}
            emphasize={!!roomCode && roomView === "cipher"}
          />
          <div className="flex flex-wrap gap-2">
            <CopyButton value={encoded.code} label="Copiar código" />
            <ShareButton value={encoded.code} label="Compartir" />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setPlain("Hola, guardianes.")}
            >
              Probar un saludo
            </Button>
          </div>
          {aligned ? (
            <p className="font-display text-center text-sm italic text-olive">
              Mensaje en Maprayés Primordial
            </p>
          ) : null}
        </section>

        <GuardianRack />

        {sequence.length > 0 ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-muted">
              <span>Poder mítico</span>
              <span className="tabular-nums">{power}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-surface-2">
              <div
                className={cn(
                  "h-full rounded-full bg-olive transition-[width] duration-500",
                  sequence.includes("triczy") && "bg-[color:var(--g-triczy)]",
                )}
                style={{ width: `${power}%` }}
              />
            </div>
          </div>
        ) : null}

        <QrPanel cleanCode={encoded.code} />

        <section className="space-y-3">
          <div className="flex items-end justify-between gap-3">
            <h2 className="font-display text-xl font-medium">Maprayés a texto</h2>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setScannerOpen(true)}
            >
              <Camera />
              Leer código
            </Button>
          </div>
          <Field
            id="inputMaprayes"
            value={cipherIn}
            onChange={setCipherIn}
            placeholder="Pega un código Maprayés — con o sin prefijo MYTHIC…"
            showCount={showCounters}
          />
          <Field
            id="textoOutput"
            value={decoded.text}
            readOnly
            placeholder="Texto traducido…"
            showCount={showCounters}
          />
          <div className="flex flex-wrap gap-2">
            <CopyButton value={decoded.text} label="Copiar texto" />
            <ShareButton value={decoded.text} label="Compartir" />
          </div>
        </section>
      </div>
      {scannerOpen ? (
        <QrScanner onScan={applyScan} onClose={() => setScannerOpen(false)} />
      ) : null}
    </AppShell>
  );
}

function RoomStrip({
  code,
  peers,
  view,
  onView,
}: {
  code: string;
  peers: number;
  view: "cipher" | "plain";
  onView: (v: "cipher" | "plain") => void;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
      <Link to="/sala" className="font-mono text-sm tracking-wide text-olive">
        {code}
      </Link>
      <span className="text-xs text-muted">
        {peers === 0 ? "Esperando…" : `${peers + 1} en la sala`}
      </span>
      <div className="flex gap-1">
        <button
          type="button"
          onClick={() => onView("plain")}
          className={cn(
            "h-8 rounded-md px-2.5 text-xs font-medium",
            view === "plain"
              ? "bg-olive text-olive-fg"
              : "bg-surface-2 text-fg",
          )}
        >
          Texto
        </button>
        <button
          type="button"
          onClick={() => onView("cipher")}
          className={cn(
            "h-8 rounded-md px-2.5 text-xs font-medium",
            view === "cipher"
              ? "bg-olive text-olive-fg"
              : "bg-surface-2 text-fg",
          )}
        >
          Cifrado
        </button>
      </div>
    </div>
  );
}

function Field({
  id,
  value,
  onChange,
  placeholder,
  readOnly,
  showCount,
  emphasize,
}: {
  id: string;
  value: string;
  onChange?: (v: string) => void;
  placeholder: string;
  readOnly?: boolean;
  showCount: boolean;
  emphasize?: boolean;
}) {
  return (
    <div className="relative">
      <Textarea
        id={id}
        value={value}
        readOnly={readOnly}
        placeholder={placeholder}
        onChange={(e) => onChange?.(e.target.value)}
        className={cn(
          "pr-10",
          readOnly && "opacity-90",
          emphasize && "ring-2 ring-olive/45",
        )}
      />
      {value && onChange ? (
        <button
          type="button"
          className="absolute top-2 right-2 inline-flex size-9 items-center justify-center rounded-md text-muted hover:text-fg"
          aria-label="Limpiar"
          onClick={() => onChange("")}
        >
          <X className="size-4" />
        </button>
      ) : null}
      {showCount ? (
        <p className="mt-1 text-right text-xs tabular-nums text-muted">
          {value.length} caracteres
        </p>
      ) : null}
    </div>
  );
}

function GuardianRack() {
  const sequence = useSession((s) => s.sequence);
  const modes = useSession((s) => s.modes);
  const addGuardian = useSession((s) => s.addGuardian);
  const removeGuardian = useSession((s) => s.removeGuardian);
  const clearGuardians = useSession((s) => s.clearGuardians);
  const setMode = useSession((s) => s.setMode);

  function handleAdd(id: GuardianId) {
    const result = addGuardian(id);
    if (result === "already") {
      playSound("error");
      notify("Ese guardián ya custodia este mensaje.", id);
      return;
    }
    if (result === "limit") {
      playSound("error");
      notify(
        "El equilibrio se rompe. Maprayés rechaza más de seis… a menos que conozcas el orden antiguo.",
        "escrimedes",
        3600,
      );
      return;
    }
    if (result === "chaos") {
      playSound("chaos");
      notify(
        "Triczy ha tomado el control. Los otros huyen aterrorizados.",
        "chaos",
        4200,
      );
      return;
    }
    if (result === "primordial") {
      playSound("primordial");
      notify(
        "Los ocho se han alineado. El velo se adelgaza… Maprayés recuerda su origen.",
        "full",
        7000,
      );
      return;
    }
    playSound("guardian-add", { guardian: id });
    notify(GUARDIANS[id].addPhrase, id);
  }

  function handleRemove(index: number) {
    const id = removeGuardian(index);
    if (id) {
      playSound("guardian-remove", { guardian: id });
      notify(GUARDIANS[id].removePhrase, id);
    }
  }

  function handleMode(id: GuardianId, plus: boolean) {
    const result = setMode(id, plus);
    playSound(result === "primordial" ? "primordial" : "guardian-mode", {
      guardian: id,
    });
    if (result === "primordial") {
      notify(
        "Los ocho se han alineado. El velo se adelgaza… Maprayés recuerda su origen.",
        "full",
        7000,
      );
    }
  }

  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-medium">Guardianes</h2>
          <p className="text-sm text-muted">
            Cada uno desplaza el alfabeto. Máximo seis, salvo el rito antiguo.
          </p>
        </div>
        {sequence.length > 0 ? (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              clearGuardians();
              playSound("clear");
              notify("Guardianes liberados. Sin rastros.", "escrimedes");
            }}
          >
            <Eraser />
            Limpiar
          </Button>
        ) : null}
      </div>

      {sequence.length > 0 ? (
        <ul className="space-y-2">
          {sequence.map((id, i) => {
            const g = GUARDIANS[id];
            const plus = modes[id] !== false;
            return (
              <li
                key={`${id}-${i}`}
                className="flex min-h-12 items-center gap-3 rounded-lg bg-surface px-3 py-2 shadow-[var(--shadow-border)]"
                style={{ borderLeft: `3px solid ${g.accent}` }}
              >
                <GuardianSigil id={id} className="size-5 text-olive" />
                <span className="flex-1 font-medium">{g.name}</span>
                {isDualMode(id) ? (
                  <label className="flex items-center gap-2 text-xs text-muted">
                    <Switch
                      checked={plus}
                      onCheckedChange={(v) => handleMode(id, v)}
                      aria-label={g.name}
                    />
                    {plus ? g.plusLabel : g.minusLabel}
                  </label>
                ) : (
                  <span className="text-xs tabular-nums text-muted">
                    {g.displacement}
                  </span>
                )}
                <button
                  type="button"
                  className="inline-flex size-10 items-center justify-center rounded-md text-muted hover:text-fg"
                  aria-label={`Quitar ${g.name}`}
                  onClick={() => handleRemove(i)}
                >
                  <X className="size-4" />
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {GUARDIAN_IDS.map((id) => {
          const g = GUARDIANS[id];
          const taken = sequence.includes(id);
          return (
            <button
              key={id}
              type="button"
              disabled={taken}
              onClick={() => handleAdd(id)}
              className="flex min-h-14 flex-col items-start gap-1 rounded-lg bg-surface px-3 py-2.5 text-left shadow-[var(--shadow-border)] transition-transform duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--fg)_16%,transparent)] active:scale-[0.98] disabled:opacity-40"
            >
              <span className="flex items-center gap-2 text-olive">
                <GuardianSigil id={id} className="size-4" />
                <span className="text-sm font-medium text-fg">{g.name}</span>
              </span>
              <span className="text-[0.7rem] text-muted">{g.displacement}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
