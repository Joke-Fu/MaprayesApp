import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/maprayes/app-shell";
import { GuardianSigil } from "@/components/maprayes/sigils";
import { GUARDIAN_IDS, GUARDIANS } from "@/lib/maprayes/guardians";

export const Route = createFileRoute("/ayuda")({ component: Ayuda });

function Ayuda() {
  return (
    <AppShell title="Ayuda y lore">
      <div className="space-y-8 text-sm leading-relaxed">
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Qué es Maprayés</h2>
          <p>
            Maprayés nació como un lenguaje secreto: un código que une lo
            cotidiano con lo mítico. Cada glifo <span className="font-mono">(X)Y</span>{" "}
            es una puerta pequeña hacia un universo donde gatos, portales y caos
            conviven.
          </p>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Cómo traducir</h2>
          <p>
            Escribe en el traductor y el texto se convierte en códigos. Los
            espacios separan palabras con <span className="font-mono">||</span>.
            Para volver atrás, pega el código — si el mensaje lleva prefijo{" "}
            <span className="font-mono">[MYTHIC:…]</span>, los guardianes se
            restauran solos.
          </p>
          <p>
            El código visual (imagen) incluye a los guardianes activos. Compártelo
            para que la otra persona reciba no solo las letras, sino también
            quién las custodia.
          </p>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Cámara</h2>
          <p>
            Desde el menú o el traductor puedes abrir la cámara y apuntar a un
            código. Si el entorno no deja usar la cámara en vivo, elige una
            foto: el mensaje se pega en Maprayés a texto, con sus guardianes
            si el código lleva prefijo MYTHIC.
          </p>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Sala</h2>
          <p>
            Crea un umbral y comparte el código <span className="font-mono">MAP-····</span>.
            Quien lo escriba ve los mismos guardianes y, en el traductor, el
            texto que escribes — en claro o cifrado, según elija. La conexión
            es directa entre dispositivos.
          </p>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Afinidad</h2>
          <p>
            El mapa recuerda qué guardianes viajan juntos cuando un mensaje se
            cifra de verdad — no basta con invocarlos. Cada secuencia de dos o
            más que toque al menos una letra, número o símbolo teje un hilo.
          </p>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Iniciación</h2>
          <p>
            Cinco caminos para probar el lenguaje. Fácil, Medio, Difícil y Libre
            usan el alfabeto base: se muestra un cifrado y escribes la lectura.
            Puedes revelar si el velo no cede. Extremo es otro rito: la frase
            está clara, el cifrado ya tiene cortejo, y tú convocas guardianes
            hasta que las dos escrituras coincidan.
          </p>
          <p>
            Los aciertos despiertan Reliquias — sellos y sigilos que permanecen.
          </p>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Compartir</h2>
          <p>
            El botón Compartir abre la hoja del sistema: WhatsApp, Messenger,
            Bluetooth u otras apps del teléfono. Si el navegador no la ofrece,
            copia el mensaje o envíalo por WhatsApp web.
          </p>
        </section>
        <section className="space-y-3">
          <h2 className="font-display text-xl font-medium">Los ocho</h2>
          <ul className="space-y-2">
            {GUARDIAN_IDS.map((id) => {
              const g = GUARDIANS[id];
              return (
                <li key={id} className="flex items-start gap-3">
                  <GuardianSigil id={id} className="mt-0.5 size-5 text-olive" />
                  <span>
                    <strong className="font-medium">{g.name}.</strong> {g.help}
                  </span>
                </li>
              );
            })}
          </ul>
        </section>
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Lo que no se dice</h2>
          <p>
            Seis es el límite. Ocho es la excepción. Tres voluntades juntas —la
            travesura, el humor picante y la llama— pueden desordenar el velo,
            y el velo se rompe más rápido de lo que parece. Hay fuentes que no
            aparecen en Ajustes hasta que el lenguaje las recuerda. En Ajustes
            también puedes dejar que el color de la interfaz siga al último
            guardián, o devolverle el oliva.
          </p>
        </section>
      </div>
    </AppShell>
  );
}
