import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/iniciacion")({ component: IniciacionLayout });

function IniciacionLayout() {
  return <Outlet />;
}
