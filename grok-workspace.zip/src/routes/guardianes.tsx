import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/maprayes/app-shell";
import { GuardianSigil } from "@/components/maprayes/sigils";
import {
  GUARDIAN_IDS,
  GUARDIANS,
  PRIMORDIAL_LORE,
} from "@/lib/maprayes/guardians";

export const Route = createFileRoute("/guardianes")({ component: Guardianes });

function Guardianes() {
  return (
    <AppShell title="Guardianes" wide>
      <p className="mb-6 text-sm text-muted">
        Ocho voluntades custodian el lenguaje. Cada una desplaza el alfabeto a
        su manera.
      </p>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {GUARDIAN_IDS.map((id) => {
          const g = GUARDIANS[id];
          return (
            <article
              key={id}
              className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]"
              style={{ borderTop: `3px solid ${g.accent}` }}
            >
              <div className="mb-3 flex items-center gap-3 text-olive">
                <GuardianSigil id={id} className="size-7" />
                <h2 className="font-display text-xl font-medium text-fg">
                  {g.name}
                </h2>
              </div>
              <p className="font-display text-sm italic text-muted">{g.epithet}</p>
              <p className="mt-3 text-sm leading-relaxed">{g.lore}</p>
              <p className="mt-4 text-xs font-medium tracking-wide text-muted uppercase">
                Desplazamiento · {g.displacement}
              </p>
            </article>
          );
        })}
        <article className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:col-span-2">
          <h2 className="font-display text-xl font-medium">
            Maprayés Primordial
          </h2>
          <p className="mt-1 font-display text-sm italic text-muted">
            El lenguaje en su forma más antigua y pura.
          </p>
          <p className="mt-3 text-sm leading-relaxed">{PRIMORDIAL_LORE}</p>
        </article>
      </div>
    </AppShell>
  );
}
