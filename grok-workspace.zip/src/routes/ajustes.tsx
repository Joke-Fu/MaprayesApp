import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/maprayes/app-shell";
import { Switch } from "@/components/ui/switch";
import { useHasMounted } from "@/hooks/use-has-mounted";
import { playSound } from "@/lib/maprayes/sound";
import {
  useSettings,
  type FontName,
  type TextSize,
  type ThemeName,
} from "@/lib/store/settings";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/ajustes")({ component: Ajustes });

function Ajustes() {
  const mounted = useHasMounted();
  const theme = useSettings((s) => s.theme);
  const setTheme = useSettings((s) => s.setTheme);
  const textSize = useSettings((s) => s.textSize);
  const setTextSize = useSettings((s) => s.setTextSize);
  const font = useSettings((s) => s.font);
  const setFont = useSettings((s) => s.setFont);
  const showCounters = useSettings((s) => s.showCounters);
  const setShowCounters = useSettings((s) => s.setShowCounters);
  const soundEnabled = useSettings((s) => s.soundEnabled);
  const setSoundEnabled = useSettings((s) => s.setSoundEnabled);
  const primordialUnlocked = useSettings((s) => s.primordialUnlocked);
  const chaosFontUnlocked = useSettings((s) => s.chaosFontUnlocked);

  return (
    <AppShell title="Ajustes">
      <div className="space-y-10">
        <ChoiceGroup
          label="Tema"
          options={[
            { id: "light", label: "Claro" },
            { id: "dark", label: "Oscuro" },
            { id: "night", label: "Noche de Guardianes" },
          ]}
          value={theme}
          onChange={(v) => setTheme(v as ThemeName)}
        />
        <ChoiceGroup
          label="Tamaño de texto"
          options={[
            { id: "small", label: "Pequeño" },
            { id: "normal", label: "Normal" },
            { id: "large", label: "Grande" },
          ]}
          value={textSize}
          onChange={(v) => setTextSize(v as TextSize)}
        />
        <div className="space-y-3">
          <p className="text-sm font-medium">Fuente</p>
          <div className="flex flex-wrap gap-2">
            <ChoiceChip
              active={font === "normal"}
              onClick={() => setFont("normal")}
            >
              Estándar
            </ChoiceChip>
            {mounted && primordialUnlocked ? (
              <ChoiceChip
                active={font === "maprayes"}
                onClick={() => setFont("maprayes")}
              >
                Maprayés
              </ChoiceChip>
            ) : null}
            {mounted && chaosFontUnlocked ? (
              <ChoiceChip
                active={font === "caos"}
                onClick={() => setFont("caos")}
              >
                Caos
              </ChoiceChip>
            ) : null}
          </div>
          {mounted && !primordialUnlocked && !chaosFontUnlocked ? (
            <p className="text-xs text-muted italic">
              Hay fuentes que se revelan cuando el lenguaje lo permite.
            </p>
          ) : null}
        </div>
        <div className="flex items-center justify-between gap-4 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
          <label htmlFor="counters" className="text-sm font-medium">
            Mostrar contadores de caracteres
          </label>
          <Switch
            id="counters"
            checked={showCounters}
            onCheckedChange={setShowCounters}
          />
        </div>
        <div className="flex items-center justify-between gap-4 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
          <div>
            <label htmlFor="sounds" className="text-sm font-medium">
              Sonidos
            </label>
            <p className="text-xs text-muted">
              Traducir, guardianes, cámara y códigos.
            </p>
          </div>
          <Switch
            id="sounds"
            checked={soundEnabled}
            onCheckedChange={(v) => {
              setSoundEnabled(v);
              if (v) playSound("toggle");
            }}
          />
        </div>
        <GuardianThemeToggle />
        <div className="pt-6 text-center text-xs text-muted italic">
          <p>Maprayés © Joke-Fu 2026</p>
          <p className="mt-1">
            <a
              href="https://github.com/Joke-Fu/maprayes"
              target="_blank"
              rel="noreferrer"
              className="underline decoration-border underline-offset-4 hover:text-olive"
            >
              Ver en GitHub
            </a>
          </p>
        </div>
      </div>
    </AppShell>
  );
}

function GuardianThemeToggle() {
  const guardianTheme = useSettings((s) => s.guardianTheme);
  const setGuardianTheme = useSettings((s) => s.setGuardianTheme);
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
      <div>
        <label htmlFor="guardian-theme" className="text-sm font-medium">
          Colores de guardianes
        </label>
        <p className="text-xs text-muted">
          El acento de la interfaz sigue al último guardián de la secuencia.
        </p>
      </div>
      <Switch
        id="guardian-theme"
        checked={guardianTheme}
        onCheckedChange={(v) => {
          setGuardianTheme(v);
          playSound("toggle");
        }}
      />
    </div>
  );
}

function ChoiceGroup({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="space-y-3">
      <p className="text-sm font-medium">{label}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => (
          <ChoiceChip
            key={opt.id}
            active={value === opt.id}
            onClick={() => onChange(opt.id)}
          >
            {opt.label}
          </ChoiceChip>
        ))}
      </div>
    </div>
  );
}

function ChoiceChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-11 rounded-md px-4 text-sm font-medium transition-colors duration-150",
        active
          ? "bg-olive text-olive-fg"
          : "bg-surface text-fg shadow-[var(--shadow-border)]",
      )}
    >
      {children}
    </button>
  );
}
