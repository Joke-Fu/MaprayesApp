import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  ArrowRight,
  BookOpen,
  Camera,
  Orbit,
  Radio,
  Settings2,
  Shield,
  Sparkles,
  Table2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { HomeSeal } from "@/components/maprayes/home-seal";
import { WHISPERS } from "@/lib/maprayes/guardians";

export const Route = createFileRoute("/")({ component: Home });

const NAV = [
  { to: "/traductor", label: "Traductor", hint: "Texto ↔ código", icon: ArrowLeftRight },
  { to: "/iniciacion", label: "Iniciación", hint: "Práctica y reliquias", icon: Sparkles },
  { to: "/camara", label: "Cámara", hint: "Leer un código", icon: Camera },
  { to: "/sala", label: "Sala", hint: "Conectar viajeros", icon: Radio },
  { to: "/tabla", label: "Tabla de códigos", hint: "Alfabeto y favoritos", icon: Table2 },
  { to: "/guardianes", label: "Guardianes", hint: "Ocho voluntades", icon: Shield },
  { to: "/afinidad", label: "Afinidad", hint: "Quiénes viajan juntos", icon: Orbit },
  { to: "/ayuda", label: "Ayuda", hint: "Uso y lore", icon: BookOpen },
  { to: "/ajustes", label: "Ajustes", hint: "Tema, tipo, sonido", icon: Settings2 },
] as const;

function Home() {
  const [whisper, setWhisper] = useState(WHISPERS[0] ?? "");
  useEffect(() => {
    setWhisper(WHISPERS[Math.floor(Math.random() * WHISPERS.length)] ?? "");
  }, []);

  return (
    <div className="flex min-h-dvh flex-col">
      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col items-center justify-center px-5 py-10">
        <HomeSeal className="mb-6 size-24 text-olive" />
        <p className="font-display text-[0.7rem] tracking-[0.38em] text-muted uppercase">
          Joke-Fu · 2026
        </p>
        <h1 className="mt-2 font-display text-5xl font-medium tracking-tight italic">
          Maprayés
        </h1>
        <p className="mt-3 min-h-6 text-center text-sm text-muted italic">
          {whisper}
        </p>
        <nav className="mt-10 flex w-full flex-col gap-2" aria-label="Secciones">
          {NAV.map((item, i) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className="group flex min-h-14 items-center justify-between rounded-xl bg-surface px-5 py-3.5 shadow-[var(--shadow-border)] transition-[transform,box-shadow] duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--fg)_16%,transparent)] active:scale-[0.98]"
                style={{ animationDelay: `${i * 40}ms` }}
              >
                <span className="flex items-center gap-3">
                  <Icon className="size-5 text-olive" />
                  <span>
                    <span className="block font-medium">{item.label}</span>
                    <span className="block text-xs text-muted">{item.hint}</span>
                  </span>
                </span>
                <ArrowRight className="size-4 text-muted transition-transform duration-150 group-hover:translate-x-0.5" />
              </Link>
            );
          })}
        </nav>
      </main>
      <footer className="px-5 pb-8 text-center text-xs text-muted italic">
        <p>Maprayés © Joke-Fu 2026</p>
        <p className="mt-1">
          <a
            href="https://github.com/Joke-Fu/maprayes"
            target="_blank"
            rel="noreferrer"
            className="underline decoration-border underline-offset-4 hover:text-olive"
          >
            Ver en GitHub
          </a>
        </p>
      </footer>
    </div>
  );
}
