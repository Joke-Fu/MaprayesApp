import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/maprayes/app-shell";
import { notify } from "@/components/maprayes/notify";
import { QrScanner } from "@/components/maprayes/qr-scanner";
import { looksLikeMaprayes } from "@/lib/maprayes/qr-decode";
import { playSound } from "@/lib/maprayes/sound";
import { useSession } from "@/lib/store/session";

export const Route = createFileRoute("/camara")({ component: Camara });

function Camara() {
  const navigate = useNavigate();
  const setPendingCipher = useSession((s) => s.setPendingCipher);

  return (
    <AppShell title="Cámara">
      <div className="space-y-4">
        <p className="text-sm leading-relaxed text-muted">
          Apunta al código para traducirlo. El mensaje —y los guardianes, si
          van en el prefijo— se abrirán en el traductor.
        </p>
        <QrScanner
          variant="page"
          onScan={(text) => {
            playSound("scan");
            notify(
              looksLikeMaprayes(text)
                ? "Código Maprayés leído."
                : "Código leído.",
              "yudmiry",
            );
            setPendingCipher(text);
            void navigate({ to: "/traductor" });
          }}
        />
      </div>
    </AppShell>
  );
}
