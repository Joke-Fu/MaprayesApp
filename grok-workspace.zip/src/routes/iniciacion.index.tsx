import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Eye, Gem, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { AppShell } from "@/components/maprayes/app-shell";
import { notify } from "@/components/maprayes/notify";
import { GuardianSigil } from "@/components/maprayes/sigils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { encodeWithGuardians } from "@/lib/maprayes/cipher";
import {
  canAddGuardian,
  GUARDIAN_IDS,
  GUARDIANS,
  isDualMode,
  type GuardianId,
} from "@/lib/maprayes/guardians";
import {
  answersMatch,
  DRILL_KINDS,
  KIND_LABEL,
  LEVEL_HINT,
  LEVEL_LABEL,
  makeDrillPrompt,
  makeExtremoChallenge,
  type DrillKind,
  type DrillPrompt,
  type ExtremoChallenge,
  type PracticeLevel,
} from "@/lib/maprayes/iniciacion";
import { RELICS, relicUnlocked, unlockedCount } from "@/lib/maprayes/reliquias";
import { playSound } from "@/lib/maprayes/sound";
import { useIniciacion } from "@/lib/store/iniciacion";
import { useHasMounted } from "@/hooks/use-has-mounted";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/iniciacion/")({ component: Iniciacion });

function Iniciacion() {
  const [view, setView] = useState<PracticeLevel | "hub">("hub");

  return (
    <AppShell title={view === "hub" ? "Iniciación" : LEVEL_LABEL[view]}>
      {view === "hub" ? (
        <Hub onOpen={setView} />
      ) : view === "extremo" ? (
        <ExtremoBoard onBack={() => setView("hub")} />
      ) : (
        <DrillBoard level={view} onBack={() => setView("hub")} />
      )}
    </AppShell>
  );
}

function Hub({ onOpen }: { onOpen: (level: PracticeLevel) => void }) {
  const mounted = useHasMounted();
  const hits = useIniciacion((s) => s.hits);
  const guardianHits = useIniciacion((s) => s.guardianHits);
  const relics = mounted ? unlockedCount({ hits, guardianHits }) : 0;

  return (
    <div className="space-y-8">
      <section className="space-y-2">
        <p className="text-sm leading-relaxed text-muted">
          Aquí el lenguaje se prueba en voz baja. Descifrado primero; en Extremo,
          los guardianes son la respuesta.
        </p>
        <Link
          to="/iniciacion/reliquias"
          className="flex min-h-14 items-center justify-between rounded-xl bg-surface px-5 py-3.5 shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.98]"
        >
          <span className="flex items-center gap-3">
            <Gem className="size-5 text-olive" />
            <span>
              <span className="block font-medium">Reliquias</span>
              <span className="block text-xs text-muted">
                {mounted ? `${relics} de ${RELICS.length} despiertas` : "Vitrina de logros"}
              </span>
            </span>
          </span>
          <ArrowRight className="size-4 text-muted" />
        </Link>
      </section>

      <nav className="flex flex-col gap-2" aria-label="Niveles">
        {(["facil", "medio", "dificil", "extremo", "libre"] as const).map((level) => (
          <button
            key={level}
            type="button"
            onClick={() => {
              playSound("toggle");
              onOpen(level);
            }}
            className="flex min-h-14 items-center justify-between rounded-xl bg-surface px-5 py-3.5 text-left shadow-[var(--shadow-border)] transition-transform duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--fg)_16%,transparent)] active:scale-[0.98]"
          >
            <span>
              <span className="block font-medium">{LEVEL_LABEL[level]}</span>
              <span className="block text-xs text-muted">{LEVEL_HINT[level]}</span>
            </span>
            <span className="text-xs tabular-nums text-olive">
              {mounted ? `${hits[level]} aciertos` : ""}
            </span>
          </button>
        ))}
      </nav>
    </div>
  );
}

function announceRelics(beforeIds: Set<string>) {
  const stats = useIniciacion.getState();
  const fresh = RELICS.filter((r) => relicUnlocked(r, stats) && !beforeIds.has(r.id));
  if (fresh[0]) {
    playSound("primordial");
    notify(`Reliquia: ${fresh[0].title}`, "full", 3600);
  }
}

function snapshotRelics(): Set<string> {
  const stats = useIniciacion.getState();
  return new Set(RELICS.filter((r) => relicUnlocked(r, stats)).map((r) => r.id));
}

function DrillBoard({
  level,
  onBack,
}: {
  level: Exclude<PracticeLevel, "extremo">;
  onBack: () => void;
}) {
  const hits = useIniciacion((s) => s.hits);
  const registerHit = useIniciacion((s) => s.registerHit);
  const [kind, setKind] = useState<DrillKind>(level === "libre" ? "palabras" : "letras");
  const used = useRef(new Set<string>());
  const [prompt, setPrompt] = useState<DrillPrompt>(() =>
    makeDrillPrompt(level, level === "libre" ? "palabras" : "letras", used.current),
  );
  const [answer, setAnswer] = useState("");
  const [status, setStatus] = useState<"idle" | "ok" | "bad" | "revealed">("idle");

  function nextPrompt(nextKind = kind) {
    setPrompt(makeDrillPrompt(level, nextKind, used.current));
    setAnswer("");
    setStatus("idle");
    playSound("translate");
  }

  function check() {
    if (!answer.trim()) {
      playSound("error");
      notify("Escribe tu lectura.", "escrimedes");
      return;
    }
    if (answersMatch(prompt.plaintext, answer)) {
      setStatus("ok");
      playSound("decode");
      const before = snapshotRelics();
      registerHit(level);
      announceRelics(before);
      notify("El velo se abre.", "yudmiry");
    } else {
      setStatus("bad");
      playSound("error");
      notify("Aún no. Mira otra vez el signo.", "escrimedes");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="text-sm text-muted hover:text-fg"
        >
          Niveles
        </button>
        <p className="text-xs tabular-nums text-muted">{hits[level]} aciertos</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {DRILL_KINDS.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => {
              setKind(item);
              nextPrompt(item);
            }}
            className={cn(
              "h-11 rounded-md px-3 text-sm font-medium",
              kind === item
                ? "bg-olive text-olive-fg"
                : "bg-surface text-fg shadow-[var(--shadow-border)]",
            )}
          >
            {KIND_LABEL[item]}
          </button>
        ))}
      </div>

      <div className="space-y-3 rounded-xl bg-surface px-4 py-5 shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-[0.2em] text-muted uppercase">Lee esto</p>
        <p className="font-mono text-sm leading-relaxed break-all text-olive">
          {prompt.cipher}
        </p>
      </div>

      <Input
        value={answer}
        onChange={(e) => {
          setAnswer(e.target.value);
          if (status === "bad") setStatus("idle");
        }}
        placeholder="Tu lectura…"
        aria-label="Respuesta"
        onKeyDown={(e) => {
          if (e.key === "Enter" && status !== "ok" && status !== "revealed") check();
        }}
        disabled={status === "ok" || status === "revealed"}
      />

      {status === "ok" ? (
        <p className="font-display text-center text-sm italic text-olive">Correcto.</p>
      ) : null}
      {status === "bad" ? (
        <p className="text-center text-sm text-[color:var(--danger)]">Aún no coincide.</p>
      ) : null}
      {status === "revealed" ? (
        <p className="text-center font-medium">{prompt.plaintext}</p>
      ) : null}

      <div className="flex flex-wrap gap-2">
        {status === "ok" || status === "revealed" ? (
          <Button type="button" onClick={() => nextPrompt()}>
            Siguiente
          </Button>
        ) : (
          <Button type="button" onClick={check}>
            Comprobar
          </Button>
        )}
        {status !== "ok" && status !== "revealed" ? (
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setStatus("revealed");
              setAnswer(prompt.plaintext);
              playSound("toggle");
            }}
          >
            <Eye />
            Revelar
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function ExtremoBoard({ onBack }: { onBack: () => void }) {
  const hits = useIniciacion((s) => s.hits);
  const registerExtremo = useIniciacion((s) => s.registerExtremo);
  const used = useRef(new Set<string>());
  const [challenge, setChallenge] = useState<ExtremoChallenge>(() =>
    makeExtremoChallenge(used.current),
  );
  const [sequence, setSequence] = useState<GuardianId[]>([]);
  const [modes, setModes] = useState<Partial<Record<GuardianId, boolean>>>({});
  const [resolved, setResolved] = useState<"idle" | "ok" | "revealed">("idle");
  const counted = useRef(false);

  const current = useMemo(
    () => encodeWithGuardians(challenge.plaintext, sequence, modes).code,
    [challenge.plaintext, sequence, modes],
  );
  const matches = current === challenge.target && sequence.length > 0;

  useEffect(() => {
    if (resolved !== "idle") return;
    if (!matches) return;
    setResolved("ok");
    if (counted.current) return;
    counted.current = true;
    playSound("decode");
    const before = snapshotRelics();
    registerExtremo(sequence);
    announceRelics(before);
    notify("La combinación es la correcta.", "full", 3200);
  }, [matches, resolved, registerExtremo, sequence]);

  function next() {
    counted.current = false;
    setChallenge(makeExtremoChallenge(used.current));
    setSequence([]);
    setModes({});
    setResolved("idle");
    playSound("translate");
  }

  function add(id: GuardianId) {
    const check = canAddGuardian(sequence, modes, id);
    if (!check.ok) {
      playSound("error");
      notify(
        check.reason === "already"
          ? "Ese guardián ya está en el cortejo."
          : "El equilibrio se rompe. No más de seis.",
        id,
      );
      return;
    }
    setSequence((s) => [...s, id]);
    setModes((m) => ({ ...m, [id]: true }));
    playSound("guardian-add", { guardian: id });
  }

  function remove(index: number) {
    const id = sequence[index];
    if (!id) return;
    setSequence((s) => s.filter((_, i) => i !== index));
    setModes((m) => {
      const nextModes = { ...m };
      delete nextModes[id];
      return nextModes;
    });
    playSound("guardian-remove", { guardian: id });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <button type="button" onClick={onBack} className="text-sm text-muted hover:text-fg">
          Niveles
        </button>
        <p className="text-xs tabular-nums text-muted">{hits.extremo} aciertos</p>
      </div>

      <p className="text-sm leading-relaxed text-muted">
        La frase es clara. El cifrado ya tiene cortejo. Invoca y retira guardianes
        hasta que tu versión coincida.
      </p>

      <div className="space-y-2 rounded-xl bg-surface px-4 py-5 shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-[0.2em] text-muted uppercase">Frase</p>
        <p className="font-display text-xl font-medium italic">{challenge.plaintext}</p>
      </div>

      <CipherCompare target={challenge.target} current={current} match={matches} />

      {resolved === "ok" ? (
        <p className="font-display text-center text-sm italic text-olive">
          El cortejo es el justo.
        </p>
      ) : null}
      {resolved === "revealed" ? (
        <p className="text-center text-sm text-muted">
          {challenge.sequence
            .map((id) => {
              const g = GUARDIANS[id];
              const plus = challenge.modes[id] !== false;
              if (isDualMode(id)) return `${g.name} (${plus ? g.plusLabel : g.minusLabel})`;
              return g.name;
            })
            .join(" · ")}
        </p>
      ) : null}

      <section className="space-y-3">
        {sequence.length > 0 ? (
          <ul className="space-y-2">
            {sequence.map((id, i) => {
              const g = GUARDIANS[id];
              const plus = modes[id] !== false;
              return (
                <li
                  key={`${id}-${i}`}
                  className="flex min-h-12 items-center gap-3 rounded-lg bg-surface px-3 py-2 shadow-[var(--shadow-border)]"
                  style={{ borderLeft: `3px solid ${g.accent}` }}
                >
                  <GuardianSigil id={id} className="size-5 text-olive" />
                  <span className="flex-1 font-medium">{g.name}</span>
                  {isDualMode(id) ? (
                    <label className="flex items-center gap-2 text-xs text-muted">
                      <Switch
                        checked={plus}
                        onCheckedChange={(v) => setModes((m) => ({ ...m, [id]: v }))}
                        aria-label={g.name}
                      />
                      {plus ? g.plusLabel : g.minusLabel}
                    </label>
                  ) : (
                    <span className="text-xs tabular-nums text-muted">{g.displacement}</span>
                  )}
                  <button
                    type="button"
                    className="inline-flex size-10 items-center justify-center rounded-md text-muted hover:text-fg"
                    aria-label={`Quitar ${g.name}`}
                    onClick={() => remove(i)}
                  >
                    <X className="size-4" />
                  </button>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="text-sm text-muted italic">Ningún guardián convocado.</p>
        )}

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {GUARDIAN_IDS.map((id) => {
            const g = GUARDIANS[id];
            const taken = sequence.includes(id);
            return (
              <button
                key={id}
                type="button"
                disabled={taken}
                onClick={() => add(id)}
                className="flex min-h-14 flex-col items-start gap-1 rounded-lg bg-surface px-3 py-2.5 text-left shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.98] disabled:opacity-40"
              >
                <span className="flex items-center gap-2 text-olive">
                  <GuardianSigil id={id} className="size-4" />
                  <span className="text-sm font-medium text-fg">{g.name}</span>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <div className="flex flex-wrap gap-2">
        {resolved !== "idle" ? (
          <Button type="button" onClick={next}>
            Siguiente
          </Button>
        ) : (
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setResolved("revealed");
              setSequence(challenge.sequence);
              setModes(challenge.modes);
              playSound("toggle");
            }}
          >
            <Eye />
            Revelar
          </Button>
        )}
      </div>
    </div>
  );
}

function CipherCompare({
  target,
  current,
  match,
}: {
  target: string;
  current: string;
  match: boolean;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="space-y-2 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-[0.2em] text-muted uppercase">Cifrado buscado</p>
        <p className="font-mono text-xs leading-relaxed break-all">{target}</p>
      </div>
      <div
        className={cn(
          "space-y-2 rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
          match && "ring-2 ring-olive/45",
        )}
      >
        <p className="text-xs tracking-[0.2em] text-muted uppercase">Tu cifrado</p>
        <p className="font-mono text-xs leading-relaxed break-all text-olive">
          {current || "—"}
        </p>
      </div>
    </div>
  );
}
