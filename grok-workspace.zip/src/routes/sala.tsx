import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, LogOut, Radio } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/maprayes/app-shell";
import { CopyButton } from "@/components/maprayes/copy-button";
import { notify } from "@/components/maprayes/notify";
import { ShareButton } from "@/components/maprayes/share-button";
import { GuardianSigil } from "@/components/maprayes/sigils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { encodeWithGuardians } from "@/lib/maprayes/cipher";
import { GUARDIANS } from "@/lib/maprayes/guardians";
import { inviteText } from "@/lib/maprayes/room-code";
import { playSound } from "@/lib/maprayes/sound";
import { useRoom } from "@/lib/store/room";
import { useSession } from "@/lib/store/session";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sala")({ component: Sala });

function Sala() {
  const code = useRoom((s) => s.code);
  return (
    <AppShell title="Sala">
      {code ? <InRoom /> : <Lobby />}
    </AppShell>
  );
}

function Lobby() {
  const name = useRoom((s) => s.name);
  const setName = useRoom((s) => s.setName);
  const createRoom = useRoom((s) => s.createRoom);
  const joinRoom = useRoom((s) => s.joinRoom);
  const [joinValue, setJoinValue] = useState("");

  return (
    <div className="space-y-8">
      <section className="space-y-3">
        <div className="flex items-center gap-2 text-olive">
          <Radio className="size-5" />
          <h2 className="font-display text-xl font-medium text-fg">Umbral</h2>
        </div>
        <p className="text-sm text-muted">
          Abre una sala y comparte el código. Los guardianes y el texto del
          traductor viajan al instante entre quienes cruzan.
        </p>
      </section>

      <label className="block space-y-2">
        <span className="text-sm font-medium">Tu nombre en la sala</span>
        <Input
          value={name}
          maxLength={24}
          onChange={(e) => setName(e.target.value)}
          placeholder="Viajero"
        />
      </label>

      <Button
        type="button"
        className="w-full"
        onClick={() => {
          const next = createRoom();
          playSound("join");
          notify(`Sala ${next} abierta.`, "yudmiry");
        }}
      >
        Crear sala
      </Button>

      <div className="space-y-3">
        <p className="text-sm font-medium">Unirse con un código</p>
        <div className="flex gap-2">
          <Input
            value={joinValue}
            onChange={(e) => setJoinValue(e.target.value.toUpperCase())}
            placeholder="MAP-7X3K"
            aria-label="Código de sala"
            className="font-mono tracking-widest"
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              const joined = joinRoom(joinValue);
              if (!joined) {
                playSound("error");
                notify("Ese código no abre ninguna puerta.", "escrimedes");
                return;
              }
              playSound("join");
              notify(`Cruzando a ${joined}…`, "yudmiry");
            }}
          >
            Entrar
          </Button>
        </div>
      </div>
    </div>
  );
}

function InRoom() {
  const code = useRoom((s) => s.code)!;
  const name = useRoom((s) => s.name);
  const joined = useRoom((s) => s.joined);
  const peers = useRoom((s) => s.peers);
  const view = useRoom((s) => s.view);
  const setView = useRoom((s) => s.setView);
  const plain = useRoom((s) => s.plain);
  const leaveRoom = useRoom((s) => s.leaveRoom);
  const sequence = useSession((s) => s.sequence);
  const modes = useSession((s) => s.modes);

  const encoded = useMemo(
    () => encodeWithGuardians(plain, sequence, modes).code,
    [plain, sequence, modes],
  );
  const live = view === "cipher" ? encoded : plain;
  const connected = peers.filter((p) => p.connectionState === "connected");
  const failed = peers.filter((p) => p.connectionState === "failed");

  return (
    <div className="space-y-8">
      <section className="rounded-xl bg-surface px-5 py-6 text-center shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-[0.28em] text-muted uppercase">Código</p>
        <p className="mt-2 font-display text-3xl font-medium tracking-[0.18em]">
          {code}
        </p>
        <p className="mt-2 text-sm text-muted">
          {joined
            ? connected.length === 0
              ? "Esperando a que alguien cruce…"
              : `${connected.length + 1} viajeros en el umbral`
            : "Abriendo el umbral…"}
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <CopyButton value={code} label="Copiar código" />
          <ShareButton value={inviteText(code)} label="Invitar" />
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-end justify-between gap-3">
          <h2 className="font-display text-xl font-medium">Eco en vivo</h2>
          <div className="flex gap-1">
            <ViewChip active={view === "plain"} onClick={() => setView("plain")}>
              Texto
            </ViewChip>
            <ViewChip active={view === "cipher"} onClick={() => setView("cipher")}>
              Cifrado
            </ViewChip>
          </div>
        </div>
        <div
          className={cn(
            "min-h-24 rounded-xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)]",
            view === "cipher" && "font-mono text-xs break-all",
          )}
        >
          {live.trim() ? (
            live
          ) : (
            <span className="text-muted italic">
              Aún no hay palabras en esta sala. Escríbelas en el traductor.
            </span>
          )}
        </div>
        <Button asChild variant="outline" className="w-full">
          <Link to="/traductor">
            Ir al traductor
            <ArrowRight />
          </Link>
        </Button>
      </section>

      {sequence.length > 0 ? (
        <section className="space-y-2">
          <h2 className="font-display text-lg font-medium">Guardianes en curso</h2>
          <ul className="flex flex-wrap gap-2">
            {sequence.map((id) => (
              <li
                key={id}
                className="inline-flex items-center gap-1.5 rounded-md bg-surface px-2.5 py-1.5 text-xs shadow-[var(--shadow-border)]"
              >
                <GuardianSigil id={id} className="size-3.5 text-olive" />
                {GUARDIANS[id].name}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="space-y-2">
        <h2 className="font-display text-lg font-medium">Presentes</h2>
        <ul className="space-y-2">
          <li className="rounded-lg bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]">
            {name} <span className="text-xs text-muted">(tú)</span>
          </li>
          {connected.map((p) => (
            <li
              key={p.id}
              className="rounded-lg bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]"
            >
              {p.name || "Viajero"}
              {p.rttMs != null ? (
                <span className="ml-2 text-xs text-muted">{p.rttMs} ms</span>
              ) : null}
            </li>
          ))}
          {failed.map((p) => (
            <li key={p.id} className="rounded-lg bg-surface px-3 py-2 text-sm text-muted">
              {p.name || "Viajero"} · no se pudo conectar
            </li>
          ))}
        </ul>
      </section>

      <Button
        type="button"
        variant="ghost"
        className="w-full"
        onClick={() => {
          leaveRoom();
          playSound("clear");
          notify("Has dejado la sala.", "epheron");
        }}
      >
        <LogOut />
        Salir de la sala
      </Button>
    </div>
  );
}

function ViewChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 rounded-md px-3 text-xs font-medium transition-colors duration-150",
        active
          ? "bg-olive text-olive-fg"
          : "bg-surface text-fg shadow-[var(--shadow-border)]",
      )}
    >
      {children}
    </button>
  );
}
