import { createFileRoute } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { AppShell } from "@/components/maprayes/app-shell";
import { HomeSeal } from "@/components/maprayes/home-seal";
import { GuardianSigil } from "@/components/maprayes/sigils";
import type { GuardianId } from "@/lib/maprayes/guardians";
import { LEVEL_LABEL, type PracticeLevel } from "@/lib/maprayes/iniciacion";
import { RELICS, relicUnlocked, unlockedCount, type Relic } from "@/lib/maprayes/reliquias";
import { useIniciacion } from "@/lib/store/iniciacion";
import { useHasMounted } from "@/hooks/use-has-mounted";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/iniciacion/reliquias")({ component: Reliquias });

const LEVELS: Exclude<PracticeLevel, "libre">[] = ["facil", "medio", "dificil", "extremo"];

function Reliquias() {
  const mounted = useHasMounted();
  const hits = useIniciacion((s) => s.hits);
  const guardianHits = useIniciacion((s) => s.guardianHits);
  const stats = { hits, guardianHits };
  const open = mounted ? unlockedCount(stats) : 0;

  return (
    <AppShell title="Reliquias" backTo="/iniciacion">
      <div className="space-y-10">
        <p className="text-sm leading-relaxed text-muted">
          Cada acierto deja una marca. Lo que duerme aquí no se inventa: se
          recuerda. {mounted ? `${open} de ${RELICS.length} despiertas.` : ""}
        </p>

        {LEVELS.map((level) => (
          <section key={level} className="space-y-3">
            <div className="flex items-end justify-between gap-3">
              <h2 className="font-display text-xl font-medium">{LEVEL_LABEL[level]}</h2>
              <p className="text-xs tabular-nums text-muted">
                {mounted ? `${hits[level]} aciertos` : ""}
              </p>
            </div>
            <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {RELICS.filter((r) => r.level === level).map((relic) => (
                <RelicCard
                  key={relic.id}
                  relic={relic}
                  unlocked={mounted && relicUnlocked(relic, stats)}
                  progress={hits[level] ?? 0}
                />
              ))}
            </ul>
          </section>
        ))}

        <section className="space-y-3">
          <h2 className="font-display text-xl font-medium">Pactos de Extremo</h2>
          <p className="text-sm text-muted">
            Cada guardián recuerda las veces que su voluntad cerró el acierto.
          </p>
          <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {RELICS.filter((r) => r.kind === "guardian").map((relic) => {
              const id = relic.guardian as GuardianId;
              return (
                <RelicCard
                  key={relic.id}
                  relic={relic}
                  unlocked={mounted && relicUnlocked(relic, stats)}
                  progress={guardianHits[id] ?? 0}
                  guardian={id}
                />
              );
            })}
          </ul>
        </section>
      </div>
    </AppShell>
  );
}

function RelicCard({
  relic,
  unlocked,
  progress,
  guardian,
}: {
  relic: Relic;
  unlocked: boolean;
  progress: number;
  guardian?: GuardianId;
}) {
  const ratio = Math.min(1, progress / relic.threshold);
  return (
    <li
      className={cn(
        "flex items-center gap-3 rounded-xl bg-surface px-4 py-3.5 shadow-[var(--shadow-border)]",
        !unlocked && "opacity-70",
      )}
    >
      <span
        className={cn(
          "flex size-12 shrink-0 items-center justify-center rounded-full",
          unlocked ? "text-olive" : "text-muted",
        )}
        aria-hidden="true"
      >
        {guardian ? (
          <GuardianSigil id={guardian} className="size-7" />
        ) : (
          <HomeSeal className="size-10" />
        )}
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="font-medium">{relic.title}</span>
          {unlocked ? null : <Lock className="size-3.5 text-muted" />}
        </span>
        <span className="block text-xs text-muted">{relic.hint}</span>
        <span className="mt-2 block h-1 overflow-hidden rounded-full bg-surface-2">
          <span
            className="block h-full rounded-full bg-olive transition-[width] duration-500"
            style={{ width: `${ratio * 100}%` }}
          />
        </span>
      </span>
    </li>
  );
}
