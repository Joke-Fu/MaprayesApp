import { createFileRoute } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/maprayes/app-shell";
import { Input } from "@/components/ui/input";
import {
  entriesForCategory,
  type TableCategory,
} from "@/lib/maprayes/alphabet";
import { useSettings } from "@/lib/store/settings";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/tabla")({ component: Tabla });

const TABS: { id: TableCategory; label: string }[] = [
  { id: "letras", label: "Letras" },
  { id: "numeros", label: "Números" },
  { id: "simbolos", label: "Símbolos" },
  { id: "favoritos", label: "Favoritos" },
];

function Tabla() {
  const [category, setCategory] = useState<TableCategory>("letras");
  const [query, setQuery] = useState("");
  const favorites = useSettings((s) => s.favorites);
  const toggleFavorite = useSettings((s) => s.toggleFavorite);

  const rows = useMemo(() => {
    const items = entriesForCategory(category, favorites);
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      ([code, char]) =>
        char.toLowerCase().includes(q) || code.toLowerCase().includes(q),
    );
  }, [category, favorites, query]);

  return (
    <AppShell title="Tabla de códigos" wide>
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setCategory(tab.id)}
              className={cn(
                "h-11 rounded-md px-4 text-sm font-medium transition-colors duration-150",
                category === tab.id
                  ? "bg-olive text-olive-fg"
                  : "bg-surface text-fg shadow-[var(--shadow-border)]",
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar carácter o código…"
          aria-label="Filtrar tabla"
        />
        {rows.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">
            {category === "favoritos"
              ? "Aún no has marcado ningún código. Toca la estrella en la tabla."
              : "Nada coincide con esa búsqueda."}
          </p>
        ) : (
          <div className="overflow-x-auto rounded-xl bg-surface shadow-[var(--shadow-border)]">
            <table className="w-full text-center">
              <thead>
                <tr className="bg-olive text-olive-fg">
                  <th className="px-3 py-3 font-display font-medium">Carácter</th>
                  <th className="px-3 py-3 font-display font-medium">Código</th>
                  <th className="px-3 py-3 font-display font-medium">Favorito</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(([code, char], i) => {
                  const fav = favorites.includes(code);
                  return (
                    <tr
                      key={code}
                      className={i % 2 === 1 ? "bg-surface-2/50" : undefined}
                    >
                      <td className="px-3 py-3 text-lg">{char}</td>
                      <td className="px-3 py-3 font-mono text-sm">{code}</td>
                      <td className="px-3 py-3">
                        <button
                          type="button"
                          className="inline-flex size-11 items-center justify-center rounded-md"
                          aria-label={
                            fav ? "Quitar de favoritos" : "Añadir a favoritos"
                          }
                          aria-pressed={fav}
                          onClick={() => toggleFavorite(code)}
                        >
                          <Star
                            className={cn(
                              "size-5",
                              fav
                                ? "fill-olive text-olive"
                                : "text-muted",
                            )}
                          />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
